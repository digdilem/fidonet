/*

KD.C
(c) Simon Avery 25/10/95

Kills a directory, and all sub directories and files.


*/


#include <stdio.h>
#include <dir.h>
#include <dos.h>


#define ULONG	unsigned long


ULONG tot_dirs=1;
ULONG tot_files=0;

ULONG bytes_free=0;
ULONG bytes_taken=0;

char path[MAXPATH];
char origpath[MAXPATH];
char origdir[MAXPATH];
char origpath[MAXPATH];

void help(void);
void getdiskspace(void);
void killstuff(char origpath[MAXDIR]);
void countstuff(char origpath[MAXDIR]);

char *current_directory(char *path)
{
   strcpy(path, "X:\\");      /* fill string with form of response: X:\ */
   path[0] = 'A' + getdisk();    /* replace X with current drive letter */
   getcurdir(0, path+3);  /* fill rest of string with current directory */
   return(path);
}


int main(int argc, char*argv[])
{
printf("\n���������������������������Ŀ");
printf("\n� KD   (C) Simon Avery 1995 �");
printf("\n�����������������������������\n");

if (argc<2)	help();


strcpy(path,argv[1]);
strupr(path);


current_directory(origdir);

if (chdir(path))
	{
	printf("\nError - Path not available.\n");
	exit(2);
	}

countstuff(path);
getdiskspace();


printf("\n%lu Files   %lu Directories   %lu Bytes   %lu Free Space",
							tot_files,
							tot_dirs,
							bytes_taken,
							bytes_free
							);

printf("\nCurr dir = %s",origdir);

printf("\nKill Directory? (y/N)");

switch(getch())
	{
	case 'y':
	case 'Y':
		killstuff(path);
		chdir(origdir);
		rmdir(path);
		printf("\nCompleted.  Deleted files: %lu   Total Dirs: %lu\n",tot_files,tot_dirs);
		break;
	default:
		chdir(origdir);
		printf("\nAborted.\n");
		break;
	}


return 0;
}

void getdiskspace(void)
{
struct dfree free;
int drive;

drive = getdisk();
getdfree(drive+1, &free);
if (free.df_sclus == 0xFFFF)
{
   printf("\nError in getdfree() call\n");
   exit(1);
}

bytes_free =  (long) free.df_avail
	 * (long) free.df_bsec
	 * (long) free.df_sclus;

}

void killstuff(char origpath[MAXPATH])
{
int done = 0;
struct ffblk data;

done = findfirst("*.*", &data, FA_DIREC+FA_SYSTEM+FA_HIDDEN);

while (!done)
{
	if (((data.ff_attrib & FA_DIREC) == FA_DIREC) &&
		(data.ff_name[0] != '.'))
		{
		chdir(data.ff_name);
		killstuff(origpath);
		chdir("..");
		rmdir(data.ff_name);
		}
	// my stuff to search in dir
	unlink(data.ff_name);

	done = findnext(&data);
}

}


void countstuff(char origpath[MAXPATH])
{
int done = 0;
struct ffblk dta;

done = findfirst("*.*", &dta, FA_DIREC+FA_SYSTEM+FA_HIDDEN);

while (!done)
{
	if (((dta.ff_attrib & FA_DIREC) == FA_DIREC) &&
		(dta.ff_name[0] != '.'))
		{
		chdir(dta.ff_name);
		countstuff(origpath);
		chdir("..");
		tot_dirs++;
		}
		else
		{
		tot_files++;
		bytes_taken+=dta.ff_fsize;
		}
	// my stuff to search in dir
	done = findnext(&dta);
}

}

void help(void)
{
printf("\nA small DOS utility to delete all files and subdirectories"
	"\nfrom a given path."
	"\nEg. KD C:\TEMP\n\n");
exit(1);
}
