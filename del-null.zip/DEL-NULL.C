/*
DEL-S   (c) Simon Avery 1995

Useful utility to delete files with a file-size of 0

Runs through all subsequent directories.


Freeware

*/


#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <string.h>
#include <dos.h>

char hidden=0;

unsigned long tot_files=0;
unsigned long tot_dirs=1;

char origdir[MAXPATH];
char origpath[MAXPATH];

void findpath(char origpath[MAXDIR]);

int main(int argc, char *argv[])
{
printf("\nDEL-NULL  (c) 1995 Simon Avery. Delete all 0-length files on drive.");

getcurdir(0, origdir);

findpath(origdir);

printf("\nCompleted.\nDeleted files: %lu   Total Dirs: %lu\n",tot_files,tot_dirs);

return 0;
}

void findpath(char origpath[MAXPATH])
{
int done = 0;
char *thispath;
struct ffblk data;

done = findfirst("*.*", &data, FA_DIREC+FA_SYSTEM+FA_HIDDEN);

while (!done)
	{
	if (((data.ff_attrib & FA_DIREC) == FA_DIREC) &&
		(data.ff_name[0] != '.'))
		{
		chdir(data.ff_name);
		findpath(origpath);
		chdir("..");
		tot_dirs++;
		}

	if ((data.ff_attrib & FA_DIREC) != FA_DIREC)
		{
		if (data.ff_fsize==0)	// null file
		      {
		      tot_files++;

		      getcurdir(0,thispath);
		      printf("\nDeleting file: \\%s\\%s",thispath,data.ff_name);

		      unlink(data.ff_name);
		      }
		}


	done = findnext(&data);
	}
}

help()
{
printf("\nDEL-NULL    (c) Simon Avery "__DATE__
	"\nDOS utility to delete files which have a 0byte filesize"
	"\n\nUsage: DEL-NULL"
	"\n\nSearches through all sub-dirs.");

exit(1);
return 0;
}
