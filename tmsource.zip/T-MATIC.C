


/*
Tag-O-Matic

Third re-write 25/10/96  Version 12

Copyright Simon Avery 1992 - 1996

Large mem model.
Turbo C Project file: \tc\t-matic\t-matic.prj

v.12e - Lost most of tag util functs - placed in TAGUTIL.C

bind spawnoL

v.13F - Severe memory limitations. Removed random scrolly, now fixed.
	Removed write_log

*/

	// Standard includes

#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <time.h>
#include <bios.h>
#include <string.h>
#include <stdlib.h>
#include <sys\stat.h>
#include <sys\types.h>
#include <io.h>
#include <dos.h>
#include <dir.h>
#include <alloc.h>
#include <math.h>
#include <process.h>
#include <errno.h>
#include <stddef.h>


#include <spawno.h>

	// glob decs needed by includes
	// My includes

	// constant defines
#define NAME		"Tag-O-Matic"
#define VER		"V.13F"

//#define TAGID		"TAGID: " NAME " " VER " Freeware\r\n"
#define CFGVER		13

#define TERMAILCFG	"TM.CFG"
#define CRACKVAL	197	// value for anti-cracking modifier
#define REGCODE		735154L

	//constant filenames
#define BACKUP_FILE	"OLDTAGS.TAG"
#define PROCESS_FILE	"PROCESS.TAG"
//#define LONGTAGFILE	"LONGTAGS.TAG"
#define TWIT_FILE	"T-MATIC.NAM"
#define TEMP_FILE	"T-MATIC.$$$"
#define DONETAGFILE	"DONETAGS.TAG"
#define MSGBACKUPFILE	"MESSAGE.BAK"
#define SCREENDATFILE	"T-MATIC.OVR"
#define DATEDATFILE	"T-MATIC.DAT"
//#define MSGINFOFILE	"MSGINFO.SYS"

	// keycode.h defines
#define LEFT		19424
#define P_LEFT		19200	// p_ means for old-type keyboards
#define RIGHT		19936
#define P_RIGHT		19712
#define UP_ARROW	18656
#define P_UP_ARROW	18432
#define DOWN_ARROW	20704
#define P_DOWN_ARROW	20480
#define ESC		283
#define SPACE		14624
#define ENTER		7181
#define C_ENTER		-8179
#define END		20448
#define P_END		20224
#define HOME		18400
#define P_HOME		18176
#define F1		15104
#define F2		15360
#define F3		15616
#define F4		15872
#define F5		16128
#define F6		16384
#define F7		16640
#define F8		16896
#define F9		17152
#define F10		17408
#define ALTJ		9216
#define ALTX		11520
#define ALT1		30720
#define ALT2		30976
#define ALT3		31232
#define ALT4		31488
#define ALT5		31744
#define ALT6		32000
#define ALT7		32256
#define ALT8		32612
#define ALT9		-32768L
#define ALT0		-32512
#define KEY_u		5749
#define KEY_U		5717
#define KEY_q		4209
#define KEY_Q		4177
#define KEY_s		8051
#define KEY_S		8019
#define KEY_L		9804
#define KEY_l		9836
#define KEY_r		4978
#define KEY_R		4946
#define KEY_P		6480
#define KEY_p		6512
#define KEY_T		5204
#define KEY_t		5236
#define KEY_G		8775
#define KEY_g		8807
#define KEY_f		8550
#define KEY_F		8518
#define KEY_H		9032
#define KEY_h		9064
#define KEY_e           4709
#define KEY_E		4677
#define DEL		21472
#define BACKSPACE	3592
#define PGDN		20960
#define PGUP		18912
#define CTRL_HOME	30688
#define CTRL_END	30176
#define INS		21216

	// some abbr's
#define ULONG	unsigned long
#define UCHAR	unsigned char
#define UINT	unsigned int

	// some max values
#define TAGLEN	2048	// biggest tagfile size
//#define BUFSIZE	6114	// for reformat
#define BUFSIZE	4096



		// some declarations
	// void funct(void)
void untag(void);
void steal(void);
//void intro(void);
void do_sig(void);
void donetag(void);
void tag_gen(void);
void np_pick(void);
void cr_pick(void);
void gen_tag(void);
void pick_tag(void);
void scrollit(void);
void do_tagid(int);
void save_dat(void);
void load_dat(void);
void mood_pick(void);
//void silly_man(void);
void steal_mood(void);
void hands_free(void);
void check_date(void);
void go_to_work(void);
void draw_tm_box(void);
void find_string(void);
void move_to_end(void);
void screen_saver(void);
void check_4_twit(void);
void reformat_text(int);
void change_quotes(void);
void rf_write_para(void);
void display_image(int);
void count_taglines(void);
void strip_hi_ascii(void);
void save_tag_yesno(void);
void check_for_tagid(void);
void check_key_abort(void);
void pick_new_tagfile(void);
void pick_new_sigfile(void);
void pick_new_sigfile_exact(void);
void get_datfile_name(void);
int write_tag_located(void);
//int write_tag_b4_tear(void);
void pick_multiple_tags(void);
	// void funct (char)
void check_msg_4_tag(char);
	// void funct(char *)
void help(char *);
void working(char *);
void execute(char *);
//void write_log(char *);
void delete_tag(char *);
void fatal_error(char *);
void missing_file(char *);
void do_extra_banner(char *);
void non_fatal_error(char *);
void slow_special_pick(char *);
void check_msg_4_search(void);
	// void funct (int, char *)
void quit(int, char *);
	// void funct((ULONG ULONG)
	// void funct (FILE *)
void write_tagline(FILE *);
void write_string(FILE *, char *);		// write any string, formatted, to FILE

	// char *
char yesno(void);
char *rmlead(char *);
char *rmtrail(char *);
char *parse_macro(char *);
	// others

int mousecheck(void);
int mouseclick(void);
int c_break(void);
int kill_file(char *);
int check_4_dupe(char *, int);
void tm_window(int,int,int,int,int);



	// some global dec's

FILE *datfp;
FILE *msg;		// msg file
FILE *rf_tmp;		// reformatting temp pointer

	// some global everythings
ULONG tot_tags=0L,chosen=0L;
ULONG filesize;		// size of current tagfile
ULONG tot_found=0L;
ULONG last_tag;

ULONG msg_filesize;

	// junk stuff
int junk;
int tw_need=0;

time_t scr_saver_first, scr_saver_second;

char tagline[TAGLEN];	// main tagline
char dumtag[TAGLEN];	// bakup to above, for parsing
char dummy[201];	// used by everything
char spec_pick_str[77]; // for special_slow_pick()
	// filenames
char dupetagfile[MAXPATH];
char tagfile[MAXPATH];
char CFGFILE[MAXPATH];
char DATFILE[MAXPATH];	// for spewtag
char sigfile[MAXPATH];
char createfile[MAXPATH];	 // for jh.rep
char homedir[MAXPATH];
//char logfile[MAXPATH];
char msgfile[MAXPATH];
char filterfile[MAXPATH];
char spewfile[MAXPATH];
char PGPfile[MAXPATH];
char onlychange[MAXPATH];
char NP_tagfile[MAXPATH];
char CR_tagfile[MAXPATH];
char MOOD_tagfile[MAXPATH];
char gifkludge[15];
char specialkludge[31];

char special_day_str[120];
char lotterystr[41];
char header[501];
char footer[501];
char newheader[101];
char newfooter[101];
char echodesc[31];
char np_str[10][51];
char cr_str[10][51];
char alt_tagfile[10][MAXPATH];
char mood_str[10][36];
char movetoendstr[10][35];
char filt_str[20][51];	// for tag filtering
char filt_str_fmt[20][51];	// for removing specific strings when reformatting
char dont_tag[10][16];
char vanilla_bod[10][36];	// for plain letters.
char replace_string_find[10][30];
char replace_string_with[10][22];
char msg_search_replace_find[20][21];
char msg_search_replace_with[20][21];
char tag_search_replace_find[20][21];
char tag_search_replace_with[20][21];
char tearline[81];	// finished tearline

char find_str[81];
char start_password[11];
char suggest_string_find[20][20];
char suggest_string_file[20][15];
char editstr[MAXPATH];	// editor string
char exec_str[MAXPATH];
char oldfile[MAXPATH];	// tm.bak for eg.
char origmsgfile[MAXPATH];
char after_edit_str[MAXPATH];
char PREFIX[6];		// tearline prefix
//char TAGPREFIX[5];
char *TAGPREFIX="...";
char quote_str[10];
char bufarr[BUFSIZE];
char twitname[20][36];	// twit's name (config)
char twitcfg[20][14];
char twittag[20][36];	// twit's name (tagfile)
char twittagcfg[20][14];
char origdate[81];
char origtime[81];
char echoID[51];
char groupID[51];
char fromaddr[21];
char toaddr[21];
char zingstring[21];
char *scr_buf;
char TAGID[51];

char do_reformat;
char dont_savedat=1;
char found_twit=0;
char original=0;
char twirly[5];
char tw_which;
char strip_len;		// length to strip too-long tags (/l)

char scroll_msg[101];
char scroll_x=0;
char scroll_n=0;

	// some useful arrays

	// some global saved vars
UCHAR countit=1, addsig=0, tagid=0, registered=0, trailing_cr=0;
UCHAR tag_total=1, check_dupes=1, use_macros=1, use_longdays=1, macro_sigs=0;
UCHAR tag_locate=0, filter_hi_asc=0, adopt_seperate=0, fuzzy_dupe=0;
UCHAR trim_trailing=1, play_tune=0,quote_style=1, swapout=1, filterstr_fnd=0;
UCHAR fiddle_method, twits_fnd=0, NP_fnd=0, CR_fnd=0, mood_fnd=0;
UCHAR NP_chosen=0,CR_chosen=0,mood_chosen=0, dodonetag=0, sort_bfr_dupe=0;
UCHAR donttagfnd=0, filter_word_fnd=0,replace_string_fnd=0,editlast=0;
UCHAR movetoendcnt=0,usetag=1,show_prompt=1,mouse_avail=0,suggestions_fnd=0;
UCHAR msgistoareafix=0,goto_scrolly=0,msg_search_fnd=0;
UCHAR tag_search_fnd=0,fast_tag,editorbeenrun=0,forceaddstuff=0;
UCHAR donotaddtearline=0,write_b4_tear=0,reformat_sig=0, picklist_sig=0;
UCHAR parse_replaced=0,special_day_tear=1,usegroup4cfg=0, quoteblank=0;
UCHAR reformat_tidy=0,tagpre_off=0,createmsgfile=0, edittagadopt=0;
UCHAR usemsginfo=1, killmsginfo=0, MSGINFOVersion=0,onlymsginfo=0;
UCHAR nocuursoronexit=0, isregistered=0, vanillas_fnd=0, twittags_fnd=0;
UCHAR f5invoked=0,editsteal=0;

//UCHAR check4uu=0,

UINT keep_check_num=0, keep_check=0, keep_check_mon=0, scr_saver_delay=0, specialdonetoday=0;

	// for msg stats
UINT msg_lines=0, msg_q_lines=0, msg_n_lines=0, msg_words=0, msg_q_words=0;
UINT msg_n_words=0, msg_size=0, msg_q_pct=0, quote_method=0;

//UINT logfilesizeK=0;
	// macro constants read from msgfile
char m_first[32];    		// first name
char m_middle[32];		// middle name / initial
char m_last[32];		// last name
char m_name[37];		// full name
char m_subj[76];		// subject
char m_from_name[36];		// previous senders name
char my_name[76];		// user's name

	// use-changable vars
UINT TAGRMARG=75;
UCHAR tagf_need_fc=0;	// tagfile needs full recount

		// ran out of mem in large model - see display_image for more info
		// in order - 1-4
//#include "\tc\t-matic\t-matic.sc1"      // thedraw screen for prompt	 - IMAGEDATA
//#include "\tc\t-matic\t-matic.sc2"      // thedraw screen for help (1)	 - IMAGEDATA2
//#include "\tc\t-matic\t-matic.sc3"      // thedraw screen for help (2)	 - IMAGEDATA3
//#include "\tc\t-matic\t-matic.sc4"      // thedraw screen for kEYS 	 - IMAGEDATA4

	// inits before ncludes
void init_prompt_show(void);
void tag_pick_list(void);
void read_msginfo(void);

#include "bp.h"				// keycode stuff
#include "version.h"			// for COMPILE_NO #define
#include "tag-head.h"			// multi-header file
#include "keycode.h"			// special replacement for bioskey
#include "editgets.h"			// simple line editor
#include "dirlist.h"			// scrolly file selection bar
#include "nocrack3.h"			// anti exe-editing routine
#include "longrand.h"			// rand routine for returning longs
//#include "tunes.h"	       		// annoying tune
#include "getini.h"			// for config routines
//#include "t-uudec.h"			// uudecoding routine
#include "t-config.h"			// config reading file
#include "t-replc.h"			// search / replace thing
#include "t-prompt.h"			// prompt screen routines
#include "t-list.h"			// scrolly pick-list
#include "t-msginf.h"			// MSGINFO.SYS routines


void main(int argc, char*argv[])
{
//int done;		// for wildcard search
	// copy some strings
//strcpy(TAGPREFIX,"...");
strcpy(twirly,"|/-\\");
strcpy(CFGFILE,"T-MATIC.CFG");
strcpy(TAGID,"TAGID: " NAME " " VER "\r\n");
ctrlbrk(c_break);

mouse_avail=mousecheck();

	// do some prelim stuff
randomize();					// seed rand counter
rstart(random(RAND_MAX),random(RAND_MAX));	// seed longrand counter
cursoff();
draw_tm_box();
//intro();
flushbuf();	// clear keyboard buffer
textattr(15);
gotoxy(1,6);
		// attempt to avoid cracking

if (!SELF_CHECK(argv[0],CRACKVAL))
	{
	textattr(RED);
	cprintf("FATAL ERROR: %s has failed self-check.\r\n",argv[0]);
	textattr(BROWN);
	cputs("EXE has been modified. Reasons could be:\r\n\n");
	textattr(YELLOW);
	cputs("Virus active on system. T-Matic infected.\r\n");
	cputs("File has been compressed or expanded.\r\n");
	cputs("File has been edited.\r\n\n");
	sound(300);
	delay(200);
	nosound();
	delay(50);
	sound(200);
	delay(500);
	nosound();
	wait(60);
	quit(99,"EXE altered");
	}

switch(argc)
	{
	case 1:
		help("No arguements supplied");
		quit(0,"Help text displayed");
		break;
	case 2:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case '?':
					help("Help requested");
					quit(0,"Help text displayed");
					break;
				case '!':
					if (!strcmp(argv[1],"/!GENERATE"))
						{
						textattr(WHITE);
						cprintf("Enter name: ");
						memset(dummy,0,50);
						editgets(12,wherey(),dummy,49,0,0);
						cprintf("\r\nKey is: [%lu]\n\r",bp(dummy,REGCODE));
						getch();
						quit(0,"Key generated.");
						}
					break;
				default:
					sprintf(dummy,"Switch [%s] no recognised, or out of context",argv[1]);
					help(dummy);
					quit(0,"Help text displayed");
					break;
				}
			}
		strcpy(msgfile,argv[1]);
		strupr(msgfile);

		go_to_work();
		break;
	case 3:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case 'U':	// untag msgfile
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					untag();
					break;
				case '4':     	// reformat
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					reformat_text(1);
					quit(0,"Message reformatted");
					break;
				case 'F':	// hands-free
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					hands_free();
					break;
				default:
					sprintf(dummy,"Switch [%s] not recognised, or out of context",argv[1]);
					help(dummy);
					quit(0,"Help text displayed");
					break;
				}
			}	// not a switch
		strcpy(msgfile,argv[1]);
		strcpy(CFGFILE,argv[2]);
		strupr(msgfile);
		strupr(CFGFILE);

		go_to_work();
		break;
	case 4:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case 'S':
					read_config(CFGFILE);
					strcpy(tagfile,argv[2]);
					strcpy(msgfile,argv[3]);
					strupr(tagfile);
					strupr(msgfile);
					steal();
					break;
				case 'F':	// hands-free
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					strcpy(CFGFILE,argv[3]);
					hands_free();
					break;
				case 'K':	//mood stealer
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					strcpy(msgfile,argv[3]);
					strupr(msgfile);
					steal_mood();
					break;
				default:
					sprintf(dummy,"Switch [%s] not recognised or out of context",argv[1]);
					break;
				}
			}
		strcpy(tagfile,argv[1]);
		strcpy(msgfile,argv[2]);
		strcpy(CFGFILE,argv[3]);
		strupr(tagfile);
		strupr(msgfile);
		strupr(CFGFILE);

		go_to_work();
		break;
	case 5:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case 'R':
					strcpy(tagfile,argv[2]);
					strcpy(spewfile,argv[3]);
					strupr(tagfile);
					strupr(spewfile);
					tot_tags=atol(argv[4]);
					tag_gen();
					break;
				default:
					sprintf(dummy,"Switch [%s] not recognised or out of context",argv[1]);
					break;
				}
			}
	}

help("No switches found.");
quit(0,"Help text displayed");
}

/*void intro(void)	// add silly msg to banner
{
textbackground(BLUE);
textcolor(WHITE);

switch(random(9))
	{
	case 0:
		center("EXCELLENT command or file name",3);
		break;
	case 1:
		center("This program requires Microsoft Windows.     NOT!",3);
		break;
	case 2:
		center("APATHY ERROR! Don't bother striking any key to continue",3);
		break;
	case 3:
		sprintf(dummy,"%s compiled on " __DATE__ " at "__TIME__" ",NAME);
		center(dummy,3);
		break;
	case 4:
		center("Fastest tagtool around, no idle boast",3);
		break;
	case 5:
		center("Don't even THINK of using another tagtool!",3);
		break;
	case 6:
		center("Tag Adoption and stealing - no other does it better",3);
		break;
	case 7:
		center("Are you using macro's? You should be!",3);
		break;
	default:
		center("Latest version always available at 2:255/90",3);
		break;
	}
} */

void go_to_work(void)
{
FILE *dropfp,*tmp;
int gibbon=0;
struct stat statbufa;
//ULONG tem_pos;

prompt_show();			// select tagline

if ((donotaddtearline) && (!editlast))
	{
	quit(0,"Message been changed. Not adding anything");
	}

if (strlen(createfile))	{if ((dropfp=fopen(createfile,"wt"))==NULL)	missing_file(createfile); }

if ((tagid) && (tagid!=3))	do_tagid(1);	// add tagid if req'd



if (write_b4_tear)
	{
	unlink(TEMP_FILE);
	rename(msgfile,TEMP_FILE);
	if ((msg=fopen(msgfile,"wt")) == NULL)	missing_file(msgfile);	// open file ready for appending
	if ((tmp=fopen(TEMP_FILE,"rt"))==NULL)	missing_file(TEMP_FILE);

	while(fgets(dummy,TAGLEN,tmp))
		{
		if ((dummy[0]=='-') && (dummy[1]=='-') &&(dummy[2]=='-'))
			break;
			else
			fputs(dummy,msg);
		}
	}
	else
	{
	if ((msg=fopen(msgfile,"at")) == NULL)	missing_file(msgfile);	// open file ready for appending
	}

if ((addsig) || (strchr(sigfile,'.')))	do_sig();

//if (trailing_cr)	fprintf(msg,"\n");
		// NP and CR lines
if (strlen(NP_tagfile))
	{
	slow_special_pick(NP_tagfile);
	fprintf(msg,"NP: %s\r\n",spec_pick_str);
	}
	else
	{
	if (NP_chosen<=9)	{ fprintf(msg,"NP: %s\n",np_str[NP_chosen]); gibbon++; }
	}

if (strlen(CR_tagfile))
	{
	slow_special_pick(CR_tagfile);
	fprintf(msg,"CR: %s\r\n",spec_pick_str);
	}
	else
	{
	if (CR_chosen<=9)	{ fprintf(msg,"CR: %s\n",cr_str[CR_chosen]); gibbon++; }
	}

if (gibbon)		fputs("\n",msg);

//if (trailing_cr)	fprintf(msg,"\n");

if (usetag)
	{
	if (tag_locate)
		{
		fclose(msg);
		write_tag_located();

		if ((msg=fopen(msgfile,"at"))==NULL)
			{
			missing_file(msgfile);
			}
		}
		else
		{
		write_tagline(msg);
		write_tagline(dropfp);
		}
	}


if (strlen(lotterystr))
	{
	sprintf(dummy,"-$- %s %d %d %d %d %d %d\n",
					lotterystr,
					random(8)+1,
					random(8)+9,
					random(8)+17,
					random(8)+25,
					random(8)+33,
					random(8)+42);
	fputs(dummy,msg);
	if (strlen(createfile)) fputs(dummy,dropfp);
	}
		// either 0 or 1

if ((tagid!=1) && (!donotaddtearline) && (tagid!=3))
	{
	fprintf(msg,"%.76s",parse_macro(tearline));
	if (strlen(createfile)) fprintf(dropfp,"%.76s",parse_macro(tearline));
	}

if ((trailing_cr) ||  (write_b4_tear))	fputs("\n",msg);
		     //(movetoendcnt) ||
if (dodonetag)	donetag();

if (write_b4_tear)
	{
	while(fgets(dummy,TAGLEN,tmp))	fputs(dummy,msg);
	fclose(tmp);
	}

fclose(msg);

check_msg_4_search();
//quit(0,"Premature test exit");
		// do create drop file if neccessary


if (movetoendcnt)	move_to_end();

if ((strlen(editstr)) && (editlast))
	{
	stat(msgfile,&statbufa);

	msg_filesize=statbufa.st_size;		// save filesize.
	working("Calling editor...");

	execute(parse_macro(editstr));

	printf("\n%s Swapping in...",NAME);
	display_image(1);

	stat(msgfile,&statbufa);
	init_prompt_show();

	if (msg_filesize==statbufa.st_size)	file_not_changed();
	check_for_tagid();

	if (donotaddtearline)
		{
		quit(0,"Message been changed. Not adding anything");
		}
	}


if (keep_check)
	{
	working("Writing number / Month");
	datecheck_write();
	}

		// msg details in logfile
//sprintf(dummy,"Message tagged. Addressed to: [%s]",m_name);
//write_log(dummy);

quit(0,"Something went wrong - it worked!");
}

void do_sig(void)
{
FILE *sigfp;

char sigfile2[15];
char dumstri[101];

// check to see if sigfile's got a . (it's been selected at prompt)

if (strchr(sigfile,'.'))
	strcpy(sigfile2,sigfile);
	else
	sprintf(sigfile2,"%s.%d",sigfile,random(addsig)+1);

if ((sigfp=fopen(sigfile2,"rt"))==NULL)
	{
	sprintf(dummy,"I appear to be missing sigfile: [%s]",sigfile2);
	box_error(dummy);
	wait(20);
	display_image(1);
	init_prompt_show();
	return;
	}

while (fgets(dumstri,100,sigfp))
	{
	if (!macro_sigs)		// no need to parse - just append
		{
		if (reformat_sig)
			{
			rmtrail(dumstri);
			write_string(msg,dumstri);
			}
			else
			{
			fputs(dumstri,msg);
			}
		}
		else		// parse
		{
		if (reformat_sig)
			{
			rmtrail(dumstri);
			strcpy(dumtag,parse_macro(dumstri));
			write_string(msg,dumtag);
			}
			else
			{
			fprintf(msg,"%s",parse_macro(dumstri));
			}
		}
	}

fprintf(msg,"\n");

fclose(sigfp);
}

void do_tagid(int doextra)
{
FILE *tmp;
int ch;

if (tagid==5)	return;

if ((tmp=fopen(TEMP_FILE,"wb"))==NULL)	missing_file(TEMP_FILE);
if ((msg=fopen(msgfile,"rb"))==NULL)
	{
	if (!createmsgfile)	missing_file(msgfile);
	}

if ((tagid) && (tagid!=3))
	{
	fputc(1,tmp);
	fputs(TAGID,tmp);
	}

if (doextra)
	{
	if (strlen(gifkludge))		fprintf(tmp,"%cGIF: %s\r\n",1,gifkludge);

	if (strlen(specialkludge))      fprintf(tmp,"%c%s\r\n",1,specialkludge);

	if ((!strlen(MOOD_tagfile)) || (mood_chosen >=9));
		else
		{
		if (strlen(MOOD_tagfile))
			{
			slow_special_pick(MOOD_tagfile);
			fprintf(tmp,"MOOD: %s\r\n",spec_pick_str);
			}
			else
			{
			fprintf(tmp,"MOOD: %s\r\n",mood_str[mood_chosen]);
			}
		}
	}

while (!feof(msg))
	{
	ch=fgetc(msg);
	if (ch!=EOF)	fputc(ch,tmp);
	}

fclose(tmp);
fclose(msg);

if (kill_file(msgfile))		fatal_error("Unable to delete message file prior to copying temp file across [1]");

if (rename(TEMP_FILE,msgfile))	fatal_error("renaming tempfile to msgfile [2]");

}

void check_msg_4_tag(char do_tag_yesno)
{	// do-tag_yesno is whether to check for a tagline, or just count
float pct;
struct stat statbuf;

UCHAR this_is_quoted;
ULONG q_bytes=0L;

stat(msgfile,&statbuf);

if (statbuf.st_size==0)		quit(4,"Message file is of size 0, not valid");

if (statbuf.st_size>64000L)
	{
	sound(300);
	delay(300);
	nosound();
	box_error("Warning! Message is larger than 64K!");
	wait(20);
	display_image(1);
	init_prompt_show();
	}

if ((msg=fopen(msgfile,"rt"))==NULL)	quit(33,"Unable to open message file (check_msg_4_tag");

working("Examining Message");

while(fgets(tagline,TAGLEN,msg))
	{
	if ((tagline[0]=='.') && (tagline[2]=='.'))
		{
		if (do_tag_yesno)
			{
			box_error("Message is being having a tagline already Sire. Quit? (Y/n)");
			switch(getch())
				{
				case 'N':
				case 'n':
					display_image(1);
//					puttext(1,1,80,25,IMAGEDATA);
					init_prompt_show();
					break;
				default:
					quit(5,"Message is being having a tagline already");
					break;
				}
			}
		}

	this_is_quoted=0;

	msg_size+=(strlen(tagline));

	for (junk=0; junk < 7; junk++)	{ if (tagline[junk]=='>')	this_is_quoted=1; }

	for (junk=0; junk!=(strlen(tagline)); junk++)
		{
		if (isalpha(tagline[junk]))
			{
			if (isspace(tagline[junk-1]))
				{
				if (this_is_quoted)
					{ msg_q_words++; }
					else
					{ msg_n_words++; }
				}
			}
		}

		// calc quote pct on bytes
	if (this_is_quoted)
		{ q_bytes+=(strlen(tagline)); }
		else
		{ msg_n_words+=(strlen(tagline)); }

	msg_lines++;

	if (this_is_quoted)
		{ msg_q_lines++; }
		else
		{ msg_n_lines++; }

		// now check to see if any SuggestWords are listed.
		// if so, we'll load that tagfile.
	if (suggestions_fnd)
		{
		for (junk=0; junk<=(suggestions_fnd-1); junk++)
			{
//			printf("\n=[%s] [%s]",suggest_string_find[junk],suggest_string_file[junk]);
			strupr(tagline);
			strupr(suggest_string_find[junk]);
			if (strstr(tagline,suggest_string_find[junk]))
				{
				sprintf(dummy,"Using suggest tagfile [%s]",suggest_string_file[junk]);
				working(dummy);
				strcpy(tagfile,suggest_string_file[junk]);
				suggestions_fnd=0;
				break;
				}
			}
		}
	}


fclose(msg);
	// work out quote pct
//pct=((float) q_bytes/msg_size);
msg_words=(msg_n_words+msg_q_words);

	// add guesstimate of size of tagstuff
msg_n_lines+=2;
msg_n_words+=10;	// not bytes since its' done by filesize

switch(quote_method)
	{
	case 1: //words
		pct=((float) msg_q_words/msg_words);
		break;
	case 2:	// lines
		pct=((float) msg_q_lines/(msg_q_lines+msg_n_lines));
		break;
	case 0:	// bytes
	default:
		pct=((float) q_bytes/statbuf.st_size);
		break;
	}


msg_q_pct=(pct*100);

}

void count_taglines(void)
{
FILE *dat;
FILE *tag;

struct stat statbuf;
ULONG old_tagfilesize;
ULONG old_tot_tags;

get_datfile_name();

stat(tagfile,&statbuf);		// get details of tagfile

if ((dat=fopen(DATFILE,"rb")) !=NULL)	// it exists
	{
	sprintf(dummy,"Using index file: [%s]",DATFILE);
	working(dummy);
	fscanf(dat,"%ld,%ld,%d",
				&old_tagfilesize,
				&old_tot_tags,
				&tagf_need_fc);
	fclose(dat);

	if (old_tagfilesize!=statbuf.st_size)           // it's changed
		{
		tagf_need_fc++;

		if (kill_file(DATFILE))
			{
			sprintf(dummy,"Unable to delete index file: [%s]",DATFILE);
			fatal_error(dummy);
			}

		if ((tag=fopen(tagfile,"rt"))==NULL) { quit(34,"File Error (count_taglines[1]) Tagfile not found!"); }

		if (tagf_need_fc > 10)		// full recount
			{
			working("Tagfile has changed. Counting...");
			tot_tags=0L;
			tagf_need_fc=0;

			while (fgets(tagline,TAGLEN,tag))	{tot_tags++;}
			}
			else
			{
			if (statbuf.st_size > old_tagfilesize)
				{
				working("Tagfile's changed - Bigger");
				tot_tags=(old_tot_tags-1);	// -1 to allow for trailing CR

				fseek(tag,old_tagfilesize,SEEK_SET);

				while (fgets(tagline,TAGLEN,tag))
					{
					tot_tags++;
					if (strlen(tagline) < 3) tot_tags--;
					}
				}
				else
				{
				working("Tagfile's changed - Smaller");
				tot_tags=0L;
				while (fgets(tagline,TAGLEN,tag))
					{
					tot_tags++;
					if (strlen(tagline) < 3) tot_tags--;
					}
				}
			}
		filesize=statbuf.st_size;
		fclose(tag);
		save_dat();
		}
		else
		{
		working("Filesize not changed");
		filesize=statbuf.st_size;
		tot_tags=old_tot_tags;
		}
	}
	else		// can't open, got to create datafile
	{
	tot_tags=0L;
	// problem is here

	if ((tag=fopen(tagfile,"rt"))==NULL) 	missing_file(tagfile);

	working("Woo! New tagfile! Counting...");

	while (fgets(tagline,TAGLEN,tag))	tot_tags++;

	filesize=statbuf.st_size;
	fclose(tag);
	save_dat();
	}

}

void pick_tag(void)
{
FILE *tagfp2;
ULONG tmp=0L,min=0L,max=0L;

if (!usetag)
	{
	strcpy(tagline,"Tags disabled");
	return;
	}

load_dat();

//fcloseall();
if ((tagfp2=fopen(tagfile,"rt"))==NULL)
	{
	sprintf(dumtag,"Error picking tag. Cannot locate tagfile [%s]",tagfile);
	box_error(dumtag);
	wait(10);
	missing_file(tagfile);
	}

if (tot_tags > 3000L)
	{
	working("Using FAST tag choosing");
	fast_tag=1;
	}
	else
	{
	working("Using SLOW tag choosing");
	fast_tag=0;
	}

if (fast_tag)
	{
	max=(last_tag+160);

	if (last_tag < 160)
		{ min=0; }
		else
		{ min=(last_tag-160); }

	goto Pick_Again;

	Pick_Again:
	;

	chosen=longrand(filesize);

	if ((chosen>min) && (chosen < max))	goto Pick_Again;

//	if (!original)
//		{
		sprintf(dummy,"Offset: [%lu]",chosen);
		working(dummy);
//		}

	if (chosen<=0)
		{
		working("Tagfile too small");
		return;
		}

	fseek(tagfp2,chosen,SEEK_SET);
	fgets(tagline,TAGLEN,tagfp2);	// to end of line
	chosen=ftell(tagfp2);	// so it gives correct pos on prompt
	fgets(tagline,TAGLEN,tagfp2);
	}
	else
	{
	do {(chosen=random(tot_tags)+1); } while (chosen==last_tag);

	if (chosen==0) chosen=1;

//	if (!original)
//		{
		sprintf(dummy,"SLOW tag choosing: Number [%lu]",chosen);
		working(dummy);
//		}

	while (tmp < chosen)
		{
		gotoxy(57,1);
		cprintf("%c",twirly[tw_which]);

		if (tw_need++ > 200)	{ tw_which++; tw_need=0; }
		if (tw_which > 3)	tw_which=0;

		fgets(tagline,TAGLEN,tagfp2);

		if (ferror(tagfp2))	{ strcpy(tagline,"Error getting tag from tagfile! [1]"); break; }

		tmp++;
		}
	}

rmtrail(tagline);

if (strlen(tagline)<2)
	{
	sprintf(dummy,"Tagline too short: [%s]",tagline);
	working(dummy);
	strcpy(tagline,"Error getting tag from tagfile! [2] (Too short)");
	}

fclose(tagfp2);

if (filter_hi_asc)	strip_hi_ascii();

last_tag=chosen;
}

void help(char *hlptxt)
{
textattr(WHITE);
clrscr();
//puttext(1,1,80,25,IMAGEDATA2);
display_image(2);
textbackground(BLUE);
textcolor(WHITE);
sprintf(dummy,"%s %s",NAME,VER);
center(dummy,2);
textattr(WHITE);
center(hlptxt,5);
bioskey(0);
//getch();
//puttext(1,1,80,25,IMAGEDATA3);
//display_image(3);
//textbackground(BLUE);
//textcolor(WHITE);
//center(dummy,2);
//textattr(WHITE);
//center(hlptxt,5);
//getch();
}

void steal(void)
{
FILE *tag;

tot_tags=0L;
textattr(WHITE);
cprintf("Tag-hunting...\r\n",
	"Message: [%s]\r\n",
	"Tagfile: [%s]\r\n",msgfile,tagfile);

if ((msg=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);

if (adopt_seperate)
	{
	textattr(GREEN);
	cprintf("Adopting to seperate file: [%s]\r\n",PROCESS_FILE);
	if ((tag=fopen(PROCESS_FILE,"at"))==NULL)	missing_file(PROCESS_FILE);
	}
	else
	{
	if ((tag=fopen(tagfile,"at"))==NULL)		missing_file(tagfile);
	}
		// main loop
while (fgets(tagline,TAGLEN,msg))
	{
	memset(dumtag,'\0',TAGLEN);

	if ((tagline[0]=='.') && (tagline[2]=='.') && (tagline[3]==' '))
		{
		rmtrail(tagline);

		if ((strlen(tagline)) < 6)
			{
			textattr(LIGHTRED);
			cputs("Tag too short!\r\n");
			}
			else
			{
			// remove 1st 4 chars
			for (junk=4; junk!=(strlen(tagline)); junk++)
				{
				dumtag[junk-4]=tagline[junk];
				}
			dumtag[junk]='\0';	// null terminator

			textattr(LIGHTBLUE);
			cprintf("Found: [%.68s]\r\n",dumtag);

			if (editsteal)
				{
				textattr(LIGHTCYAN);
				cprintf("Manual edit enabled:\r\n");
				textattr(WHITE);

					sound(500);
					delay(50);
					nosound();

				editgets(1,wherey(),dumtag,79,0,0);
				}

			if (check_dupes)
				{
				switch(check_4_dupe(dumtag,1))
					{
					case 0:
						if (fprintf(tag,"%s\n",dumtag)==EOF)	box_error("Problem writing tag");
	//					fclose(tag);
						tot_tags++;
						break;
					case 1:
						textattr(LIGHTRED);
						cputs("Duped...\r\n");
						break;
					case 2:
						textattr(LIGHTRED);
						cputs("Contained a filtered word...\r\n");
						break;
					default:
						textattr(LIGHTRED+BLINK);
						cputs("Error in steal function!\r\n\a");
						break;
					}
				}
				else		// no dupe-check, just append
				{
				if ((fprintf(tag,"%s\n",dumtag))==EOF)	{box_error("Error writing to tagfile"); wait(10); }
				tot_tags++;
				}
			}
	    //	wait(1);
		}
	}

fclose(tag);
fclose(msg);

sprintf(dummy,"Stolen %lu tags from file [%s]",tot_tags,msgfile);
textattr(YELLOW);
cprintf("\r\n%s",dummy);
//wait(5);
quit(0,dummy);
}



int check_4_dupe(char *newtag, int usebox)
{
FILE *tg;
char dummy2[TAGLEN];	// to save overwriting dumtag etc which may be in use
char rslt=0;

if (usebox)		// * poss reposition cursor if usebox
	{
	box_error("Checking for dupes...");
	}

if ((tg=fopen(tagfile,"rt"))==NULL)		return 0;

	// check it for filtered words first

for (junk=0; junk!=10; junk++)
	{
	if (strlen(filt_str[junk]) > 3 )	// only do it if it's got something in it
		{
		if (strstr(newtag,filt_str[junk]))
			{
			fclose(tg);
			return 2;
			}
		}
	}

	// check it against every tag in file (yawn)

while (fgets(dummy2,TAGLEN,tg))
	{
	if (!strcmp(newtag,dummy2))
		{
		fclose(tg);
		return 1;
		}
	}
fclose(tg);

return rslt;
}
		// DO NOT put write log entry in here, since it recurses
void quit(int errlev, char *errmsg)
{
char dummy5[81];
//FILE *logfp;
//struct time t;
//struct date d;
textattr(WHITE);
clrscr();
textbackground(BLUE);
tm_window(1,1,80,1,WHITE);
textcolor(YELLOW);
sprintf(dummy5,"%s %s Copyright "__DATE__" Simon Avery",NAME,VER);
center(dummy5,2);
gotoxy(1,4);
textattr(WHITE);
cprintf("Closing down\r\n");
cprintf("%d files closed down\r\n",fcloseall());

cprintf("Returning error level %d\r\n",errlev);

switch(errlev)
	{
	case 0:
		cprintf("No problems. Feel lucky.\r\n");
		break;
	default:
		textattr(LIGHTRED);
		cprintf("A problem occured. (Blame the beta-testers)\r\n");
/*		if (strlen(logfile))
			{
			textattr(LIGHTMAGENTA);
			cprintf("Writing to Log: ");
			if ((logfp=fopen(logfile,"at"))==NULL)
				{
				if ((logfp=fopen(logfile,"wt"))==NULL)
					{
					textattr(LIGHTRED+BLINK);
					cprintf("Cannot open logfile: [%s]\r\n",logfile);
					break;
					}
				}
			gettime(&t);
			getdate(&d);
			fprintf(logfp,"-!- %.2d/%.2d/%d %.2d:%.2d:%.2d.%.2d Errlev: %d  Reason: %s\r\n",
						d.da_day,
						d.da_mon,
						d.da_year,
						t.ti_hour,
						t.ti_min,
						t.ti_sec,
						t.ti_hund,
						errlev,
						errmsg);
			fclose(logfp);
			cprintf("Written.\r\n");
			}*/
		textattr(LIGHTRED);
		break;
	}

cprintf("%s\n",errmsg);
textattr(LIGHTGRAY);
if (!nocuursoronexit)	_setcursortype(_NORMALCURSOR);

if (errlev)	wait(30);

exit(errlev);
}

void save_dat(void)
{
FILE *dat;

if ((dat=fopen(DATFILE,"wb"))==NULL)	missing_file(DATFILE);

fprintf(dat,"%lu,%lu,%d,%lu",filesize,tot_tags,tagf_need_fc,last_tag);

fclose(dat);
}


void delete_tag(char *killtag)
{
FILE *tmp,*tag;
int tot_bad=0;

working("Killing tagline...");

if ((tag=fopen(tagfile,"rt"))==NULL)	missing_file(tagfile);

if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)	missing_file(TEMP_FILE);

while (fgets(dumtag,TAGLEN,tag))
	{
	rmtrail(dumtag);
	if (!strcmp(dumtag,killtag))
		{ tot_bad++; }
		else
		{ fprintf(tmp,"%s\n",dumtag); }
	}

fclose(tag);
fclose(tmp);

kill_file(BACKUP_FILE);				//)			non_fatal_error("Unable to delete backup file");

if (rename(tagfile,BACKUP_FILE))        quit(9,"Unable to delete tagfile prior to copying tempfile across");

if (rename(BACKUP_FILE,tagfile))	quit(10,"Unable to rename temp file to tagfile");

sprintf(dummy,"%d tags deleted",tot_bad);
working(dummy);

tot_tags-=tot_bad;

display_image(1);
init_prompt_show();
}

void find_string(void)
{
FILE *tag;
char found=0;

textbackground(GREEN);
tm_window(5,9,70,5,WHITE);
center("Searching...",10);

if ((tag=fopen(tagfile,"rt"))==NULL)	missing_file(tagfile);

while(fgets(tagline,TAGLEN,tag))
	{
	strcpy(dumtag,tagline);		// copy it so it doesn't uppercase original tagline
	strupr(dumtag);

	if (strstr(dumtag,find_str))
		{
		if (use_macros)		parse_macro(tagline);
		textcolor(WHITE);
		center("Found a match",11);
		sound(600);
		delay(50);
		nosound();
		textcolor(LIGHTGREEN);
		gotoxy(6,13);
				// clear any existing tag
		for (junk=0; junk!=66; junk++)	cputs(" ");

		gotoxy(6,13);
		cprintf("%.66s",tagline);

		textcolor(YELLOW);
		center("Accept this? (Y/n)",14);

		switch(toupper(getch()))
			{
			case 'N':
				break;
			default:
				found=1;
				break;
			}
		}

	if (found)	break;
	}

fclose(tag);

rmtrail(tagline);

if (!found)
	{
	box_error("Unable to find match. Picking random tag");
	wait(5);
	display_image(1);
	init_prompt_show();
	pick_tag();			// just to get a random tag
	}
}

void check_date(void)
{
struct date d;
char itis=0;

strcpy(special_day_str,"Happy St. ");

getdate(&d);

if ((d.da_day==9) && (d.da_mon==7))
	{
	itis=2;
	strcpy(special_day_str,"It's the author's birthday on the 15th!\r\nWhy not send him a birthday netmail?\r\n\nSimon Avery, at 2:255/20.1");
	}

if ((d.da_day==15) && (d.da_mon==7))
	{
	itis=3;
	sprintf(special_day_str,"The date is 15th July, the author's Birthday!\r\nHe's %d years old today!\r\nHope you sent him a birthday Netmail...",d.da_year-1971);
	}

if ((d.da_day==25) && (d.da_mon==12))
	{
	itis=1;
	strcpy(special_day_str,"Happy Christmas / Hanukkah!");
	}

if ((d.da_day==1) && (d.da_mon==1))
	{
	itis=1;
	strcpy(special_day_str,"Happy New Year!");
	}

if ((d.da_day==4) && (d.da_mon==7))
	{
	itis=1;
	strcpy(special_day_str,"Happy 4th of July!");
	}

if ((d.da_day==10) && (d.da_mon==7))
	{
	itis=2;
	strcpy(special_day_str,"It's the beta-tester's Birthday!");
	}

if ((d.da_mon==11) && (d.da_day > 21) && (2==day_of_week(d.da_day,d.da_mon,d.da_year)))
	{
	itis=1;
	strcpy(special_day_str,"Happy Thanksgiving!");
	}

	// some obscure ones...

if ((d.da_mon==1) && (d.da_day==19))
	{
	itis=1;
	strcat(special_day_str,"Wulfstan day!");
	}

if ((d.da_mon==2) && (d.da_day==23))
	{
	itis=1;
	strcat(special_day_str,"Polycarp day!");
	}
if ((d.da_mon==3) && (d.da_day==20))
	{
	itis=1;
	strcat(special_day_str,"Cuthbert day!");
	}
if ((d.da_mon==4) && (d.da_day==10))
	{
	itis=1;
	strcat(special_day_str,"Fulbert day!");
	}
if ((d.da_mon==5) && (d.da_day==30))
	{
	itis=1;
	strcat(special_day_str,"Joan of Arc day!");
	}
if ((d.da_mon==6) && (d.da_day==23))
	{
	itis=1;
	strcat(special_day_str,"Etheldreda day!");
	}
if ((d.da_mon==7) && (d.da_day==27))
	{
	itis=1;
	strcat(special_day_str,"Pantaleon");
	}
if ((d.da_mon==8) && (d.da_day==15))
	{
	itis=1;
	strcat(special_day_str,"Arnulf");
	}
if ((d.da_mon==9) && (d.da_day==27))
	{
	itis=1;
	strcat(special_day_str,"Frumentius day!");
	}
if ((d.da_mon==10) && (d.da_day==31))
	{
	itis=1;
	strcat(special_day_str,"Wolfgang day!");
	}
if ((d.da_mon==11) && (d.da_day==3))
	{
	itis=1;
	strcat(special_day_str,"Winifred day!");
	}
if ((d.da_mon==12) && (d.da_day==7))
	{
	itis=1;
	strcat(special_day_str,"Ambrose day!");
	}

if (itis)
	{
	if (specialdonetoday==d.da_day)
		{
		return;
		}
		else
		{
		if (keep_check)
			{
			textattr(WHITE);
			cprintf("\r\nGood morning, %s\r\n",my_name);
			delay(500);
			}

		textattr(LIGHTGREEN);
		cprintf("\r\nIt's a special day!   ");
		sound(400);
		delay(5);
		nosound();
		textattr(WHITE);
		cputs(special_day_str);

		if ((special_day_tear) && (itis!=2))
			{
			if (itis==3)	strcpy(special_day_str,"Happy St. Swithin's Day!");
			if (!strlen(PREFIX))	pick_prefix();
			sprintf(tearline,"%s %s %s %s",PREFIX,NAME,VER,special_day_str);
			}

		wait(20);
		}
	}
	else
	{
	strcpy(special_day_str,"\0");
	}

}

void save_tag_yesno(void)
{
FILE *tag;
textbackground(RED);
tm_window(28,9,24,1,WHITE);

center("Save this tag? (y/N)",10);

switch(toupper(getch()))
	{
	case 'Y':
		if (check_dupes)
			{
			if (!check_4_dupe(tagline,1))
				{
				if ((tag=fopen(tagfile,"at"))==NULL)	missing_file(tagfile);

				fprintf(tag,"%s\n",tagline);
				fclose(tag);
				}
				else
				{
				sound(300);
				delay(200);
				nosound();
				}
			}
			else
			{
			if ((tag=fopen(tagfile,"at"))==NULL)	missing_file(tagfile);

			fprintf(tag,"%s\n",tagline);
			fclose(tag);
			}
		break;
	default:
		break;
	}
}

void write_tagline(FILE *tmp)		// with proper word-wrap
{
char *taghere, *tagstart;
int true_rmarg=(TAGRMARG-4);		// to allow for precursor

if (trailing_cr)		fputs("\n",tmp);

// poss put in another trailing CR if it don't appear too well.

if (use_macros)
	{
	strcpy(dumtag,parse_macro(tagline));
	strcpy(tagline,dumtag);
	}

if (tag_search_fnd)
	{
	tag_search_fnd--;
	for (junk=0; junk<=tag_search_fnd; junk++)
		{
		if (strstr(tagline,tag_search_replace_find[junk]))
			{
			working("Found match for replace in tag");
			strrepl(tagline,TAGLEN,tag_search_replace_find[junk],tag_search_replace_with[junk]);
			}
		}
	}

tagstart=tagline;
		// main word-wrap routine
while (strlen(tagstart)>true_rmarg)
	{
	/* The tagline needs formatting */
	taghere=(tagstart+true_rmarg);
	while (*taghere!=' ' && taghere>tagstart) taghere--;
	*taghere=0;
	fprintf(tmp,"%s %s\n",TAGPREFIX,tagstart);
	tagstart=taghere+1;

	if (tagpre_off)
		{
		strcpy(TAGPREFIX,"   ");
		}
	}

fprintf(tmp,"%s %s\n",TAGPREFIX,tagstart);
}

void missing_file(char *filnm)
{
sprintf(dumtag,"Error!\r\n%s had problems accessing file: [%s]",NAME,filnm);
dont_savedat=1;
quit(11,dumtag);
}

int write_tag_located(void)	// locate a tagline in a specific location
{
FILE *tmp;
char found=0,line=0;

if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)	missing_file(TEMP_FILE);
if ((msg=fopen(msgfile,"rt"))==NULL)
	{
	if (!createmsgfile)	missing_file(msgfile);
	}

		// force TAGID kludge
if (!tagid) 	fprintf(tmp,"%c%s",1,TAGID);

if (tag_search_fnd)
	{
	tag_search_fnd--;
	for (junk=0; junk<=tag_search_fnd; junk++)
		{
		if (strstr(tagline,tag_search_replace_find[junk]))
			{
			working("Found match for replace in tag");
			strrepl(tagline,TAGLEN,tag_search_replace_find[junk],tag_search_replace_with[junk]);
			}
		}
	}


while (fgets(dummy,100,msg))
	{
	line++;
	if (strstr(dummy,"@TAG"))
		{
		sprintf(dummy,"Found @TAG marker in line: %d",line);
		working(dummy);
		found=1;
		write_tagline(tmp);
		pick_tag();
		}
		else
		{
		fputs(dummy,tmp);	// not this line, just copy
		}
	}
fclose(tmp);
fclose(msg);

if (!found)
	{
	working("Didn't find @TAG marker\a");
	wait(10);
	working("Appending normally");
	if ((msg=fopen(msgfile,"at"))==NULL)	missing_file(msgfile);
	write_tagline(msg);
	fclose(msg);
	return 1;
	}

if (kill_file(msgfile))		fatal_error("Unable to kill msgfile prior to copying [4]");

if (rename(TEMP_FILE,msgfile))	fatal_error("Unable to copy tempfile to msgfile [4]");

return 0;
}

char * parse_macro(char *flib)
{
struct date d;
struct time t;
char parse_dummy[12];

char *month_name[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
char *day_name[7]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};

memset(dumtag,'\0',TAGLEN);

for (junk=0; junk!=strlen(flib); junk++)
	{
	if (flib[junk]=='@')
		{
			// make it case sensitive
//		switch(toupper(flib[junk+1]))
		switch(flib[junk+1])
			{
			case 'F':
				strcat(dumtag,m_first);
				junk++;
				break;
			case 'L':
				strcat(dumtag,m_last);
				junk++;
				break;
			case 'N':
				strcat(dumtag,m_name);
				junk++;
				break;
			case 'S':
				strcat(dumtag,m_subj);
				junk++;
				break;
			case 'R':
				strcat(dumtag,m_from_name);
				junk++;
				break;
			case 'B':
				strcat(dumtag,"\n");
				junk++;
				break;
			case 'A':
				strcat(dumtag,"        ");
				junk++;
				break;
			case 'Y':
				strcat(dumtag,my_name);
				junk++;
				break;
			case 'T':
				gettime(&t);
				sprintf(dummy,"%.02d:%.02d:%.02d",
								t.ti_hour,
								t.ti_min,
								t.ti_sec);
				strcat(dumtag,dummy);
				junk++;
				break;
			case 'D':
				getdate(&d);
				if (use_longdays)
					{
					sprintf(dummy,"%s %d %s %d",
								day_name[day_of_week(d.da_day,d.da_mon,d.da_year)],
								d.da_day,
								month_name[d.da_mon-1],
								d.da_year);
					}
					else
					{
					sprintf(dummy,"%.02d/%.02d/%.02d",
								d.da_day,
								d.da_mon,
								d.da_year);
					}
				strcat(dumtag,dummy);
				junk++;
				break;
			case 'Q':
				sprintf(dummy,"%d%%",msg_q_pct);
				strcat(dumtag,dummy);
				junk++;
				break;
			case 'P':
				sprintf(dummy,"%lu",tot_tags);
				strcat(dumtag,dummy);
				junk++;
				break;
			case 'Z':
				strcat(dumtag,tagfile);
				junk++;
				break;
			case 'X':
				strcat(dumtag,sigfile);
				junk++;
				break;
			case 'M':	// messagefile
				strcat(dumtag,msgfile);
				junk++;
				break;
			case 'O':
				strcat(dumtag,origmsgfile);
				junk++;
				break;
			case 'K':	// num / mon
				sprintf(dummy,"%d/%d",keep_check_num,keep_check_mon);
				strcat(dumtag,dummy);
				junk++;
				break;
			case 'I':
				strcat(dumtag,origtime);
				junk++;
				break;
			case 'E':
				strcat(dumtag,origdate);
				junk++;
				break;
			case 'G':
				strcat(dumtag,groupID);
				junk++;
				break;
			case 'H':
				strcat(dumtag,echoID);
				junk++;
				break;
			case '1':	//stardate
				getdate(&d);
				sprintf(dummy,"%.2d%.2d.%.2d",(d.da_year-1900),d.da_mon,d.da_day);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '2':
				strcat(dumtag,fromaddr);
				junk++;
				break;
			case '3':
				strcat(dumtag,toaddr);
				junk++;
				break;
			case '4':	// zinger
				if (!strlen(zingstring))
					{
					textbackground(GREEN);
					tm_window(5,10,70,3,WHITE);
					center("� Zinger! �",10);
					textcolor(LIGHTGREEN);
					gotoxy(6,11);
					cprintf("%.65s",flib);
					textcolor(WHITE);
					center("Enter Zinger String",12);
					textattr(WHITE);
					editgets(6,13,zingstring,68,0,0);
					}
				strcat(dumtag,zingstring);
				junk++;
				break;
			case '5':	// quote meter (short)
				junk++;
				if (msg_q_pct < 10)	strcpy(parse_dummy,"[.....]");
				if (msg_q_pct > 10)	strcpy(parse_dummy,"[o....]");
				if (msg_q_pct > 20)	strcpy(parse_dummy,"[O....]");
				if (msg_q_pct > 30)	strcpy(parse_dummy,"[Oo...]");
				if (msg_q_pct > 40)	strcpy(parse_dummy,"[OO...]");
				if (msg_q_pct > 50)	strcpy(parse_dummy,"[OOo..]");
				if (msg_q_pct > 60)	strcpy(parse_dummy,"[OOO..]");
				if (msg_q_pct > 70)	strcpy(parse_dummy,"[OOOo.]");
				if (msg_q_pct > 80)	strcpy(parse_dummy,"[OOOO.]");
				if (msg_q_pct > 90)	strcpy(parse_dummy,"[OOOOo]");
				if (msg_q_pct > 95)	strcpy(parse_dummy,"[OOOOO]");
				strcat(dumtag,parse_dummy);
				break;
			case '6':
				if (msg_q_pct < 10)	strcpy(parse_dummy,"[..........]");
				if (msg_q_pct > 10)	strcpy(parse_dummy,"[O.........]");
				if (msg_q_pct > 20)	strcpy(parse_dummy,"[OO........]");
				if (msg_q_pct > 30)	strcpy(parse_dummy,"[OOO.......]");
				if (msg_q_pct > 40)	strcpy(parse_dummy,"[OOOO......]");
				if (msg_q_pct > 50)	strcpy(parse_dummy,"[OOOOO.....]");
				if (msg_q_pct > 60)	strcpy(parse_dummy,"[OOOOOO....]");
				if (msg_q_pct > 70)	strcpy(parse_dummy,"[OOOOOOO...]");
				if (msg_q_pct > 80)	strcpy(parse_dummy,"[OOOOOOOO..]");
				if (msg_q_pct > 90)	strcpy(parse_dummy,"[OOOOOOOOO.]");
				if (msg_q_pct > 95)	strcpy(parse_dummy,"[OOOOOOOOOO]");
				strcat(dumtag,parse_dummy);
				junk++;
				break;
			case '7':
				junk++;
				strcat(dumtag,VER);
				break;
			case '8':
				junk++;
				sprintf(dummy,"%ld",COMPILE_NO);
				strcat(dumtag,dummy);
				break;
			case '9':
				junk++;
				strcat(dumtag,echodesc);
				break;
			case '0':
				sprintf(dummy,"%d",keep_check_num);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '!':
				sprintf(dummy,"%d",msg_lines);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '"':
				sprintf(dummy,"%d",msg_q_lines);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '�':
				sprintf(dummy,"%d",msg_n_lines);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '$':
				sprintf(dummy,"%d",msg_words);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '%':
				sprintf(dummy,"%d",msg_q_words);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '^':
				sprintf(dummy,"%d",msg_n_words);
				strcat(dumtag,dummy);
				junk++;
				break;
			case '&':
				sprintf(dummy,"%d",msg_size);
				strcat(dumtag,dummy);
				junk++;
				break;
			default:
				sprintf(dummy,"%c",flib[junk]);
				strcat(dumtag,dummy);
				break;
			}
		}
		else
		{
		sprintf(dummy,"%c",flib[junk]);
		strcat(dumtag,dummy);
		}
	}

return dumtag;
}

void get_datfile_name(void)		// resolve file.tag to file.idx
{
memset(DATFILE,'\0',MAXPATH);
for (junk=0; tagfile[junk]!=0; junk++)
	{
	if (junk>MAXPATH)	break;
	if (tagfile[junk]=='.') break;

	DATFILE[junk]=tagfile[junk];
	}

strcat(DATFILE,".IDX");
}

void strip_hi_ascii(void)	// strip tagline from hi-ascii
{
memset(dumtag,'\0',TAGLEN);

for (junk=0; junk!=strlen(tagline); junk++)
	{
	if (tagline[junk]==0)
		{
		dumtag[junk]=0;
		break;
		}
	if ((tagline[junk] < 32) || (tagline[junk] > 126))
		{
		dumtag[junk]='*';
		}
		else
		{
		dumtag[junk]=tagline[junk];
		}
	}

strcpy(tagline,dumtag);
}

void reformat_text(int doall)
{
char new_quote_str[15];

int isq,num_lines=0,already;

int junk1,junk2,junk3;

struct stat statbufr;

working("Reformatting text");

memset(bufarr,'\0',BUFSIZE);
memset(new_quote_str,'\0',15);
memset(quote_str,'\0',15);

if ((msg=fopen(msgfile,"rt"))==NULL)	{ missing_file(msgfile); }

kill_file(TEMP_FILE);

if ((rf_tmp=fopen(TEMP_FILE,"wt"))==NULL)	{ missing_file(TEMP_FILE); }

if (strlen(newheader))
	{
	junk3=0;
	while(fgets(tagline,TAGLEN,msg))
		{
		if (strchr(tagline,'>')) junk3=1;
		}
	if (!junk3) 	strcpy(header,newheader);
	}

rewind(msg);

if (strlen(header))
	{
	fprintf(rf_tmp,"%s\n",parse_macro(header));
	}

	// do random header before rest of message
if (doall)	// otherwise just header and footer
	{
	while (fgets(tagline,TAGLEN,msg))
		{
	//	textcolor(WHITE);
	//	cprintf("Loop...");
		isq=0;
		already=0;
		memset(dumtag,'\0',TAGLEN);

		num_lines++;		// keep count

		rmtrail(tagline);	// strip whitespace at end
		strcat(tagline," ");	// add 1 trailing space

		if (strstr(tagline,"/*"))
			{
			working("Pre-formatted entry");
			if (strlen(bufarr)>3)	rf_write_para();

			fprintf(rf_tmp,"%s\n",tagline);
			while (fgets(tagline,TAGLEN,msg))
				{
				rmtrail(tagline);
				fprintf(rf_tmp,"%s\n",tagline);
				if (strstr(tagline,"*/"))	break;
				}
			}

		if (strlen(tagline)<3)	//blank
			{
			if (strlen(bufarr) > 3)
				{
				rf_write_para();
				already=1;
				}
			}
			else// line contains summat
			{				// check if quoted
			for (junk1=8; junk1!=0; junk1--)
				{
				if (tagline[junk1]=='>')	// it IS!
					{
					isq=1;
					rmlead(tagline);
					break;
					}
				}
			}


		if ((isq) && (!already))
			{	    // copy quote id to new_q_s
			 memset(new_quote_str,'\0',15);

			 for (junk2=0; junk2!=(junk1+1); junk2++)
				 {
				 new_quote_str[junk2]=tagline[junk2];
				 }

			//			cprintf("\n\rOld [%s]  New [%s]\n",old_quote_str,quote_str);
								 // check if same,
			 if (strcmp(new_quote_str,quote_str))
				 {		// not same
	//			 cprintf("\n\rDiff: [%d] [%s] [%s]",junk1,quote_str,new_quote_str);
				 if (strlen(bufarr))
					 {
					 rf_write_para();
					 //already=1;
	//				 cprintf("-");
					 }
				 strcpy(quote_str,new_quote_str);
				 }

							 // copy rest of text to dumtag

			 for (junk2=(junk1+1), junk3=0; tagline[junk2]!='\0'; junk3++, junk2++)
				 {
				 dumtag[junk3]=tagline[junk2];
				 }
			}       		// end isq loop


		if (!already)
			{
			if (isq)
				{
	//			cprintf("app");
				strcat(bufarr,dumtag);

				if (strlen(bufarr) > (BUFSIZE-TAGLEN))
					{
					rf_write_para();
					already=1;
					}
				}
				else
				{
					// not quotes, output verbatim
				fputs(tagline,rf_tmp);
				fputs("\n",rf_tmp);
				}
			}
	//		else
	//		{
	//		cprintf("Already");
	//		}


		}	// end main loop

	if (strlen(bufarr)>3)	rf_write_para();

	}
	else	// just copy every line
	{
	while (fgets(tagline,TAGLEN,msg))	fputs(tagline,rf_tmp);
	}

		// do sig

if (!msg_q_pct)	check_msg_4_tag(0);

if (strlen(footer))	fprintf(rf_tmp,"%s\n",parse_macro(footer));

fcloseall();

kill_file(MSGBACKUPFILE);

if (rename(msgfile,MSGBACKUPFILE))	non_fatal_error("Cannot create backup file");

if (rename(TEMP_FILE,msgfile))	non_fatal_error("Unable to overwrite message file!");


stat(msgfile,&statbufr);

msg_size=statbufr.st_size;		// to check whether it's been edited

sprintf(dummy,"Finished. (%d lines)",num_lines);
working(dummy);
}

void rf_write_para(void)
{
char *taghere, *tagstart, altered=0;
int len;
char orig_quote_str[16];
char block_str[15],junkfed;
char dumster[81],angleseen=0;

memset(dumster,'\0',80);
memset(block_str,'\0',15);

tagstart=bufarr;

if (reformat_tidy)
	{
		// only put ??>> out
	memset(orig_quote_str,'\0',16);

	for (junk=0; junk!=strlen(quote_str); junk++)
		{
		if ((quote_str[junk]!='>') && (!angleseen))
			{
			orig_quote_str[junk]=quote_str[junk];
			}
			else
			{
			if (quote_str[junk]=='>')
				{
				angleseen=1;
				orig_quote_str[junk]=quote_str[junk];
				}
			}
		}
	strcpy(quote_str,orig_quote_str);
	}
		// redo quote-str depending on which option chosen

strcpy(orig_quote_str,quote_str);

if (strlen(quote_str) > 15)
	{
	sprintf(dumster,".14s",quote_str);
	}
	else
	{
	strcpy(dumster,quote_str);
	}


rmlead(dumster);
rmtrail(dumster);
memset(quote_str,'\0',15);

if (quote_style==7)	quote_style=random(7);


switch(quote_style)
	{
	case 0:		// normal
		break;
	case 1: 	// lowercase
		strlwr(dumster);
		altered++;
		break;
	case 2:		// Mixed Case (Sa)
		strlwr(dumster);
		toupper(dumster[0]);
		altered++;
		break;
	case 3:		// Mixed Case (sA)
		strupr(dumster);
		altered++;
		tolower(dumster[0]);
		break;
	case 4:
		dumster[strlen(dumster)]='-';
		altered++;
		strcat(dumster,">");
		break;
	case 5:
		dumster[strlen(dumster)]='=';
		altered++;
		strcat(dumster,">");
		break;
	case 6:
		dumster[strlen(dumster)]='+';
		altered++;
		strcat(dumster,">");
		break;
	case 8:		// filter out alpha
		for (junk=0, junkfed=0; junk!=15; junk++)
			{
			if (dumster[junk]=='>')	break;

			if (isalpha(dumster[junk]))
				{
				block_str[junkfed]=dumster[junk];
				junkfed++;
				}
			}
		strcat(block_str," -|");
		break;
	case 9:
		for (junk=0, junkfed=0; junk!=15; junk++)
			{
			if (dumster[junk]=='>')	break;

			if (isalpha(dumster[junk]))
				{
				block_str[junkfed]=dumster[junk];
				junkfed++;
				}
			}
		strcat(block_str," �");
		break;
	case 10:
		break;
	default:
		strcat(dumster,"?");
		altered++;
		break;
	}

//sprintf(quote_str," %s ",dumster);	       // to get correct spacing

if (strlen(block_str))
	sprintf(quote_str," %s ",block_str);
	else
	sprintf(quote_str," %s ",dumster);


len=strlen(quote_str);

while(strlen(tagstart)>(TAGRMARG-len))
	{

	taghere=tagstart+(TAGRMARG-len);
	while(*taghere!=' ' && taghere>tagstart) taghere--;
	*taghere=0;
	fprintf(rf_tmp,"%s%s\n",
				quote_str,
				tagstart);

	if (quoteblank)
		{
		for (junk=0; junk!=strlen(quote_str)-2; junk++)
			{
			if (junk <0) break;
			quote_str[junk]=' ';
			}
		if (quote_style==8) 	quote_str[(strlen(quote_str)-2)]='|';
		if (quote_style==9)	quote_str[(strlen(quote_str)-2)]='�';

		}

	tagstart=taghere+1;
	}

fprintf(rf_tmp,"%s%s\n\n",quote_str,tagstart);

if (ferror(rf_tmp))
	{
	textattr(RED);
	sprintf(dummy,"An error occured writing to reformat temp file: %s\r\n",TEMP_FILE);
	quit(555,dummy);
	}

memset(bufarr,'\0',BUFSIZE);

if (altered)	strcpy(quote_str,orig_quote_str);
}

void do_extra_banner(char *txt)
{
int oldy=wherey();

textbackground(BLUE);
textcolor(LIGHTCYAN);

gotoxy(3,4);
cprintf("Function: [%s]",txt);

gotoxy(1,oldy);
}
				// draw non-shadowed box
void tm_window(int tlx,int tly,int width,int height,int col)
{
int jj=(tly+1);
int winjunk,winjunk2;

textcolor(col);
gotoxy(tlx,tly);

cprintf("�");
for (winjunk=0; winjunk!=(width-2); winjunk++)	{ cputs("�"); }
cputs("�");

for (winjunk = 0;winjunk != height;winjunk++)
	     {
	     textcolor(col);
	     gotoxy(tlx,jj);
	     cputs("�");
	     for (winjunk2=0; winjunk2!=(width-2); winjunk2++)	{ cputs(" "); }
	     cputs("�");
	     jj++;
	     }

textcolor(col);
gotoxy(tlx,jj);
cputs("�");
for (winjunk=0; winjunk!=(width-2); winjunk++)	{ cputs("�"); }
cputs("�");
}

char *rmtrail(char *lin)
{
junk=strlen((char *)lin);

while(junk >=0)
	{
	junk--;
	if (!isspace(lin[junk])) break;
	lin[junk]='\0';
	}

return (char*)lin;
}

char *rmlead(char *str)
{
char *obuf;

for (obuf=str; obuf && *obuf && isspace(*obuf); ++obuf)
	;
if ((char *)str !=obuf)		strcpy((char*)str,obuf);

return str;
}


void load_dat(void)
{
FILE *dat;

if ((dat=fopen(DATFILE,"rb"))!=NULL)
	{
	fscanf(dat,"%lu,%lu,%lu,%lu",				// huh?
					&last_tag,
					&last_tag,
					&last_tag,
					&last_tag);
	fclose(dat);
	}
}

void fatal_error(char *reason)
{
textattr(LIGHTRED);
cprintf("\r\nFatal Error: [%s]\r\n\n",reason);
textattr(WHITE);
cputs(  "The most likely reason for this error is that a file has been set as\r\n"
	"read-only and T-Matic cannot delete it. If this isn't the case,\r\n"
	"please netmail the author with the EXACT errormessage and what you\r\n"
	"were doing when it appeared.\r\n\n\a");
wait(50);
quit(18,"Fatal Error");
}
void non_fatal_error(char *reason)
{
textattr(BROWN);
tm_window(5,5,70,5,WHITE);
textattr(RED);
sprintf(dummy,"Non-Fatal-Error: [%s]",reason);
center(dummy,6);
textattr(WHITE);
center("Although this error is not serious enough to halt T-Matic,",8);
center("it may produce unwanted results. If this error persists, please ",9);
center("rectify it, or netmail the author.",10);

wait(60);
}
				// kill a file, even if RO
int kill_file(char *filnm)
{
int amode;

amode = S_IREAD|S_IWRITE;

chmod(filnm,amode);

return (unlink(filnm));
}

void pick_new_tagfile(void)	//scrolly pick-list of *.TAG
{
char *savebuf;

if ((savebuf=(char *)malloc(5000))==NULL)	quit(18,"Out of memory (pick_new_tagfile())");

gettext(1,1,80,25,savebuf);

strcpy(tagfile,FileSelect("*.TAG","Pick Tagfile",BLUE,WHITE,18,60,4,18));

puttext(1,1,80,25,savebuf);
free(savebuf);
}

void pick_new_sigfile(void)	//scrolly pick-list of *.1
{
char *savebuf;

if ((savebuf=(char *)malloc(5000))==NULL)	quit(18,"Out of memory (pick_new_sigfile())");

gettext(1,1,80,25,savebuf);

strcpy(dummy,FileSelect("*.1","Pick SigfileSet",BLUE,WHITE,18,60,4,18));

for (junk=0; junk!=strlen(dummy); junk++)	// trim suffix
	{
	if (dummy[junk]=='.')	break;
	if (dummy[junk]=='\0')	break;
	sigfile[junk]=dummy[junk];
	}
sigfile[junk]='\0';

puttext(1,1,80,25,savebuf);
free(savebuf);
}

					// new for v.12 - uses gen_tag()
					// to copy new tagline into char *tagline
					// for menu-creation
void tag_gen(void)
{
FILE *out;
//time_t first,second;
//double seconds1;
int c;

do_extra_banner("Spewtag");

textattr(YELLOW);
cprintf("Creating [%lu] taglines...\r\n",tot_tags);

//first=time(NULL);

	if ((out=fopen(tagfile,"at"))==NULL)		missing_file(tagfile);

for (;;)
	{
	textattr(LIGHTBLUE);
	cprintf("\rDone: [%lu]   Left: [%lu]   Total: [%lu]   ",
						last_tag,
						(tot_tags-last_tag),
						tot_tags);
	gen_tag();

	fprintf(out,"%s\n",tagline);

	fflush(out);
//	fclose(datfp);		// it wasn't closing properly for some reason  13/12/96
	last_tag++;

	if (last_tag>=tot_tags)	break;

		// check to see if esc hit
	if (bioskey(1))
		{
		c=bioskey(0);
		if (c==ESC)
			{
			quit(1,"Esc pressed in Tag_Gen routine");
			}
		}
	}

fclose(out);

textattr(WHITE);

//second=time(NULL);
cputs("\r\nSpewtag complete.\r\n");

//(double) seconds1=difftime(second,first);

//textattr(YELLOW);
//cprintf("[%lu] tags. [%.2f] seconds. [%d] tags / second.\r\n",tot_tags,seconds1,tot_tags/seconds1);
textattr(WHITE);
sprintf(dummy,"Finished. [%lu] taglines created",tot_tags);
cputs(dummy);
wait(30);
quit(0,dummy);
}


void gen_tag(void)
{
long oldpos;
int y,jnk;

fclose(datfp);

if ((datfp=fopen(spewfile,"rt"))==NULL)		missing_file(spewfile);

memset(dumtag,'\0',TAGLEN);
memset(tagline,'\0',TAGLEN);

while (dumtag[0]!='%')
	{
	fgets(dumtag,TAGLEN,datfp);
	if (feof(datfp))
		{
		fclose(datfp);
		strcpy(tagline,"Error in Spewtag - EOF");
		return;
		}
	}
				// skip to first *

for (;;)
	{
	for (;;) 		// find first.
		{
		fgets(dumtag,TAGLEN,datfp);
		if (dumtag[0]=='*')	break;
		if (feof(datfp))
			{
			if (strlen(tagline))	return;

			fclose(datfp);
			strcpy(tagline,"Error in Spewtag - Can't find '*'");
			return;
			}
		}

	rmtrail(dumtag);

	for (junk=1, jnk=strlen(tagline); junk<=(strlen(dumtag)); junk++, jnk++)
		{
		tagline[jnk]=dumtag[junk];
		}

	tagline[jnk]='\0';

	oldpos=ftell(datfp);

	for (y=0;;y++)
		{
		fgets(dumtag,TAGLEN,datfp);
		if (feof(datfp))
			{
			if (strlen(tagline))	return;

			fclose(datfp);
			strcpy(tagline,"Error in Spewtag - Can't find '*' [2]");
			return;
			}
		if (dumtag[0]=='*')
			{
			y--;
			break;
			}
		}
	fseek(datfp,oldpos,SEEK_SET);

	jnk=(random(y)+1);

	for (junk=0; junk<=jnk; junk++)
		{
		fgets(dumtag,TAGLEN,datfp);
		}

	rmtrail(dumtag);

//	strcat(taglines,dumtag);

	if ((strlen(dumtag) + (strlen(tagline)) > TAGLEN))	strcpy(tagline,"This tagline was too long");
				// appnd rand sel to tagline
	if (strlen(dumtag))	strcat(tagline,dumtag);

	if (ferror(datfp))		break;
	if (feof(datfp))		break;
	}

fclose(datfp);
}


void working(char *str)
{
textattr(BROWN);
gotoxy(1,8);                               //
cputs("                                    ");
gotoxy(1,8);
cprintf("%.36s",str);
}

/*void silly_man(void)
{
int junk;

textbackground(GREEN);
tm_window(37,10,7,4,LIGHTGREEN);
textcolor(WHITE);
gotoxy(39,10);
cputs(" Hi! ");
gotoxy(40,11);
cprintf("");
gotoxy(39,12);
cprintf("/�\\");
gotoxy(40,13);
cprintf("�");
gotoxy(39,14);
cprintf("/ \\");

for (junk=0; junk!=15; junk++)
	{
	sound(400);
	delay(5);
	nosound();
	gotoxy(41,12);
	cprintf(" ");
	gotoxy(41,11);
	cprintf("/");
	delay(100);
	gotoxy(41,11);
	cprintf(" ");
	gotoxy(41,12);
	cprintf("\\");
	delay(100);
	}
}
  */

void scrollit(void)			// scroll msg, and show clock
{
int junk;
char ch;

struct time t;
struct date d;

char *month_name[12]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
char *day_name[7]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};

scroll_n++;

gettime(&t);
getdate(&d);

if (scroll_n>11)
	{
	scroll_n=0;

	textcolor(WHITE);
	textbackground(BLUE);

	for(junk=36; junk!=48; junk++)
	       {
	       ch=scr_in(junk,10);

//	       if (junk > 36)
//		       {
		       gotoxy(junk-1,10);
		       cprintf("%c",ch);
//		       gotoxy(1,1);
//		       cprintf("%c",ch);
//		       }
	       }

	gotoxy(47,10);
	cprintf("%c",scroll_msg[scroll_x]);

	scroll_x++;

	if (scroll_x > strlen(scroll_msg))      scroll_x=0;

	textbackground(BLUE);
	textcolor(WHITE);

	gotoxy(39,19);
	cprintf("%.02d:%.02d.%.02d",
					t.ti_hour,
					t.ti_min,
					t.ti_sec
					);

	textcolor(LIGHTGRAY);
	gotoxy(34,20);
	cprintf("%s %d %s %d",
				day_name[day_of_week(d.da_day,d.da_mon,d.da_year)],
				d.da_day,
				month_name[d.da_mon-1],
				d.da_year
				);

	scr_saver_second=time(NULL);

	if (scr_saver_delay)
		{
		if ((difftime(scr_saver_second,scr_saver_first)) >= scr_saver_delay)
			{
			screen_saver();
			}
		}

	}

delay(10);
}


void draw_tm_box(void)
{
int jnk;

textattr(BLACK);
clrscr();

textbackground(BLUE);
textcolor(LIGHTCYAN);

		// draw box
gotoxy(1,1);
memset(dummy,'\0',100);
strcat(dummy,"�");
for (jnk=0;jnk!=78;jnk++)       { strcat(dummy,"�"); }
strcat(dummy,"�");

raster_str(dummy,BLUE);

gotoxy(1,2);
clreol();
textcolor(random(14)+1);
cputs("�");
gotoxy(80,2);
textcolor(random(14)+1);
cputs("�");
gotoxy(1,3);
clreol();
textcolor(random(14)+1);
cputs("�");
gotoxy(80,3);
textcolor(random(14)+1);
cputs("�");
gotoxy(1,4);
clreol();
textcolor(random(14)+1);
cputs("�");
gotoxy(80,4);
textcolor(random(14)+1);
cputs("�");

memset(dummy,'\0',100);
strcat(dummy,"�");
for(jnk=0;jnk!=78;jnk++)        { strcat(dummy,"�");}
strcat(dummy,"�");
gotoxy(1,5);
clreol();
raster_str(dummy,BLUE);

memset(dummy,'\0',100);

textcolor(YELLOW);
sprintf(dummy,"\n%s %s  Copyright %s Simon Avery. Build #%ld\n",NAME,VER,__DATE__,COMPILE_NO); // Say hello
center(dummy,1);

}

void untag(void)			// remove any tags from msg
{
FILE *tmp;

char found;

do_extra_banner("UnTag-O-Matic");

tot_tags=0L;

if ((msg=fopen(msgfile,"rt"))==NULL)		missing_file(msgfile);
if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)		missing_file(TEMP_FILE);

while (fgets(tagline,TAGLEN,msg))
	{
	found=0;

	if ((tagline[0]=='.') && (tagline[2]=='.'))	{ tot_tags++; found++; }
			// also rem any t-matic IDs
	if (strstr(tagline,TAGID))			{ found++; }

	if (strstr(tagline,NAME))			{ found++; }

	if (!found)					{ fputs(tagline,tmp); }
	}

fclose(tmp);
fclose(msg);

if (kill_file(msgfile))			fatal_error("Unable to delete original msgfile");

if (rename(TEMP_FILE,msgfile))		fatal_error("Unable to rename tempfile to msgfile");

sprintf(dummy,"Untag Finished. [%lu] taglines removed.",tot_tags);

quit(0,dummy);
}

void execute(char *str)
{
char where[MAXPATH];
int rslt;

strcpy(where,getenv("COMSPEC"));

textbackground(BLACK);
clrscr();
draw_tm_box();

if (!nocuursoronexit) 	_setcursortype(_NORMALCURSOR);

do_extra_banner("Running External Program");

textattr(WHITE);
gotoxy(1,7);

cprintf("Execute string: [%s /c %s]\r\n",where,str);
cprintf("Mem left in current block prior to swapping out : [%lu]\r\n",coreleft());
//cprintf("Mem left overall prior to swapping out          : [%lu]\r\n",farcoreleft());

//wait(1);
		// see men-yoo.c for details on usage
//result=spawnlo(path_d,where,where,"/c",thing,NULL);
//result=spawnlo (".", where, where, "/c", thing, NULL);
	// this one
if (swapout)
	{
	rslt=spawnlo (".", where, where, "/c", str, NULL);
	}
	else
	{
	rslt=system(str);
	}
//spawnlo (".", where, where, "/c", str, msgfile);

//if (_doserrno)
if (rslt)
	{
	sprintf(dummy,"Program returned an error level of [%d] [%s] [%d]\a",errno,sys_errlist[errno],rslt);
	box_error(dummy);
	wait(60);
	}

_setcursortype(_NOCURSOR);
display_image(1);
init_prompt_show();
}

void hands_free(void)
{
textattr(WHITE);
cputs("Hands-Free mode...\r\n");
cprintf("Message File: [%s]\r\n",msgfile);
cprintf("Config  File: [%s]\r\n",CFGFILE);

read_config(CFGFILE);

if ((!access("MSGINFO.SYS",0)) && (usemsginfo))	// it exists
	{ read_msginfo(); }
	else
	{ if (use_macros)		read_macros(msgfile); }

textattr(WHITE);
cprintf("Tagline File: [%s]\r\n",tagfile);

check_msg_4_tag(1);      // if find a tagline, abort

count_taglines();

pick_tag();

cprintf("Found tag worthy of this message:\r\n");
textattr(YELLOW);
cprintf("%s %.75s\r\n",TAGPREFIX,tagline);

if ((tagid) && (tagid!=3))	do_tagid(1);	// add tagid if req'd

if ((msg=fopen(msgfile,"at"))==NULL)		missing_file(msgfile);

if (addsig)	do_sig();

if (trailing_cr)	fprintf(msg,"\n");

if (tag_locate)
	{
	fclose(msg);
	write_tag_located();

	if ((msg=fopen(msgfile,"at"))==NULL)
		{
		missing_file(msgfile);
		}
	}
	else	// standard append tag
	{
	write_tagline(msg);
	}

if (strlen(lotterystr))
	{
	fprintf(msg,"-$- %s %d %d %d %d %d %d\n",
					lotterystr,
					random(8)+1,
					random(8)+9,
					random(8)+17,
					random(8)+25,
					random(8)+33,
					random(8)+42);
	}
		// either 0 or 1,2 or 3
if ((tagid!=1) && (tagid!=3))
	{
	if (use_macros)
		{ fprintf(msg,"%.76s",parse_macro(tearline)); }
		else
		{ fprintf(msg,"%.76s",tearline); }
	}

fclose(msg);

quit(0,"All done!");
}

			// does 9, not 10 - cos it tends to run out of mem

void pick_multiple_tags(void)
{
char *tag0,*tag1,*tag2,*tag3,*tag4,*tag5,*tag6,*tag7,*tag8,*tag9;
//char *tag9;
char ab=1;
int c,flab;

if ((tag0=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(0))");
if ((tag1=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(1))");
if ((tag2=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(2))");
if ((tag3=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(3))");
if ((tag4=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(4))");
if ((tag5=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(5))");
if ((tag6=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(6))");
if ((tag7=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(7))");
if ((tag8=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(8))");
if ((tag9=(char *)malloc(TAGLEN))==NULL)	quit(18,"Out of memory (pick_multiple_tags(9))");


pick_tag();
strcpy(tag0,tagline);
pick_tag();
strcpy(tag1,tagline);
pick_tag();
strcpy(tag2,tagline);
pick_tag();
strcpy(tag3,tagline);
pick_tag();
strcpy(tag4,tagline);
pick_tag();
strcpy(tag5,tagline);
pick_tag();
strcpy(tag6,tagline);
pick_tag();
strcpy(tag7,tagline);
pick_tag();
strcpy(tag8,tagline);
pick_tag();
tag9=tagline;

textbackground(BLUE);
tm_window(1,6,80,10,WHITE);

gotoxy(3,6);
cputs("� Pick Tagline �");

for (;;)
	{
	if (ab>10)       	ab=1;
	if (ab<1)        	ab=10;

		// print menu
	textbackground(BLUE);
	textcolor(LIGHTCYAN);

	gotoxy(2,7);
	cprintf("%.78s",tag0);
	gotoxy(2,8);
	cprintf("%.78s",tag1);
	gotoxy(2,9);
	cprintf("%.78s",tag2);
	gotoxy(2,10);
	cprintf("%.78s",tag3);
	gotoxy(2,11);
	cprintf("%.78s",tag4);
	gotoxy(2,12);
	cprintf("%.78s",tag5);
	gotoxy(2,13);
	cprintf("%.78s",tag6);
	gotoxy(2,14);
	cprintf("%.78s",tag7);
	gotoxy(2,15);
	cprintf("%.78s",tag8);
	gotoxy(2,16);
	cprintf("%.78s",tag9);

	textbackground(BLUE);
	textcolor(WHITE);

	for (flab=0; flab!=10; flab++)
		{
		gotoxy(1,flab+7);
		cputs("�");
		}

	for (flab=0; flab!=10; flab++)
		{
		gotoxy(80,flab+7);
		cputs("�");
		}

	textbackground(LIGHTGRAY);
	textcolor(BLUE);
	gotoxy(1,ab+6);
	cputs(">");
	gotoxy(80,ab+6);
	cputs("<");

	c=getkc();

	switch(c)
		{
		case LEFT:
		case ESC:
			free(tag0);
			free(tag1);
			free(tag2);
			free(tag3);
			free(tag4);
			free(tag5);
			free(tag6);
			free(tag7);
//			free(tag8);
//			puttext(1,1,80,25,IMAGEDATA);
			display_image(1);
			return;
		case UP_ARROW:
			ab--;
			break;
		case DOWN_ARROW:
			ab++;
			break;
		case HOME:
			ab=15;
			break;
		case END:
			ab=0;
			break;
		case RIGHT:
		case ENTER:
		case C_ENTER:
		case SPACE:              	// second menu
			switch(ab)
				{
				case 1:
					strcpy(tagline,tag0);
					break;
				case 2:
					strcpy(tagline,tag1);
					break;
				case 3:
					strcpy(tagline,tag2);
					break;
				case 4:
					strcpy(tagline,tag3);
					break;
				case 5:
					strcpy(tagline,tag4);
					break;
				case 6:
					strcpy(tagline,tag5);
					break;
				case 7:
					strcpy(tagline,tag6);
					break;
				case 8:
					strcpy(tagline,tag7);
					break;
				case 9:
					strcpy(tagline,tag8);
					break;
				case 10:	// tagline already in use
					break;
				default:
					strcpy(tagline,"Error in multiple-pick routine");
					break;
				}
//			puttext(1,1,80,25,IMAGEDATA);
			display_image(1);
			free(tag0);
			free(tag1);
			free(tag2);
			free(tag3);
			free(tag4);
			free(tag5);
			free(tag6);
			free(tag7);
			free(tag8);
			return;
		}
	sound(600);
	delay(5);
	nosound();
	}
}

void check_4_twit(void)
{
UCHAR gghi;
char dummy2[60];

for (gghi=0; gghi!=twits_fnd; gghi++)
	{
//	if (!strcmpi(twitname[gghi],m_name))
	if (strstr(m_name,twitname[gghi]))
		{
		working("Found Twit!");
		strcpy(CFGFILE,twitcfg[gghi]);
		read_config(CFGFILE);
		sprintf(dummy2,"-I- Found Twit: %s",m_name);
//		write_log(dummy2);
		}
//	textattr(LIGHTRED+BLINK);
//	cprintf("\r\n[%s] in [%s]",twitname[gghi],m_name);
//	wait(10);
	}
/*
	textattr(WHITE+BLINK);
	cprintf("\r\n[%s] in [%s] [%d]",twitname[0],m_name,twits_fnd);
	wait(10);
	textattr(WHITE+BLINK);
	cprintf("\r\n[%s] in [%s]",twitname[1],m_name);
	wait(10);
*/
for (gghi=0; gghi!=twittags_fnd; gghi++)
	{

	if (strstr(m_name,twittag[gghi]))
		{
		working("Found Twit! - Tagfile");
		strcpy(tagfile,twittagcfg[gghi]);
		sprintf(dummy2,"-I- Found TwitTag: %s",m_name);
//		write_log(dummy2);
		}
	}

for (gghi=0; gghi!=vanillas_fnd; gghi++)
	{
//	gotoxy(1,1); printf("%d",gghi);
//	wait(1);
	if (strstr(m_name,vanilla_bod[gghi]))
		{
		working("Vanilla Entry found!");
//		wait(5);
		addsig=0; tagid=1; trailing_cr=0;
		usetag=0; goto_scrolly=0;

		memset(header,'\0',100);
		memset(footer,'\0',100);
		memset(lotterystr,'\0',40);
		sprintf(dummy2,"-I- Vanilla Entry: %s",m_name);
//		write_log(dummy2);

		}
	}
}




void donetag(void)		// move tag from tagfile to donetags.tag
{
FILE *duntmp;
FILE *tagfp;
FILE *destag;

working("Moving tag to DONETAGS.TAG");

if ((duntmp=fopen(DONETAGFILE,"at"))==NULL)	missing_file(DONETAGFILE);
if ((tagfp=fopen(tagfile,"rt"))==NULL)		missing_file(tagfile);
if ((destag=fopen(TEMP_FILE,"wt"))==NULL)	missing_file(TEMP_FILE);
		// write tagline to tagfile
fprintf(duntmp,"%s\n",tagline);
fclose(duntmp);

while (fgets(dumtag,TAGLEN,tagfp))		// main loop
	{
	rmtrail(dumtag);
	if (strcmp(dumtag,tagline))		fprintf(destag,"%s\n",dumtag);
	}

fclose(destag);
fclose(tagfp);

kill_file(tagfile);

if (rename(TEMP_FILE,tagfile))			quit(39,"Error renaming TEMP_FILE to tagfile!");


}

void steal_mood(void)
{
FILE *moodfp;
int count=0,lincnt=0;

do_extra_banner("Moody-bLose");

if ((msg=fopen(msgfile,"rt"))==NULL)		missing_file(msgfile);
if ((moodfp=fopen(tagfile,"at"))==NULL)		missing_file(tagfile);

textattr(WHITE);

while (fgets(tagline,TAGLEN,msg))
	{
	if ((tagline[0]==1) && (strstr(tagline,"MOOD:")))
		{
		memset(dumtag,'\0',TAGLEN);

		for (junk=7; junk<=strlen(tagline); junk++)
			{
			dumtag[junk-7]=tagline[junk];
			}
		fprintf(moodfp,"%s",dumtag);
		cprintf("Stolen: %s\r",dumtag);
		count++;
		}
	lincnt++;
	}

fclose(moodfp);
fclose(msg);

sprintf(dummy,"I stole [%d] moods from this message. %d Lines",count,lincnt);
cprintf(dummy);
wait(5);
quit(0,dummy);
}


void move_to_end(void)
{
FILE *in,*tmp;
char movingstr[10][83];
char movecnt=0,found,totfound=0;

movetoendcnt--;

for (junk=0; junk!=10; junk++)	memset(movingstr[junk],'\0',83);

working("Moving strings to end of msg");

if ((in=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);
if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)	missing_file(TEMP_FILE);

while (fgets(dumtag,TAGLEN,in))
	{
	found=0;
	for (junk=0; junk<=movetoendcnt; junk++)
		{
		if (strstr(dumtag,movetoendstr[junk]))
			{
			sprintf(dummy,"Moving [%.15s]",movetoendstr[junk]);
			working(dummy);
			strcpy(movingstr[movecnt],dumtag);
			movecnt++;
			found++;
			totfound++;
			}
		}
	if (!found)	fputs(dumtag,tmp);
	}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!
if (trailing_cr)
	{
	fputs("\n",tmp);	// otherwise it appends original tearline to end of
	}
	else
	{
	if ((tagid==2) || (!tagid)) fputs("\n",tmp);	// otherwise it appends original tearline to end of
	}
			// t-matic's.

//if (movecnt)
//	{
//	fputs("\n",tmp);
//	movecnt--;
//	}

for (junk=0; junk!=movecnt; junk++)
	{
	fputs(movingstr[junk],tmp);
	}

fclose(in);
fclose(tmp);

if (totfound)
	{
	if (kill_file(msgfile))		fatal_error("Unable to delete message file prior to copying temp file across [9]");

	if (rename(TEMP_FILE,msgfile))	fatal_error("renaming tempfile to msgfile [9]");
	sprintf(dummy,"Moved [%d] strings",movecnt+1);
	}
	else
	{
	(kill_file(TEMP_FILE));
	strcpy(dummy,"No matching strings moved");
	}

working(dummy);
}

int c_break(void)
{
quit(98,"Control-Break pressed.  T-Matic Aborting.");
return 1;
}

		// check ID hasn't been removed
void check_for_tagid(void)
{
UCHAR fnd=0;

if ((msg=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);

while (fgets(dumtag,TAGLEN,msg))
	{
	if (strstr(dumtag,NAME))
		{ fnd=1; break; }
	if (strstr(dumtag,".:."))
		{ fnd=1; break; }
	}
fclose(msg);

if (!fnd)
	{
	box_error("No T-Matic ID found! Adding it! ')");
	do_tagid(0);
	wait(10);
	}
}


int mouseclick()                      /* see if mouse buttons were clicked */
{
   int click = 0;
   union REGS inregs;
   union REGS outregs;
   inregs.x.ax = 5;
   inregs.x.bx = 1;
   int86(0x33,&inregs,&outregs);
   click = outregs.x.bx << 1;
   inregs.x.bx--;
   int86(0x33,&inregs,&outregs);
   return(click | outregs.x.bx);
}

int mousecheck()                      /* see if mouse exists, & # of buttons */
{
   union REGS inregs;
   union REGS outregs;
   inregs.x.ax = 0;
   int86(0x33,&inregs,&outregs);
   return(outregs.x.ax ? outregs.x.bx : 0);
}

void screen_saver(void)
{
int junkie,x,y;
struct time ti;

nosound();
while (!bioskey(1))
	{
	textattr(WHITE);
	clrscr();
	junk=random(15)+1;
	junkie=random(7)+1;
	x=random(68)+1;
	y=random(22)+1;

	textbackground(junkie);
	tm_window(x,y,12,1,junk);
	gotoxy(x+2,y+1);
	gettime(&ti);
	cprintf("%.2d:%.2d:%.2d",ti.ti_hour,ti.ti_min,ti.ti_sec);
	sleep(2);
	}

bioskey(0);
scr_saver_first=time(NULL);
//puttext(1,1,80,25,IMAGEDATA);
display_image(1);
init_prompt_show();
}

void display_image(int number)
{
FILE *scr;
char *scrbuf;


number--;

if ((scrbuf=(char *) malloc(4001))==NULL)	quit(99,"Ran out of memory (display_image)");
if ((scr=fopen(SCREENDATFILE,"rb"))==NULL)	missing_file(SCREENDATFILE);

fseek(scr,(4000*number),SEEK_SET);

if (!fread(scrbuf,4000,1,scr))
	{
	non_fatal_error("Unable to load correct image!");
	return;
	}

puttext(1,1,80,25,scrbuf);

free(scrbuf);
fclose(scr);
}


void check_msg_4_search(void)
{
FILE *in,*out;
UCHAR rep_found=0;
UCHAR dummy2[TAGLEN];

if (msg_search_fnd)
	{
	working("Checking msg for search/replace");

	if (f5invoked)
		{
		working("F5 hit - ignoring");
		return;
		}

	if ((in=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);
	if ((out=fopen(TEMP_FILE,"wt"))==NULL)	missing_file(TEMP_FILE);

	while (fgets(dummy2,TAGLEN,in))
		{
		if (msg_search_fnd)
			{
			for (junk=0; junk<=(msg_search_fnd-1); junk++)
				{
				if (strstr(dummy2,msg_search_replace_find[junk]))
					{
					working("Found match for replace in msg");
					strrepl(dummy2,TAGLEN,msg_search_replace_find[junk],msg_search_replace_with[junk]);
					rep_found=1;
					}
				}
			}
		if (parse_replaced)
			fprintf(out,"%s",parse_macro(dummy2));
			else
			fputs(dummy2,out);
		}
	fclose(in);
	fclose(out);

	if (rep_found)
		{
		kill_file(msgfile);
		if (rename(TEMP_FILE,msgfile))	quit(34,"Unable to rename Temp file to msgfile");
		}
		else
		{
		kill_file(TEMP_FILE);
		}
	}
}

		// split files to certain size.
void check_key_abort(void)
{
if (bioskey(1))	if (getkc()==ESC)	quit(1,"Escape was pressed!");
}


/*int write_tag_b4_tear(void)	// locate a tagline immediately before the tearline
{
FILE *tmp;
char found=0,line=0,thisline=0;

if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)	missing_file(TEMP_FILE);
if ((msg=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);

		// force TAGID kludge
if ((!tagid) && (tagid!=3)) 	fprintf(tmp,"%c%s",1,TAGID);

if (tag_search_fnd)
	{
	tag_search_fnd--;
	for (junk=0; junk<=tag_search_fnd; junk++)
		{
		if (strstr(tagline,tag_search_replace_find[junk]))
			{
			working("Found match for replace in tag");
			strrepl(tagline,TAGLEN,tag_search_replace_find[junk],tag_search_replace_with[junk]);
			}
		}
	}


while (fgets(dummy,100,msg))
	{
	line++;

	thisline=0;

	if ((dummy[0]=='-') &&(dummy[1]=='-') &&(dummy[2]=='-'))	thisline=1;
	if ((dummy[0]=='_') &&(dummy[1]=='_') &&(dummy[2]=='_'))        thisline=1;

	if (thisline)
		{
		sprintf(dummy,"Found tearline at line: %d",line);
		working(dummy);
		found=1;
		write_tagline(tmp);
		fputs(dummy,tmp);
		}
		else
		{
		fputs(dummy,tmp);	// not this line, just copy
		}
	}
fclose(tmp);
fclose(msg);

if (!found)
	{
	working("Didn't find tearline\a");
	wait(10);
	working("Appending normally");
	if ((msg=fopen(msgfile,"at"))==NULL)	missing_file(msgfile);
	write_tagline(msg);
	fclose(msg);
	return 1;
	}

if (kill_file(msgfile))		fatal_error("Unable to kill msgfile prior to copying [4]");

if (rename(TEMP_FILE,msgfile))	fatal_error("Unable to copy tempfile to msgfile [4]");

return 0;
}
*/
void write_string(FILE *tmp, char *str)		// with proper word-wrap
{
char *taghere, *tagstart;
int true_rmarg=(TAGRMARG-4);		// to allow for precursor

tagstart=str;
		// main word-wrap routine
while (strlen(tagstart)>true_rmarg)
	{
	/* The tagline needs formatting */
	taghere=(tagstart+true_rmarg);
	while (*taghere!=' ' && taghere>tagstart) taghere--;
	*taghere=0;
	fprintf(tmp,"%s\n",tagstart);
	tagstart=taghere+1;
	}

fprintf(tmp,"%s\n",tagstart);
}

char yesno(void)
{
char ch=2;

goto again;

again:
;

switch(getch())
	{
	case 'y':
	case 'Y':
	case 13:	// CR
		ch=1;
		break;
	case 'n':
	case 'N':
	case '.':
	case 27:	       // esc
		ch=0;
		break;
	default:
		goto again;
	}

if (ch==2)	{ yesno(); }

return ch;
}


void pick_new_sigfile_exact(void)	//scrolly pick-list of [sigfile].*
{
//char *savebuf;

if (strchr(sigfile,'.'))
	{
	for (junk=0; junk!=strlen(sigfile); junk++)
		{
		if (sigfile[junk]=='\0')	break;
		if (sigfile[junk]=='.')		sigfile[junk]='\0';
		}
//	strcat(sigfile,".*");
	}

sprintf(dummy,"%s.*",sigfile);

//if ((savebuf=(char *)malloc(5000))==NULL)	quit(18,"Out of memory (pick_new_sigfile_exact())");

//gettext(1,1,80,25,savebuf);

strcpy(sigfile,FileSelect(dummy,"Pick Sigfile",BLUE,WHITE,18,60,4,18));

//puttext(1,1,80,25,savebuf);

//free(savebuf);
}
/*
void write_log(char *txt)
{
FILE *logfp;
struct date d;
struct time t;
if (strlen(logfile))
	{
	if ((logfp=fopen(logfile,"at"))!=NULL)
		{
		getdate(&d);
		gettime(&t);
		fprintf(logfp,"%.2d/%.2d/%d %.2d:%.2d.%.2d  %s\n",
				d.da_day,
				d.da_mon,
				d.da_year-1900,
				t.ti_hour,
				t.ti_min,
				t.ti_sec,
				txt);
		fclose(logfp);
		}
	}
} */

void change_quotes(void)
{
int junk1,junk2,junk3;
char *taghere, *tagstart, altered=0, isq,already;
int len,num_lines=0;
char orig_quote_str[16];
char block_str[15],junkfed;
char dumster[81],angleseen=0;
working("Re-quoting text");

memset(quote_str,'\0',15);

if ((msg=fopen(msgfile,"rt"))==NULL)	{ missing_file(msgfile); }

kill_file(TEMP_FILE);
if ((rf_tmp=fopen(TEMP_FILE,"wt"))==NULL)	{ missing_file(TEMP_FILE); }

while (fgets(tagline,TAGLEN,msg))
	{
	isq=0;
	already=0;
	memset(dumtag,'\0',TAGLEN);

	num_lines++;		// keep count
	rmtrail(tagline);	// strip whitespace at end

	if (strlen(tagline)<3)
		{
		fputs("\n",rf_tmp);//blank
		already=1;
		}
		else// line contains summat
		{				// check if quoted
		for (junk1=8; junk1!=0; junk1--)
			{
			if (tagline[junk1]=='>')	// it IS!
				{
				isq=1;
				rmlead(tagline);
				break;
				}
			}
		}


	if ((isq) && (!already))
		{	    // copy quote id to new_q_s

		memset(quote_str,'\0',15);

		for (junk2=0; junk2!=(junk1+1); junk2++)
			 {
			 quote_str[junk2]=tagline[junk2];
			 }

		//			cprintf("\n\rOld [%s]  New [%s]\n",old_quote_str,quote_str);
							 // check if same,

						 // copy rest of text to dumtag

		 for (junk2=(junk1+1), junk3=0; tagline[junk2]!='\0'; junk3++, junk2++)
			 {
			 dumtag[junk3]=tagline[junk2];
			 }
		}       		// end isq loop


	if (!already)
		{
		if (isq)
			{
			memset(dumster,'\0',80);
			memset(block_str,'\0',15);

			tagstart=dumtag;

			if (reformat_tidy)
				{		// only put ??>> out
				memset(orig_quote_str,'\0',16);

				for (junk=0; junk!=strlen(quote_str); junk++)
					{
					if ((quote_str[junk]!='>') && (!angleseen))
						{
						orig_quote_str[junk]=quote_str[junk];
						}
						else
						{
						if (quote_str[junk]=='>')
							{
							angleseen=1;
							orig_quote_str[junk]=quote_str[junk];
							}
						}
					}
				strcpy(quote_str,orig_quote_str);
				}
					// redo quote-str depending on which option chosen

			strcpy(orig_quote_str,quote_str);

			if (strlen(quote_str) > 15)
				{
				sprintf(dumster,".14s",quote_str);
				}
				else
				{
				strcpy(dumster,quote_str);
				}


			rmlead(dumster);
			rmtrail(dumster);
			memset(quote_str,'\0',15);

			if (quote_style==7)	quote_style=random(7);


			switch(quote_style)
				{
				case 0:		// normal
					break;
				case 1: 	// lowercase
					strlwr(dumster);
					altered++;
					break;
				case 2:		// Mixed Case (Sa)
					strlwr(dumster);
					toupper(dumster[0]);
					altered++;
					break;
				case 3:		// Mixed Case (sA)
					strupr(dumster);
					altered++;
					tolower(dumster[0]);
					break;
				case 4:
					dumster[strlen(dumster)]='-';
					altered++;
					strcat(dumster,">");
					break;
				case 5:
					dumster[strlen(dumster)]='=';
					altered++;
					strcat(dumster,">");
					break;
				case 6:
					dumster[strlen(dumster)]='+';
					altered++;
					strcat(dumster,">");
					break;
				case 8:		// filter out alpha
					for (junk=0, junkfed=0; junk!=15; junk++)
						{
						if (dumster[junk]=='>')	break;

						if (isalpha(dumster[junk]))
							{
							block_str[junkfed]=dumster[junk];
							junkfed++;
							}
						}
					strcat(block_str," -|");
					break;
				case 9:
					for (junk=0, junkfed=0; junk!=15; junk++)
						{
						if (dumster[junk]=='>')	break;

						if (isalpha(dumster[junk]))
							{
							block_str[junkfed]=dumster[junk];
							junkfed++;
							}
						}
					strcat(block_str," �");
					break;
				case 10:
					break;
				default:
					strcat(dumster,"?");
					altered++;
					break;
				}

			//sprintf(quote_str," %s ",dumster);	       // to get correct spacing

			if (strlen(block_str))
				sprintf(quote_str," %s ",block_str);
				else
				sprintf(quote_str," %s ",dumster);


			len=strlen(quote_str);

			while(strlen(tagstart)>(TAGRMARG-len))
				{

				taghere=tagstart+(TAGRMARG-len);
				while(*taghere!=' ' && taghere>tagstart) taghere--;
				*taghere=0;
				fprintf(rf_tmp,"%s%s\n",
							quote_str,
							tagstart);
				tagstart=taghere+1;
				}

			fprintf(rf_tmp,"%s%s\n",quote_str,tagstart);

			if (ferror(rf_tmp))
				{
				textattr(RED);
				sprintf(dummy,"An error occured writing to requote temp file: %s\r\n",TEMP_FILE);
				quit(555,dummy);
				}

			if (altered)	strcpy(quote_str,orig_quote_str);
			}
			else
			{
				// not quotes, output verbatim
			fputs(tagline,rf_tmp);
			fputs("\n",rf_tmp);
			}
		}
	}

fcloseall();

kill_file(MSGBACKUPFILE);

if (rename(msgfile,MSGBACKUPFILE))	non_fatal_error("Cannot create backup file [8]");


if (rename(TEMP_FILE,msgfile))	non_fatal_error("Unable to overwrite message file! [8]");

sprintf(dummy,"Finished. (%d lines)",num_lines);
working(dummy);
}

		// fills char spec_pick_str[51];
void slow_special_pick(char *tagfilename)
{
FILE *tagfp;
unsigned int totcnt=0, randpick;


if ((tagfp=fopen(tagfilename,"rt"))==NULL)
	{
	sprintf(spec_pick_str,"Unable to open file: %s",tagfilename);
	return;
	}

while (fgets(spec_pick_str,76,tagfp))   totcnt++;

rewind(tagfp);

if (totcnt < 2)
	{
	strcpy(spec_pick_str,"File too short for picking");
	return;
	}

randpick=random(totcnt);

for (totcnt=0; totcnt < randpick; totcnt++)	fgets(spec_pick_str,50,tagfp);

fclose(tagfp);
rmtrail(spec_pick_str);

if (!strlen(spec_pick_str))	strcpy(spec_pick_str,"Entry was too short");

return;
}


