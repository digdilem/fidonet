/*
TAGUTIL.C  (C) Simon Avery 1997

This program contains many functions from Tag-O-Matic (T-MATIC.C) V.12d
which got too big (even in Large mem model) to contain everything. For this
reason, another program is created to take most of those away.

Compile in Large memory model.

bind spawno

*/

#define NAME	"Tagutil"
#define VER	"09a"

#define TAGLEN	2048
#define CRACKVAL 251

#define BACKUP_FILE	"OLDTAGS.TAG"
#define LONGTAGFILE	"LONGTAGS.TAG"
#define TERMAILCFG	"TM.CFG"
#define TEMP_FILE	"T-MATIC.$$$"
#define DEFAULT_CFGFILE "T-MATIC.CFG"

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dir.h>
#include <string.h>
#include <dos.h>
#include <time.h>
#include <bios.h>
#include <sys\stat.h>
#include <spawno.h>

#define ESC		283


#define ULONG	unsigned long
#define UCHAR	unsigned char

void split_alpha(void);
void filter_tag(void);
void too_long(void);
void termail_replace_regstring(void);
void quick_tag_filt(char *);
int exact_check(char *, char *);
void non_fatal_error(char *);
void cross_dupecheck(void);
void dupe_check(void);
void filter_non_punct(void);
void tagfile_toss(void);
void dupe_check_window(ULONG, ULONG);
void get_datfile_name(void);
void replace_word_tagfile(void);
void load_dat(void);
void steal_mood(void);
void split_file(void);
void rot13(void);
void execute(char *);
void count_taglines(void);
void pick_tag(void);
void check_key_abort(void);
int kill_file(char *);
void missing_file(char *);
char *rmlead(char *);
char *rmtrail(char *);
void cook_tag(void);
void tm_window(int ,int,int ,int ,int );
void untag(void);
void help(char *);
void quit(int , char *);
void do_extra_banner(char *);
int check_4_dupe(char *, int);
void draw_tm_box(void);
void append_files(void);
void manual_steal(void);
void mass_steal(char);
void steal(void);
void rand_originmood(int);
void read_config(char *);


char tagfile[MAXPATH];
char msgfile[MAXPATH];
char filterfile[MAXPATH];
char dupetagfile[MAXPATH];
char CFGFILE[MAXPATH];
char DATFILE[MAXPATH];
char logfile[MAXPATH];

char tagline[TAGLEN];
char dumtag[TAGLEN];

char filt_str[20][51];	// for tag filtering

char dummy[201];

ULONG tot_tags=0L,last_tag=0L,chosen=0L;
ULONG tot_found=0L;
ULONG filesize=0L;


char TAGRMARG;

int junk;

FILE *msg;

UCHAR adopt_seperate, fuzzy_dupe=0, check_dupes=0,swapout=1;
UCHAR filter_word_fnd=0, edittagadopt=0;

UCHAR sort_bfr_dupe=0;

#include "tag-head.h"
#include "editgets.h"
#include "longrand.h"			// rand routine for returning longs
#include "keycode.h"			// special replacement for bioskey
#include "t-uudec.h"	// uudecoding routine
#include "nocrack3.h"			// anti exe-editing routine
#include "getini.h"
#include "t-replc.h"			// string replacementn

#include "tagutil.sc1"		// help 1
#include "tagutil.sc2"		// help 2







int main(int argc, char *argv[])
{
FILE *filtlst;
struct ffblk ffblk;
char done;

TAGRMARG=75;
strcpy(CFGFILE,DEFAULT_CFGFILE);
_setcursortype(_NOCURSOR);

randomize();

textattr(WHITE);
clrscr();
draw_tm_box();

gotoxy(1,6);

if (!SELF_CHECK(argv[0],CRACKVAL))
	{
	textattr(RED);
	cprintf("FATAL ERROR: %s has failed self-check.\r\n",argv[0]);
	textattr(BROWN);
	cputs("EXE has been modified. Reasons could be:\r\n\n");
	textattr(YELLOW);
	cputs("Virus active on system. T-Matic infected.\r\n");
	cputs("File has been compressed or expanded.\r\n");
	cputs("File has been edited.\r\n\n");
	sound(200);
	delay(200);
	nosound();
	wait(60);
	quit(99,"EXE altered");
	}


switch(argc)
	{
	case 1:
		help("No arguements supplied");
		quit(0,"Help text displayed");
		break;
	case 2:
//		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
//			{
		break;
	case 3:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case 'D':	// dupe
						// wildcards allowed
					read_config(CFGFILE);

					strcpy(tagfile,argv[2]);
					strupr(tagfile);
						// if sort
//					if (sort_bfr_dupe)
//						{
//						sprintf(dummy,"TSORT %s",tagfile);
//						execute(dummy);
//						}
					done=findfirst(tagfile,&ffblk,0);
					if (done==-1)
						{
						quit(2,"Unable to find any files to de-dupe");
						}
					while (!done)
						{
						strcpy(tagfile,ffblk.ff_name);
						dupe_check();
						done=findnext(&ffblk);
						}
					quit(0,"Finishing dupe-checking tagfile(s)");
					break;
				case 'R':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					replace_word_tagfile();
					break;
				case 'G':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					termail_replace_regstring();
					break;
				case 'N':
					strcpy(tagfile,argv[2]);
					strcpy(CFGFILE,"T-MATIC.CFG");
					strupr(tagfile);
					filter_non_punct();
					break;
				case '5':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					split_alpha();
					break;
				case '3':
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					rot13();
					break;
				case '2':
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					if (uudecode(msgfile))
						{
						quit(86,"UUdecode routine failed");
						}
					quit(0,"UUencoded file decoded successfully");
					break;
				case 'T':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					sprintf(dumtag,"TSORT %s",tagfile);
					execute(dumtag);
					quit(0,"Sorting routine finished");
					break;
				case 'O':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					strcpy(msgfile,TERMAILCFG);
					rand_originmood(0);
					break;
				case 'U':	// untag msgfile
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					untag();
					break;
				case 'S':	// steal - manual
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					manual_steal();
					break;
				case 'L':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					too_long();
					break;
				case '6':
					strcpy(tagfile,argv[2]);
					strcpy(msgfile,"TAGUTIL.CTL");
					strupr(tagfile);
					strupr(msgfile);
					tagfile_toss();
					break;
				case 'M':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					strcpy(msgfile,TERMAILCFG);
					rand_originmood(1);
					break;
				default:
					help("Switch not recognised");
					quit(1,"Switch not recognised");
					break;
				}
			}
		help("Switch not recognised");
		quit(1,"Switch not recognised");
		break;
	case 4:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case 'N':
					strcpy(tagfile,argv[2]);
					strcpy(CFGFILE,argv[3]);
					strupr(tagfile);
					strupr(CFGFILE);
					filter_non_punct();
					break;
				case 'C':	// cookie
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					strcpy(tagfile,argv[3]);
					strupr(tagfile);
					cook_tag();
					break;
				case 'I':	// filter - no cfg specified
					read_config(CFGFILE);
					strcpy(tagfile,strupr(argv[2]));
					strcpy(msgfile,strupr(argv[3]));
					filter_tag();
					break;
				case 'R':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					strcpy(CFGFILE,argv[3]);
					strupr(CFGFILE);
					replace_word_tagfile();
					break;
				case 'P':     // split
					strcpy(msgfile,argv[2]);
					strupr(msgfile);
					TAGRMARG=atoi(argv[3]);
					split_file();
					break;
				case 'A':
					strcpy(tagfile,argv[2]);
					strcpy(msgfile,argv[3]);
					strupr(tagfile);
					strupr(msgfile);
					append_files();
					break;
				case 'L':
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					TAGRMARG=atoi(argv[3]);
					too_long();
					break;
				case '6':
					strcpy(tagfile,argv[2]);
					strcpy(msgfile,argv[3]);
					strupr(tagfile);
					strupr(msgfile);
					tagfile_toss();
					break;
				case 'K':	//mood stealer
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					strcpy(msgfile,argv[3]);
					strupr(msgfile);
					steal_mood();
					break;
				case '4':	// cross tagfiles dupecheck
					read_config(CFGFILE);
					strcpy(tagfile,argv[2]);
					strupr(tagfile);
					strcpy(msgfile,argv[3]);
					strupr(msgfile);
					cross_dupecheck();
					break;
				case 'S':
					switch(toupper(argv[1][2]))
						{
						case 'J':
							read_config(CFGFILE);
							strcpy(tagfile,argv[2]);
							strcpy(msgfile,argv[3]);
							strupr(tagfile);
							strupr(msgfile);
							mass_steal(0);
							break;
						case 'H':
							read_config(CFGFILE);
							strcpy(tagfile,argv[2]);
							strcpy(msgfile,argv[3]);
							strupr(tagfile);
							strupr(msgfile);
							mass_steal(1);
							break;
						case 'S':
							read_config(CFGFILE);
							strcpy(tagfile,argv[2]);
							strcpy(msgfile,argv[3]);
							strupr(tagfile);
							strupr(msgfile);
							mass_steal(2);
							break;
						case 'M':
							read_config(CFGFILE);
							strcpy(tagfile,argv[2]);
							strcpy(msgfile,argv[3]);
							strupr(tagfile);
							strupr(msgfile);
							mass_steal(3);
							break;
						default:
							read_config(CFGFILE);
							strcpy(tagfile,argv[2]);
							strcpy(msgfile,argv[3]);
							strupr(tagfile);
							strupr(msgfile);
							steal();
							break;
						}
				}
			}
		help("Switch not recognised");
		quit(1,"Switch not recognised");
		break;
	case 5:
		if ((argv[1][0]=='/') || (argv[1][0]=='-'))
			{
			switch(toupper(argv[1][1]))
				{
				case 'I':	// filter - no cfg specified
					strcpy(CFGFILE,strupr(argv[4]));
					read_config(CFGFILE);
					strcpy(tagfile,strupr(argv[2]));
					strcpy(msgfile,strupr(argv[3]));
					filter_tag();
					break;
				case '1':	// filter - quick
					strcpy(tagfile,argv[2]);
					strcpy(filterfile,argv[3]);
					strupr(tagfile);
					strupr(filterfile);
							// file exists of same name
					if (access(argv[4],0)==0)
						{
						textattr(LIGHTGREEN);
						cprintf("File [%s] found. Use this for filter list?\r",argv[4]);
						switch(toupper(getch()))
							{
							case 'Y':
								clreol();
								if ((filtlst=fopen(argv[4],"rt"))==NULL)	missing_file(argv[4]);
								while (fgets(dummy,100,filtlst))
									{
									rmtrail(dummy);
									if (strlen(dummy)) 	quick_tag_filt(dummy);
									}
								fclose(filtlst);
								break;
							default:
								clreol();
								quick_tag_filt(argv[4]);
								break;
							}
						}
						else
						{
						quick_tag_filt(argv[4]);
						}

					wait(30);
					sprintf(dummy,"Quick-Filter-Tag finished. %lu tags filtered.",tot_found);
					quit(0,dummy);
					break;
				}
			}
		help("Switch not recognised");
		quit(1,"Switch not recognised");
		break;
	}

help("Switch not recognised");
quit(1,"Switch not recognised");
return 0;
}

void steal(void)
{
FILE *tag;

tot_tags=0L;
textattr(WHITE);
cprintf("Tag-hunting...\r\n",
	"Message: [%s]\r\n",
	"Tagfile: [%s]\r\n",msgfile,tagfile);

if ((msg=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);

if (adopt_seperate)
	{
	textattr(GREEN);
	cprintf("Adopting to seperate file: [%s]\r\n","PROCESS.TAG");
	if ((tag=fopen("PROCESS.TAG","at"))==NULL)	missing_file("PROCESS.TAG");
	}
	else
	{
	if ((tag=fopen(tagfile,"at"))==NULL)		missing_file(tagfile);
	}
		// main loop
while (fgets(tagline,TAGLEN,msg))
	{
	memset(dumtag,'\0',TAGLEN);

	if ((tagline[0]=='.') && (tagline[2]=='.') && (tagline[3]==' '))
		{
		rmtrail(tagline);

		if ((strlen(tagline)) < 6)
			{
			textattr(LIGHTRED);
			cputs("Tag too short!\r\n");
			}
			else
			{
			// remove 1st 4 chars
			for (junk=4; junk!=(strlen(tagline)); junk++)
				{
				dumtag[junk-4]=tagline[junk];
				}
			dumtag[junk]='\0';	// null terminator

			textattr(LIGHTBLUE);
			cprintf("Found: [%.68s]\r\n",dumtag);
			if (check_dupes)
				{
				switch(check_4_dupe(dumtag,1))
					{
					case 0:
						if (fprintf(tag,"%s\n",dumtag)==EOF)	box_error("Problem writing tag");
	//					fclose(tag);
						tot_tags++;
						break;
					case 1:
						textattr(LIGHTRED);
						cputs("Duped...\r\n");
						break;
					case 2:
						textattr(LIGHTRED);
						cputs("Contained a filtered word...\r\n");
						break;
					default:
						textattr(LIGHTRED+BLINK);
						cputs("Error in steal function!\r\n\a");
						break;
					}
				}
				else		// no dupe-check, just append
				{
				if ((fprintf(tag,"%s\n",dumtag))==EOF)	{box_error("Error writing to tagfile"); wait(10); }
				tot_tags++;
				}
			}
	    //	wait(1);
		}
	}

fclose(tag);
fclose(msg);

sprintf(dummy,"Stolen %lu tags from file [%s]",tot_tags,msgfile);
textattr(YELLOW);
cprintf("\r\n%s",dummy);
wait(20);
quit(0,dummy);
}



void manual_steal(void)
{
FILE *tag;

tot_tags=0L;

for (;;) 	// loop until finished
	{
	textbackground(BLUE);
	tm_window(2,11,76,1,WHITE);
	gotoxy(4,11);
	cputs("� Enter new tag �");
	gotoxy(4,13);
	cputs("� Leave blank to abort �");

	memset(dumtag,'\0',TAGLEN);
	editgets(3,12,dumtag,74,0,0);	// get new tag

	if (strlen(dumtag) < 3)		quit(0,"Not wanted eh?");

	if (adopt_seperate)
		{
		textattr(WHITE);
		cputs("Adopting to seperate file: [PROCESS.TAG]\r\n");
		if ((tag=fopen("PROCESS.TAG","at"))==NULL)	missing_file("PROCESS.TAG");
		}
		else
		{
		if ((tag=fopen(tagfile,"at"))==NULL)		missing_file(tagfile);
		}

	if (check_dupes)
		{
		switch(check_4_dupe(dumtag,1))
			{
			case 0:
				fprintf(tag,"%s\n",dumtag);
				tot_tags++;
				textattr(LIGHTBLUE);
				cputs("Adopted.\r\n");
				break;
			case 1:
				textattr(LIGHTRED);
				cputs("Duped...\r\n");
				break;
			case 2:
				textattr(LIGHTRED);
				cputs("Contained a filtered string...\r\n");
				break;
			default:
				textattr(LIGHTRED+BLINK);
				cputs("Error in check_dupe function!\r\n");
				break;
			}
		}
		else
		{
		fprintf(tag,"%s\n",dumtag);
		tot_tags++;
		textattr(LIGHTBLUE);
		cputs("Adopted.\r\n");
		}

	fclose(tag);
	gettext(1,10,80,16,dumtag);
	box_error("Do you want to add another? (Y/n)");

	switch(toupper(getch()))
		{
		case 'N':
			puttext(1,10,80,16,dumtag);
			sprintf(dummy,"%lu taglines added.",tot_tags);
			quit(0,dummy);
			break;
		default:
			break;
		}

	puttext(1,10,80,16,dumtag);
	}
}


void mass_steal(char whichbase)
{
FILE *tag,*msgbase;

char ch,ch2,ch3;
int done,endtag,not_dupe,echos=0;
struct ffblk data;
char dir[MAXPATH];

char *scrptr;
int ypos;

ULONG tags_ok=0L;

if (edittagadopt)
	{
	if ((scrptr=(char *)malloc(500))==NULL)
		{
		textattr(LIGHTRED);
		cputs("Not enough memory. EditTagAdopt turned off\r\n");
		edittagadopt=0;
		}
	}


switch(whichbase)
	{
	case 0:	// jambase
		do_extra_banner("Taglifting: JAM");
		sprintf(dir,"%s\\*.JDT",msgfile);
		break;
	case 1: // hudson
		do_extra_banner("Taglifting: Hudson");
		sprintf(dir,"%s\\MSGTXT.BBS",msgfile);
		break;
	case 2: // Swuish
		do_extra_banner("Taglifting: Squish");
		sprintf(dir,"%s\\*.SQD",msgfile);
		break;
	case 3:	// msg
		do_extra_banner("Taglifting: Msg");
		sprintf(dir,"%s\\*.MSG",msgfile);
		break;
	}

textattr(YELLOW);
if (check_dupes)
	{ cputs("Dupe-checking. SLOW!\r\n"); }
	else
	{ cputs("No Dupe-checking\r\n"); }

if (adopt_seperate)	{ textattr(GREEN);  cprintf("Adopting to seperate file: [%s]\r\n","PROCESS.TAG"); }

textattr(WHITE);
cprintf("Tagfile: [%s]\r\nMessage base directory: [%s]\r\n",tagfile,msgfile);
textattr(BROWN);
cprintf("File Spec: [%s]\r\n",dir);

done=findfirst(dir,&data,0);

tot_tags=0L;

while(!done)
	{
	sprintf(dummy,"%s\\%s",msgfile,data.ff_name);

	if ((msgbase=fopen(dummy,"rb"))==NULL)
		{
		textattr(LIGHTRED);
		cprintf("Unable to open file: [%s]\r\n",dummy);
		goto Rest;
		}

	textattr(LIGHTBLUE);
	gotoxy(1,10);
	clreol();
	cprintf("File: [%s] Tags Found: [%lu]",data.ff_name,tot_tags);

	check_key_abort();

	while (!feof(msgbase))
		{
		ch=fgetc(msgbase);

		if ((ch==13) || (ch==10))	// it's a CR
			{
			if (fgetc(msgbase)=='.')
				{
				ch3=fgetc(msgbase);

				if ((ch3=='.') || (ch3=='!') || (ch3==':'))
					{
					if (fgetc(msgbase)=='.')	// got CR... precursor - IT@S A DAMN TAG!
						{
						fgetc(msgbase);	// get space
						not_dupe=0;
						tot_tags++;

						memset(tagline,'\0',TAGLEN);


						endtag=0;

						for (junk=0; junk!=TAGLEN; junk++)
							{
							ch2=fgetc(msgbase);
							switch(ch2)
								{
								case 13:
								case '\0':
								case EOF:
								case 10:
									endtag=1;
									break;
								default:
									tagline[junk]=ch2;
									break;
								}
							if (endtag)	break;
							}

						textcolor(LIGHTCYAN);
						gotoxy(1,11);
						clreol();
						cprintf("%.78s",tagline);

						if (edittagadopt)
							{
							ypos=wherey();
							gettext(1,10,80,12,scrptr);
							textbackground(BLUE);
							tm_window(1,10,80,1,YELLOW);
							center("� Edit tagline �",10);
							textcolor(WHITE);
							editgets(2,11,tagline,78,0,0);
							puttext(1,10,80,12,scrptr);
							gotoxy(1,ypos);
							textattr(LIGHTBLUE);
							}
								// got tag, now check for dupe and/or adopt

						if (check_dupes)
							{
							switch (check_4_dupe(tagline,0))
								{
								case 0:	// not duped
									not_dupe=1;
									break;
								case 1:	// Duped
									textattr(WHITE);
									gotoxy(1,11);
									clreol();
									cputs("Duped");
									break;
								case 2: // filtered
									textattr(LIGHTGRAY);
									gotoxy(1,11);
									clreol();
									cputs("Filtered");
									break;
								default:	// unknown
									textattr(LIGHTRED+BLINK);
									gotoxy(1,11);
									clreol();
									cputs("Error in check_4_dupe()");
									sound(600);
									delay(100);
									nosound();
									wait(5);
								}
							}
							else
							{
							not_dupe=1;
							}

						if (not_dupe)
							{
							if (adopt_seperate)
								{ if ((tag=fopen("PROCESS.TAG","at"))==NULL)	missing_file("PROCESS.TAG"); }
								else
								{ if ((tag=fopen(tagfile,"at"))==NULL)		missing_file(tagfile); }
							fprintf(tag,"%s\n",tagline);
							fclose(tag);
							tags_ok++;
							}

						textattr(LIGHTBLUE);
						gotoxy(1,10);
						clreol();
						cprintf("File: [%s] Tags Found: [%lu]",data.ff_name,tot_tags);
						}
					}
				}
			}
		}

	fclose(msgbase);
	echos++;

	Rest:;

	done=findnext(&data);
	}


sprintf(dumtag,"Finished.\r\nTotal Echos/Msgs: [%d]  Total Tags Stolen: [%lu]  Total Taglines: [%lu]",

						echos,
						tags_ok,
						tot_tags);
textattr(WHITE);
printf("\n\n");
cprintf(dumtag);

if (edittagadopt)	free(scrptr);

wait(5);
quit(0,dumtag);
}


void too_long(void)
{
FILE *tag,*rf_tmp;

ULONG long_tags=0L;
ULONG ok_tags=0L;

int len;

do_extra_banner("The long and short of it");

textattr(WHITE);
cprintf("Tagfile       : [%s]\r\n",tagfile);
cprintf("Long Tagfile  : [%s]\r\n",LONGTAGFILE);
cprintf("Backup File   : [%s]\r\n",BACKUP_FILE);
cprintf("Max Length    : [%d]\r\n",TAGRMARG);

if ((tag=fopen(tagfile,"rt"))==NULL)		missing_file(tagfile);
if ((rf_tmp=fopen(LONGTAGFILE,"at"))==NULL)	missing_file(LONGTAGFILE);
if ((msg=fopen(TEMP_FILE,"wt"))==NULL)		missing_file(TEMP_FILE);

while (fgets(tagline,TAGLEN,tag))
	{
	check_key_abort();
	len=strlen(tagline);

	if (len > TAGRMARG)
		{
		fputs(tagline,rf_tmp);
		long_tags++;
		}
		else
		{
		fputs(tagline,msg);
		ok_tags++;
		}
	tot_tags++;

	textattr(LIGHTBLUE);
	cputs("\rTotal Taglines [");
	textattr(LIGHTCYAN);
	cprintf("%-5lu",tot_tags);
	textattr(LIGHTBLUE);
	cputs("]  Taglines too long [");
	textattr(LIGHTCYAN);
	cprintf("%-5lu",long_tags);
	textattr(LIGHTBLUE);
	cputs("]  Taglines Ok [");
	textattr(LIGHTCYAN);
	cprintf("%-5lu",ok_tags);
	textattr(LIGHTBLUE);
	cputs("]");
	}

fcloseall();

textattr(LIGHTGREEN);
cputs("\r\nRenaming Files...\r\n");

kill_file(BACKUP_FILE);

if (rename(tagfile,BACKUP_FILE))        quit(16,"Unable to rename tagfile to backup file");
if (rename(TEMP_FILE,tagfile))		quit(17,"Unable to rename temp file to tagfile");

quit(0,"Finished long-tag routine");
}
void append_files(void)			// append one file (msg) to another (tag)
{
FILE *out;
do_extra_banner("Appendectomy");

textattr(WHITE);
cprintf("Appending file [%s] to [%s]\r\n",msgfile,tagfile);

tot_tags=0L;

if ((out=fopen(tagfile,"at"))==NULL)	missing_file(tagfile);
if ((msg=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);

while(fgets(tagline,TAGLEN,msg))
	{
	check_key_abort();
	tot_tags++;
	if (!fputs(tagline,out))	quit(1,"Error writing file...");
	}

sprintf(dummy,"[%lu] taglines appended. Original file NOT deleted",tot_tags);
quit(0,dummy);
}

void rand_originmood(int which)	       	// combine both 0=origin 1=mood
{
FILE *bakfp;
int numdone=0;
int done;
			// no longer applied
//fast_tag=0;	// 'cos it'll be a small file

textattr(YELLOW);

gotoxy(1,6);

if (!which)
	{ cputs("Origin Origami\r\n"); 	textattr(WHITE);	cprintf("Origin File  : [%s]\r\n",tagfile); }
	else
	{ cputs("Mood Muddler\r\n"); 	textattr(WHITE);	cprintf("Mood File    : [%s]\r\n",tagfile); }

cprintf("Config File  : [TM.CFG]\r\n");
cprintf("Backup File  : [TMCFG.BAK]\r\n");

kill_file("TMCFG.BAK");

if (access(tagfile,0))
	{
	textattr(LIGHTRED+BLINK);
	cprintf("Unable to open text file: %s\r\n",tagfile);
	wait(40);
	quit(2,"Textfile didn't exist");
	}

if (rename("TM.CFG","TMCFG.BAK"))               quit(19,"Can't rename TM.CFG to TMCFG.BAK");
if ((bakfp=fopen("TMCFG.BAK","rt"))==NULL)	quit(20,"Can't open TMCFG.BAK");
if ((msg=fopen("TM.CFG","wt"))==NULL)		quit(21,"Can't open TM.CFG for writing");



count_taglines();

while(fgets(dumtag,TAGLEN,bakfp))
	{
	done=0;

	if (!which)	// origin
		{ if ((dumtag[0]=='O') && (dumtag[1]=='r') && (dumtag[2]=='i') && (dumtag[3]=='g') && (dumtag[4]=='i') && (dumtag[5]=='n'))	{ done=1; } }
		else
		{ if ((dumtag[0]=='M') && (dumtag[1]=='o') && (dumtag[2]=='o') && (dumtag[3]=='d'))	{ done=1; } }

	if (done)	// found a match
		{
		numdone++;
		textattr(LIGHTCYAN);


		if (numdone > 20)	// error-check
			{
			fcloseall();
			kill_file("TM.CFG");
			rename("TMCFG.BAK","TM.CFG");
			quit(22,"Too many entries in TM.CFG");
			}

		pick_tag();

		if (!which)
			{
			cprintf("Origin Done: [%d]\r\n",numdone);
			fprintf(msg,"Origin      %.55s\n",tagline);
			}
			else
			{
			cprintf("Mood Done  : [%d]\r\n",numdone);
			fprintf(msg,"Mood %.25s\n",tagline);
			}
		}
		else		// not origin/mood - just write out again
		{
		fputs(dumtag,msg);
		}
	}

fcloseall();

sprintf(dummy,"Finished. Number of moods / origins changed: [%d]",numdone);
quit(0,dummy);
}
void steal_mood(void)
{
FILE *moodfp;
int count=0,lincnt=0;

do_extra_banner("Moody-bLose");

if ((msg=fopen(msgfile,"rt"))==NULL)		missing_file(msgfile);
if ((moodfp=fopen(tagfile,"at"))==NULL)		missing_file(msgfile);

textattr(WHITE);

while (fgets(tagline,TAGLEN,msg))
	{
	if ((tagline[0]==1) && (strstr(tagline,"MOOD:")))
		{
		memset(dumtag,'\0',TAGLEN);

		for (junk=7; junk<=strlen(tagline); junk++)
			{
			dumtag[junk-7]=tagline[junk];
			}
		fprintf(moodfp,"%s",dumtag);
		cprintf("Stolen: %s\r",dumtag);
		count++;
		}
	lincnt++;
	}

fclose(moodfp);
fclose(msg);

sprintf(dummy,"I stole [%d] moods from this message. %d Lines",count,lincnt);
cprintf(dummy);
wait(5);
quit(0,dummy);
}
void untag(void)			// remove any tags from msg
{
FILE *tmp;

char found;

do_extra_banner("UnTag-O-Matic");

tot_tags=0L;

if ((msg=fopen(msgfile,"rt"))==NULL)		missing_file(msgfile);
if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)		missing_file(TEMP_FILE);

while (fgets(tagline,TAGLEN,msg))
	{
	found=0;

	if ((tagline[0]=='.') && (tagline[2]=='.'))	{ tot_tags++; found++; }
			// also rem any t-matic IDs
//	if (strstr(tagline,TAGID))			{ found++; }

	if (strstr(tagline,"Tag-O-Matic"))		{ found++; }

	if (!found)					{ fputs(tagline,tmp); }
	}

fclose(tmp);
fclose(msg);

if (kill_file(msgfile))			quit(2,"Unable to delete original msgfile");

if (rename(TEMP_FILE,msgfile))		quit(2,"Unable to rename tempfile to msgfile");

sprintf(dummy,"Untag Finished. [%lu] taglines removed.",tot_tags);

quit(0,dummy);
}

void execute(char *str)
{
char where[MAXPATH];
int rslt;

strcpy(where,getenv("COMSPEC"));

textbackground(BLACK);
clrscr();
draw_tm_box();

_setcursortype(_NORMALCURSOR);

do_extra_banner("Running External Program");

textattr(WHITE);
gotoxy(1,7);

cprintf("Execute string: [%s /c %s]\r\n",where,str);
cprintf("Mem left in current block prior to swapping out : [%lu]\r\n",coreleft());
cprintf("Mem left overall prior to swapping out          : [%lu]\r\n",farcoreleft());

//wait(1);
		// see men-yoo.c for details on usage
//result=spawnlo(path_d,where,where,"/c",thing,NULL);
//result=spawnlo (".", where, where, "/c", thing, NULL);
	// this one
if (swapout)
	{
	rslt=spawnlo (".", where, where, "/c", str, NULL);
	}
	else
	{
	rslt=system(str);
	}
//spawnlo (".", where, where, "/c", str, msgfile);

//if (_doserrno)
if (rslt)
	{
	sprintf(dummy,"Program returned an error level of [%d] [%s] [%d]\a",errno,sys_errlist[errno],rslt);
	box_error(dummy);
	wait(60);
	}

_setcursortype(_NOCURSOR);
}

void filter_tag(void)
{
FILE *in,*out;
int junk;

do_extra_banner("Filt-O-Matic");

textattr(YELLOW);

cprintf("Tagfile: [%s]\r\n",tagfile);
cprintf("Newfile: [%s]\r\n",msgfile);
cprintf("Cfgfile: [%s]\r\n",CFGFILE);

if ((in=fopen(tagfile,"rt"))==NULL)	missing_file(tagfile);
if ((out=fopen(msgfile,"at"))==NULL)
	{
	out=fopen(msgfile,"wt");
	fclose(out);
	if ((out=fopen(msgfile,"at"))==NULL)	missing_file(msgfile);
	}

// load to_kill_list


if (!filter_word_fnd)
	{
	textattr(LIGHTRED);
	cprintf("\r\nNo entries found in FilterWord section of [%s]\n\r\a",CFGFILE);
	wait(10);
	quit(63,"Unable to locate entries for FilterWord");
	}

filter_word_fnd--;		// it adds one in config

textattr(GREEN);
cputs("Words to filter:\r\n");
textattr(LIGHTGREEN);

for (junk=0; junk<=filter_word_fnd; junk++)
	{
	cprintf("%d) [%s]\r\n",junk,filt_str[junk]);
	}

textcolor(WHITE);
cprintf("\r\nTags Filtered: [0]");


	// check

while (fgets(tagline,TAGLEN,in))
	{
	for (junk=0; junk<=filter_word_fnd; junk++)
		{
		if (strstr((char *)tagline,filt_str[junk]))
			{
			tot_tags++;
			cprintf("\rTags Filtered: [%lu]",tot_tags);
			fputs(tagline,out);
			}
		}
	}

fcloseall();

//system("cls");
sprintf(dummy,"Finished. [%lu] taglines filtered.",tot_tags);
quit(0,dummy);
}
void cook_tag(void)
{
FILE *in,*out;

tot_tags=0L;
textattr(LIGHTBLUE);
gotoxy(1,5);
do_extra_banner("Cookie-O-Matic");

if ((in=fopen(msgfile,"rt"))==NULL)	missing_file("Unable to open cookie-file");
if ((out=fopen(tagfile,"at"))==NULL)
	{
	if ((out=fopen(tagfile,"wt"))==NULL)
		{
		missing_file("Unable to open tagfile");
		}
	}

		// main loop
memset(tagline,'\0',TAGLEN);
textattr(LIGHTCYAN);
gotoxy(1,6);

while (fgets(dumtag,100,in))
	{
	rmtrail(dumtag);
	rmlead(dumtag);

	if (dumtag[0]=='%')	// it's a seperator - write tags
		{
		if (strlen(tagline))		// something in tagline
			{
			fprintf(out,"%s\n",tagline);
			memset(tagline,'\0',TAGLEN);
			tot_tags++;
			}
		}
		else	// append it
		{
		if ((strlen(dumtag) + strlen(tagline)) > TAGLEN)
			{
			cprintf("Cookie too long. Current limit is [%d] chars.\r\n",TAGLEN);
			}
			else
			{
			strcat(tagline," ");
			strcat(tagline,dumtag);
			}
		}

	}
if (strlen(tagline))	fprintf(out,"%s\n",tagline);	// just to flush array, otherwise it forgets last one

fcloseall();

textattr(WHITE);
cprintf("Finished. %lu taglines added.\r\n",tot_tags);
wait(30);
sprintf(tagline,"[%lu] Taglines added",tot_tags);
quit(0,tagline);
}

void quick_tag_filt(char *word_to_filt)
{
FILE *in,*out;

tot_tags=0L;

strupr(word_to_filt);

do_extra_banner("Quick Filter");

textattr(WHITE);
gotoxy(1,6);
cprintf("Tagfile: [%s]   \r\n",tagfile);
cprintf("Outfile: [%s]   \r\n",filterfile);
cprintf("Using word: [%s]      \r\n\n",word_to_filt);

textattr(LIGHTCYAN);
cprintf("\rTotal Taglines [%lu]   Taglines Filtered [%lu]      ",tot_tags,tot_found);

if ((in=fopen(tagfile,"rt"))==NULL)	missing_file(tagfile);
if ((out=fopen(filterfile,"at"))==NULL)	missing_file(tagfile);

while (fgets(tagline,TAGLEN,in))
	{
	check_key_abort();
	strcpy(dumtag,tagline);
	strupr(tagline);
	if (strstr(tagline,word_to_filt))
		{
		fputs(dumtag,out);
		tot_found++;
		}
	tot_tags++;
	cprintf("\rTotal Taglines [%lu]   Taglines Filtered [%lu]",tot_tags,tot_found);
	}
fclose(in);
fclose(out);

printf("\r\n\n");
textattr(YELLOW);
sprintf(dumtag,"Finished. [%lu] taglines filtered to [%s]",tot_found,filterfile);
cputs(dumtag);
return;
}

void rot13(void)
{
char alph1[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
char alph2[]="NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm";

FILE *in,*out;
int ch,count=0,idx;

do_extra_banner("Rot13 cypter");

textattr(LIGHTBLUE);
gotoxy(1,6);

unlink("ROT13.BAK");

if (rename(msgfile,"ROT13.BAK"))
	{
	sprintf(tagline,"Error renaming [%s] to [%s]\n",msgfile,"ROT13.BAK");
	quit(2,tagline);
	}

if ((in=fopen("ROT13.BAK","rt"))==NULL)	missing_file("Unable to open ROT13.BAK");

if ((out=fopen(msgfile,"wt"))==NULL)	missing_file("Unable to open msgfile");

while(fgets(tagline,100,in))
	{
	rmtrail(tagline);

	for (idx=0; idx!=strlen(tagline); idx++)
		{
		if (isalpha(tagline[idx]))
			{
			for (ch=0; ch<=51; ch++)
				{
				if (tagline[idx]==alph1[ch])	break;
				}
			dumtag[idx]=alph2[ch];
			}
			else
			{
			dumtag[idx]=tagline[idx];
			}
		}
	dumtag[idx]='\0';
	fprintf(out,"%s\n",dumtag);
	count++;
	}
fcloseall();
textattr(WHITE);
sprintf(tagline,"Finished. [%d] lines processed.",count);
cputs(tagline);
wait(30);
quit(0,tagline);
}
void split_alpha(void)		// split tagfile to .a .b
{
FILE *in,*out;
char ch,ch2;
char file2[MAXPATH];
char file3[MAXPATH];

do_extra_banner("Splitting Tagfile to Alpha's");
textattr(WHITE);
gotoxy(1,6);
cprintf("Tagfile: [%s]\r\n",tagfile);

memset(msgfile,'\0',MAXPATH);

if (strchr(tagfile,'.'))
	{
	for (junk=0; junk!=strlen(tagfile); junk++)
		{
		if (tagfile[junk]=='.')	break;
		msgfile[junk]=tagfile[junk];
		}
	}
	else
	{
	strcpy(msgfile,tagfile);
	}

cprintf("Master File: [%s]\r\n",msgfile);

sprintf(file2,"%s.OTH",msgfile);

cprintf("Non-Alpha File: [%s]\r\n",file2);

wait(2);
if ((in=fopen(tagfile,"rt"))==NULL)	missing_file(tagfile);

tot_tags=0L;
textattr(YELLOW);

while (fgets(tagline,TAGLEN,in))
	{
	ch=toupper(tagline[0]);
	cprintf("Total Taglines: [%lu] [%c]  \r",tot_tags,ch);

	if (ch!=ch2)	// not as before, open afresh
		{
		fclose(out);

		if ((ch < 65) || (ch > 90))
			{
			if ((out=fopen(file2,"at"))==NULL)	missing_file(file2);
			}
			else
			{
			sprintf(file3,"%s.%c",msgfile,ch);
			if ((out=fopen(file3,"at"))==NULL)	missing_file(file3);
			ch2=ch;
			}
		}
		// file now open for writing
	fputs(tagline,out);
	tot_tags++;
	check_key_abort();
	}

fclose(in);
fclose(out);

textattr(WHITE);

printf("\r\n");
sprintf(dummy,"%lu taglines written to various files.",tot_tags);
cprintf(dummy);
cprintf("\r\nFiles are [%s.A] to [%s.Z] and [%s.OTH]\r\n",msgfile,msgfile,msgfile);

wait(10);
quit(0,dummy);
}
void split_file(void)
{			// msgfile=file to split to ..
			// tagfile= master
			// TAGRMARG = maxKfilesize
			// DATFILE = current tagfile+%d
FILE *in,*out;
int donesofar=1;


do_extra_banner("Splittification");

gotoxy(1,6);
textattr(WHITE);
cprintf("Max File Size: [%dK]\r\n",TAGRMARG);
cprintf("Splitting file : [%s]\r\n",msgfile);

if (TAGRMARG<1)
	{
	textattr(LIGHTRED+BLINK);
	cputs("Filesize too small!");
	wait(20);
	quit(2,"Splitter - Max Filesize < 1K");
	}
filesize=(TAGRMARG*1000);	// do 1000, not 1024
memset(tagfile,'\0',MAXPATH);
tot_tags=0L;

	//work out master
if (strchr(msgfile,'.'))
	{
	for (junk=0; junk!=strlen(msgfile); junk++)
		{
		if (msgfile[junk]=='.')	break;
		tagfile[junk]=msgfile[junk];
		}
	}
	else
	{
	strcpy(tagfile,msgfile);
	}

cprintf("Master Filename: [%s]\r\n",tagfile);

if ((in=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);

textattr(YELLOW);

for (;;)
	{
	sprintf(DATFILE,"%s.%d",tagfile,donesofar);
	cprintf("Creating: %s   \r",DATFILE);
	if ((out=fopen(DATFILE,"wt"))==NULL)	missing_file(DATFILE);


	while (fgets(tagline,TAGLEN,in))
		{
		tot_tags+=strlen(tagline);
		fputs(tagline,out);

		if (tot_tags > filesize)
			{
			tot_tags=0L;
			fclose(out);
			donesofar++;
			break;
			}
		}
	if (feof(in))	break;

	if (donesofar > 999)
		{
		textattr(LIGHTRED);
		cprintf("\r\nToo many files created!\r\n");
		break;
		}
	}
fclose(in);
fclose(out);
textattr(LIGHTCYAN);
sprintf(dummy,"Finished.\r\n%d files created.\r\n",donesofar);
cputs(dummy);
wait(10);
quit(0,dummy);
}

void read_config(char *fil)
{
FILE *cfg;
int flib;

if ((cfg=fopen(fil,"rt"))==NULL)	quit(4,"Unable to open configuration file");

adopt_seperate=getini_yesno(cfg,"AdoptSep");
swapout=getini_yesno(cfg,"SwapOut");
sort_bfr_dupe=getini_yesno(cfg,"ForceSort");
edittagadopt=getini_yesno(cfg,"EditTagAdopt");
strcpy(dupetagfile,getini(cfg,"DupedTagFile"));

strcpy(logfile,getini(cfg,"LogFile"));


rewind(cfg);

while(fgets(dummy,200,cfg))
	{
	if ((strstr(dummy,"DupeCheck")) && (dummy[0]!='%'))
		{
		switch(toupper(dummy[10]))
			{
			case 'F':
				fuzzy_dupe=1;
				check_dupes=1;
				break;
			case 'E':
				fuzzy_dupe=0;
				check_dupes=1;
				break;
			default:
				fuzzy_dupe=0;
				check_dupes=0;
				break;
			}
		}

	if ((strstr(dummy,"FilterWord")) && (dummy[0]!='%'))
		{
		if (filter_word_fnd>=10)	break;

		for (flib=11; flib<=strlen(dummy); flib++)
			{
			filt_str[filter_word_fnd][flib-11]=dummy[flib];
			if ((flib-11) > 50) break;
			}
		filt_str[filter_word_fnd][flib]='\0';
		rmtrail(filt_str[filter_word_fnd]);
		filter_word_fnd++;	//+
		}
	}


fclose(cfg);
}

void draw_tm_box(void)
{
int jnk;

textattr(BLACK);
clrscr();

textbackground(BLUE);
textcolor(LIGHTCYAN);

		// draw box
gotoxy(1,1);
memset(dummy,'\0',100);
strcat(dummy,"�");
for (jnk=0;jnk!=78;jnk++)       { strcat(dummy,"�"); }
strcat(dummy,"�");

raster_str(dummy,BLUE);

gotoxy(1,2);
clreol();
textcolor(random(14)+1);
cputs("�");
gotoxy(80,2);
textcolor(random(14)+1);
cputs("�");
gotoxy(1,3);
clreol();
textcolor(random(14)+1);
cputs("�");
gotoxy(80,3);
textcolor(random(14)+1);
cputs("�");
gotoxy(1,4);
clreol();
textcolor(random(14)+1);
cputs("�");
gotoxy(80,4);
textcolor(random(14)+1);
cputs("�");

memset(dummy,'\0',100);
strcat(dummy,"�");
for(jnk=0;jnk!=78;jnk++)        { strcat(dummy,"�");}
strcat(dummy,"�");
gotoxy(1,5);
clreol();
raster_str(dummy,BLUE);

memset(dummy,'\0',100);

textcolor(YELLOW);
sprintf(dummy,"\n%s %s  Copyright %s Simon Avery\n",NAME,VER,__DATE__); // Say hello
center(dummy,1);

}
void do_extra_banner(char *txt)
{
int oldy=wherey();

textbackground(BLUE);
textcolor(LIGHTCYAN);

gotoxy(3,4);
cprintf("Function: [%s]",txt);

gotoxy(1,oldy);
}

void quit(int errlev, char *errmsg)
{
char dummy5[81];
FILE *logfp;
struct time t;
struct date d;
textattr(WHITE);
clrscr();
textbackground(BLUE);
tm_window(1,1,80,1,WHITE);
textcolor(YELLOW);
sprintf(dummy5,"%s %s Copyright "__DATE__" Simon Avery",NAME,VER);
center(dummy5,2);
gotoxy(1,4);
textattr(WHITE);
cprintf("Closing down\r\n");
cprintf("%d files closed down\r\n",fcloseall());

cprintf("Returning error level %d\r\n",errlev);

switch(errlev)
	{
	case 0:
		cprintf("No problems\r\n");
		break;
	default:
		textattr(LIGHTRED);
		cprintf("A problem occured. (Blame the beta-testers)\r\n");
		if (strlen(logfile))
			{
			textattr(LIGHTMAGENTA);
			cprintf("Writing to Log: ");
			if ((logfp=fopen(logfile,"at"))==NULL)
				{
				if ((logfp=fopen(logfile,"wt"))==NULL)
					{
					textattr(LIGHTRED+BLINK);
					cprintf("Cannot open logfile: [%s]\r\n",logfile);
					break;
					}
				}
			gettime(&t);
			getdate(&d);
			fprintf(logfp,"-U- %.2d/%.2d/%d %.2d:%.2d:%.2d.%.2d Errlev: %d  Reason: %s\r\n",
						d.da_day,
						d.da_mon,
						d.da_year,
						t.ti_hour,
						t.ti_min,
						t.ti_sec,
						t.ti_hund,
						errlev,
						errmsg);
			fclose(logfp);
			cprintf("Written.\r\n");
			}
		textattr(LIGHTRED);
		break;
	}

cprintf("%s\n",errmsg);
textattr(LIGHTGRAY);
_setcursortype(_NORMALCURSOR);

if (errlev)	wait(30);

exit(errlev);
}

void help(char *hlptxt)
{
textattr(WHITE);
clrscr();
puttext(1,1,80,25,IMAGEDATA);
textbackground(BLUE);
textcolor(WHITE);
sprintf(dummy,"%s %s",NAME,VER);
center(dummy,2);
textattr(WHITE);
center(hlptxt,5);
getch();
puttext(1,1,80,25,IMAGEDATA2);
textbackground(BLUE);
textcolor(WHITE);
center(dummy,2);
textattr(WHITE);
center(hlptxt,5);
getch();
}

void tm_window(int tlx,int tly,int width,int height,int col)
{
int jj=(tly+1);
int winjunk,winjunk2;

textcolor(col);
gotoxy(tlx,tly);

cprintf("�");
for (winjunk=0; winjunk!=(width-2); winjunk++)	{ cputs("�"); }
cputs("�");

for (winjunk = 0;winjunk != height;winjunk++)
	     {
	     textcolor(col);
	     gotoxy(tlx,jj);
		//	 tlx,jj);
	     cputs("�");
	     for (winjunk2=0; winjunk2!=(width-2); winjunk2++)	{ cputs(" "); }
	     cputs("�");
	     jj++;
	     }

textcolor(col);
gotoxy(tlx,jj);
cputs("�");
for (winjunk=0; winjunk!=(width-2); winjunk++)	{ cputs("�"); }
cputs("�");
}

char *rmtrail(char *lin)
{
junk=strlen((char *)lin);

while(junk >=0)
	{
	junk--;
	if (!isspace(lin[junk])) break;
	lin[junk]='\0';
	}

return (char*)lin;
}

char *rmlead(char *str)
{
char *obuf;

for (obuf=str; obuf && *obuf && isspace(*obuf); ++obuf)
	;
if ((char *)str !=obuf)		strcpy((char*)str,obuf);

return str;
}

void missing_file(char *filnm)
{
sprintf(dumtag,"Error!\r\n%s had problems accessing file: [%s]",NAME,filnm);
quit(11,dumtag);
}

int check_4_dupe(char *newtag, int usebox)
{
FILE *tg;
char dummy2[TAGLEN];	// to save overwriting dumtag etc which may be in use
char rslt=0;

if (usebox)		// * poss reposition cursor if usebox
	{
	box_error("Checking for dupes...");
	}

if ((tg=fopen(tagfile,"rt"))==NULL)		return 0;

	// check it for filtered words first

for (junk=0; junk!=10; junk++)
	{
	if (strlen(filt_str[junk]) > 3 )	// only do it if it's got something in it
		{
		if (strstr(newtag,filt_str[junk]))
			{
			fclose(tg);
			return 2;
			}
		}
	}

	// check it against every tag in file (yawn)

while (fgets(dummy2,TAGLEN,tg))
	{
	if (!strcmp(newtag,dummy2))
		{
		fclose(tg);
		return 1;
		}
	}
fclose(tg);

return rslt;
}

int kill_file(char *filnm)
{
int amode;

amode = S_IREAD|S_IWRITE;

chmod(filnm,amode);

return (unlink(filnm));
}

void check_key_abort(void)
{
if (bioskey(1))	if (getkc()==ESC)	quit(1,"Escape was pressed!");
}

void pick_tag(void)
{
FILE *tagfp2;
UCHAR fast_tag;
ULONG tmp=0L,min=0L,max=0L;

load_dat();

//fcloseall();
if ((tagfp2=fopen(tagfile,"rt"))==NULL)
	{
	sprintf(dumtag,"Error picking tag. Cannot locate tagfile [%s]",tagfile);
	box_error(dumtag);
	wait(10);
	missing_file(tagfile);
	}

if (tot_tags > 3000L)
	{
	fast_tag=1;
	}
	else
	{
	fast_tag=0;
	}

if (fast_tag)
	{
	max=(last_tag+160);

	if (last_tag < 160)
		{ min=0; }
		else
		{ min=(last_tag-160); }

	goto Pick_Again;

	Pick_Again:
	;

	chosen=longrand(filesize);

	if ((chosen>min) && (chosen < max))	goto Pick_Again;


	if (chosen<=0)
		{
		return;
		}

	fseek(tagfp2,chosen,SEEK_SET);
	fgets(tagline,TAGLEN,tagfp2);	// to end of line
	fgets(tagline,TAGLEN,tagfp2);
	}
	else
	{
	do {(chosen=random(tot_tags)+1); } while (chosen==last_tag);

	if (chosen==0) chosen=1;

	while (tmp < chosen)
		{
		fgets(tagline,TAGLEN,tagfp2);

		if (ferror(tagfp2))	{ strcpy(tagline,"Error getting tag from tagfile! [1]"); break; }

		tmp++;
		}
	}

rmtrail(tagline);

if (strlen(tagline)<2)
	{
//	sprintf(dummy,"Tagline too short: [%s]",tagline);
//	working(dummy);
	strcpy(tagline,"Error getting tag from tagfile! [2] (Too short)");
	}

fclose(tagfp2);

last_tag=chosen;
}

void count_taglines(void)
{
FILE *dat;
FILE *tag;

struct stat statbuf;
ULONG old_tagfilesize;
ULONG old_tot_tags;

get_datfile_name();

stat(tagfile,&statbuf);		// get details of tagfile

if ((dat=fopen(DATFILE,"rb")) !=NULL)	// it exists
	{
	textattr(WHITE);
	cprintf("Using index file: [%s]\r\n",DATFILE);
//	working(dummy);
	fscanf(dat,"%ld,%ld",
				&old_tagfilesize,
				&old_tot_tags);

	fclose(dat);

	if (old_tagfilesize!=statbuf.st_size)           // it's changed
		{

		if (kill_file(DATFILE))
			{
			sprintf(dummy,"Unable to delete index file: [%s]",DATFILE);
			quit(2,dummy);
			}

		if ((tag=fopen(tagfile,"rt"))==NULL) { quit(34,"File Error (count_taglines[1]) Tagfile not found!"); }

		if (statbuf.st_size > old_tagfilesize)
				{
				cprintf("Tagfile's changed - Bigger\r\n");
				tot_tags=(old_tot_tags-1);	// -1 to allow for trailing CR

				fseek(tag,old_tagfilesize,SEEK_SET);

				while (fgets(tagline,TAGLEN,tag))
					{
					tot_tags++;
					if (strlen(tagline) < 3) tot_tags--;
					}
				}
				else
				{
				cprintf("Tagfile's changed - Smaller\r\n");
				tot_tags=0L;
				while (fgets(tagline,TAGLEN,tag))
					{
					tot_tags++;
					if (strlen(tagline) < 3) tot_tags--;
					}
				}
		filesize=statbuf.st_size;
		fclose(tag);
//		save_dat();
		}
		else
		{
		cprintf("Filesize not changed\r\n");
		filesize=statbuf.st_size;
		tot_tags=old_tot_tags;
		}
	}
	else		// can't open, got to create datafile
	{
	tot_tags=0L;
	// problem is here

	if ((tag=fopen(tagfile,"rt"))==NULL) 	missing_file(tagfile);

	cprintf("Woo! New tagfile! Counting...\r\n");

	while (fgets(tagline,TAGLEN,tag))	tot_tags++;

	filesize=statbuf.st_size;
	fclose(tag);
//	save_dat();
	}

}

void load_dat(void)
{
FILE *dat;

if ((dat=fopen(DATFILE,"rb"))!=NULL)
	{
	fscanf(dat,"%lu,%lu,%lu,%lu",				// huh?
					&last_tag,
					&last_tag,
					&last_tag,
					&last_tag);
	fclose(dat);
	}
}

void get_datfile_name(void)		// resolve file.tag to file.idx
{
memset(DATFILE,'\0',MAXPATH);
for (junk=0; tagfile[junk]!=0; junk++)
	{
	if (junk>MAXPATH)	break;
	if (tagfile[junk]=='.') break;

	DATFILE[junk]=tagfile[junk];
	}

strcat(DATFILE,".IDX");
}

void dupe_check(void)	// de-dupe global tagfile (needs sorting - errcheck)
{
FILE *tmp,*dupefile;
ULONG tot_ok=0L, tot_bad=0L, tot_filtered=0L;

int last_letter,last_letter_done=0,key_press;

if (sort_bfr_dupe)
	{
	textbackground(BLACK);
	clrscr();
	sprintf(dumtag,"TSORT %s",tagfile);
	execute(dumtag);
	textbackground(BLACK);
	clrscr();
	draw_tm_box();
	}


tot_tags=0L;

textbackground(RED);
tm_window(1,6,80,3,WHITE);
gotoxy(3,6);
cprintf("� Dupe-Checking tagfile: [%s] (ESC = Abort) �",tagfile);

dupe_check_window(tot_bad,tot_filtered);

gotoxy(1,1);

if (strlen(dupetagfile))
	{
	textattr(WHITE);
	cprintf("DupeFile: [%s]\r\n",dupetagfile);
	wait(5);
	}

		// check if temp file exists first.
if (access("NOT-DUPE.TAG",0)==0)
	{
	textattr(YELLOW);
	cputs("Temp file: NOT-DUPE.TAG exists! Over-write? (Y/n)\r\n");
	switch(toupper(getch()))
		{
		case 'N':
			quit(0,"Temporary file: NOT-DUPE.TAG existed");
			break;
		default:
			break;
		}
	}

if ((msg=fopen(tagfile,"rt"))==NULL)		missing_file(tagfile);
if ((tmp=fopen("NOT-DUPE.TAG","wt"))==NULL)	missing_file("NOT-DUPE.TAG");

if (strlen(dupetagfile))
	{
	if ((dupefile=fopen(dupetagfile,"at"))==NULL)	missing_file(dupetagfile);
	}

fgets(dumtag,TAGLEN,msg);		// prime dumtag
fputs(dumtag,tmp);

last_letter='A';
	// main loop
while(fgets(tagline,TAGLEN,msg))
	{
	if (bioskey(1))
		{                                    	// is it alpha sorted?
		key_press=getkc();
		if (key_press==ESC)
			{ quit(1,"You pressed ESC!"); }
		}
	if ((!last_letter_done) && (last_letter < toupper(tagline[0])))
		{
		textattr(LIGHTRED);
		cputs("File doesn't appear to have been alpha-sorted! May not work properly.\r\n");
		last_letter_done++;
		}
		else
		{		// prime it for next time
		last_letter_done=(toupper(tagline[0]));
		}

	tot_tags++;
	if (strlen(tagline) < 2)
		{
		textattr(LIGHTGREEN);
		cprintf("Tag too short  (Tagline: %lu:[%s])\r\n",tot_tags,tagline);
		goto Rest;
		}
			// check for filter words
	for (junk=0; junk!=10; junk++)
		{
		if (strlen(filt_str[junk]))	// only do it if it's got something in it
			{
			if (strstr(tagline,filt_str[junk]))
				{		// filter - discard
				textattr(LIGHTCYAN);
				tot_filtered++;
				rmtrail(tagline);
				cprintf("Filtered: %.68s\r\n",tagline);
				if (strlen(dupetagfile))
					{
					fprintf(dupefile,"%s\n",tagline);
					}
				goto Rest;
				}
			}
		}

	switch(fuzzy_dupe)
		{
		case 0: 	// not - do exact comparison
			if (!strcmp(tagline,dumtag))
				{
				rmtrail(tagline);
				textattr(LIGHTBLUE);
				cprintf("Duped: %.68s\r\n",tagline);
				tot_bad++;
				if (strlen(dupetagfile))
					{
					fprintf(dupefile,"%s\n",tagline);
					}
				}
				else	// it's not duped
				{
				strcpy(dumtag,tagline);
				rmtrail(tagline);
				fprintf(tmp,"%s\n",tagline);	// write it to temp file
				tot_ok++;
				}
			break;
		default:	// yes - do fuzzy check
			if (exact_check(tagline,dumtag))
				{
				textattr(LIGHTBLUE);
				rmtrail(tagline);
				cprintf("Fuzzy-duped: %.65s\r\n",tagline);
				tot_bad++;
				if (strlen(dupetagfile))
					{
					fprintf(dupefile,"%s\n",tagline);
					}
				}
				else
				{
				strcpy(dumtag,tagline);
				rmtrail(tagline);
				fprintf(tmp,"%s\n",tagline);
				tot_ok++;
				}
			break;
		}
	goto Rest;

	Rest:;

	dupe_check_window(tot_bad,tot_filtered);
	}

window(1,1,80,25);
fclose(msg);
fclose(tmp);
fclose(dupefile);

textattr(BROWN);
cputs("Copying files...\r\n");

if (unlink(BACKUP_FILE))	non_fatal_error("Unable to delete backup file: [OLDTAGS.TAG]");

if (rename(tagfile,BACKUP_FILE))
	{
	quit(7,"Unable to rename tagfile prior to copying tempfile.\r\nNote that de-duped file is called NOT-DUPE.TAG\r\n");
	}

if (rename("NOT-DUPE.TAG",tagfile))
	{
	sprintf(dummy,"Unable to rename temp file: [NOT-DUPE.TAG] to\r\ntagfile: [%s]",tagfile);
	quit(8,dummy);
	}

textattr(WHITE);
cputs("Finished. Press a key or wait...\r\n");
wait(30);

sprintf(dummy,"Finished. Total: [%lu]  Dupes: [%lu]\r\nFiltered: [%lu]  Written: [%lu]",
							tot_tags,
							tot_bad,
							tot_filtered,
							tot_ok);
quit(0,dummy);
}

void dupe_check_window(ULONG duped_t, ULONG filtered_t)
{
int oldx=wherex();
int oldy=wherey();
float d_pct,f_pct;

window(1,1,80,25);
textbackground(RED);

if (!duped_t)		// no total - so only shown first time
	{
	textcolor(WHITE);
	gotoxy(4,7);
	cputs("Good / Total Tags:");
	gotoxy(4,8);
	cputs("Duped Taglines   :");
	gotoxy(4,9);
	cputs("Filtered Taglines:");

	gotoxy(40,7);
	cputs("Method      : ");
	textcolor(YELLOW);
	switch(fuzzy_dupe)
		{
		case 0:
			cputs("Exact");
			break;
		case 1:
			cputs("Fuzzy");
			break;
		default:
			cputs("God-Knows");
			break;
		}
	textcolor(WHITE);
	gotoxy(40,8);
	cputs("Temp File   : ");
	textcolor(YELLOW);
	cputs("NOT-DUPE.TAG");
	textcolor(WHITE);
	gotoxy(40,9);
	cputs("Backup File : ");
	textcolor(YELLOW);
	cputs(BACKUP_FILE);
	}

textcolor(YELLOW);
gotoxy(24,7);
cprintf("%-5lu / %-5lu",(tot_tags-duped_t),tot_tags);
gotoxy(24,8);

if (tot_tags)
	{
	d_pct=((float)duped_t/tot_tags);
	f_pct=((float)filtered_t/tot_tags);
	d_pct*=100;
	}
	else
	{
	d_pct=0;
	f_pct=0;
	}

cprintf("%-5lu (%.1f%%)  ",duped_t,d_pct);
gotoxy(24,9);
cprintf("%-5lu (%.1f%%)  ",filtered_t,f_pct);
textbackground(BLACK);
window(1,11,80,25);
gotoxy(oldx,oldy);
}

void non_fatal_error(char *reason)
{
textattr(BROWN);
tm_window(5,5,70,5,WHITE);
textattr(RED);
sprintf(dummy,"Non-Fatal-Error: [%s]",reason);
center(dummy,6);
textattr(WHITE);
center("Although this error is not serious enough to halt T-Matic,",8);
center("it may produce unwanted results. If this error persists, please ",9);
center("rectify it, or netmail the author.",10);

wait(60);
}

int exact_check(char *str1, char *str2)
{
//char dum1[TAGLEN];
//char dum2[TAGLEN];
char *dum1;
char *dum2;
char *dum3;
char *dum4;
UCHAR ret1=0;

int off1=0,j;

if ((dum1=(char *) malloc(TAGLEN)) ==NULL)	quit(82,"Out of memory in fuzzy_check routine1");
if ((dum2=(char *) malloc(TAGLEN)) ==NULL)	quit(82,"Out of memory in fuzzy_check routine2");
if ((dum3=(char *) malloc(TAGLEN)) ==NULL)	quit(82,"Out of memory in fuzzy_check routine3");
if ((dum4=(char *) malloc(TAGLEN)) ==NULL)	quit(82,"Out of memory in fuzzy_check routine4");

memset(dum1,'\0',TAGLEN);
memset(dum2,'\0',TAGLEN);
memset(dum3,'\0',TAGLEN);
memset(dum4,'\0',TAGLEN);

strcpy(dum3,str1);
strcpy(dum4,str2);
rmtrail(dum3);
rmtrail(dum4);
strupr(dum3);
strupr(dum4);
					// do a comp only on alpha chars

for (j=0,off1=0; j!=strlen(str1); j++)
	{
	if ((isalpha(dum3[j])) || (isdigit(dum3[j])))
		{
		dum1[off1]=dum3[j];
		off1++;
		}
	}

for (j=0, off1=0; j!=strlen(str2); j++)
	{
	if ((isalpha(dum4[j])) || (isdigit(dum4[j])))
		{
		dum2[off1]=dum4[j];
		off1++;
		}
	}
/*
for (junk=0; junk!=TAGLEN; junk++)
	{
	if (isalpha(str1[junk]))
		{
		dum1[off1]=str1[junk];
		off1++;
		}

	if (isalpha(str2[junk]))
		{
		dum2[off2]=str2[junk];
		off2++;
		}
	}*/

if (!strcmp(dum1,dum2))	ret1=1;		// don't match

free(dum1);
free(dum2);
free(dum3);
free(dum4);

return ret1;
}

void replace_word_tagfile(void)
{
FILE *cfg,*out,*tag;
//struct { tofind[21]; toreplace[21]; } srch[200];
char tofind[200][21];
char toreplace[200][21];
int srchfnd=0,flib;
ULONG totreplaced=0L;

textattr(WHITE);
cprintf("Replacing words.\r\n");
textattr(YELLOW);
cprintf("Tagfile: [%s]\r\n",tagfile);
cprintf("Cfgfile: [%s]\r\n",CFGFILE);
cprintf("BakFile: [%s]\r\n",BACKUP_FILE);

if ((cfg=fopen(CFGFILE,"rt"))==NULL)	quit(81,"Unable to open cfgfile");

while (fgets(dummy,200,cfg))
	{
	if ((strstr(dummy,"TagFileSearchReplace")) && (dummy[0]!='%'))
		{
		if (srchfnd > 200)	quit(82,"Too many TagFileSearchReplace entries in cfg");

		memset(tofind[srchfnd],'\0',21);

		for (flib=21; flib<=38; flib++)
			{
			if (dummy[flib]=='\0')	break;
			tofind[srchfnd][flib-21]=dummy[flib];
			}
		rmtrail(tofind[srchfnd]);

		memset(toreplace[srchfnd],'\0',21);
		for (flib=39; flib!=strlen(dummy); flib++)
			{
			if (dummy[flib]=='\0')	break;
			toreplace[srchfnd][flib-39]=dummy[flib];
			}
		rmtrail(toreplace[srchfnd]);

		srchfnd++;
		}
	}

fclose(cfg);

textattr(GREEN);
for (flib=0; flib!=srchfnd; flib++)
	{
	cprintf("        Replace: [%s] with [%s]\r\n",
						tofind[flib],
						toreplace[flib]);
	}

unlink(BACKUP_FILE);

if (rename(tagfile,BACKUP_FILE))		quit(70,"Unable to create bakup file");

if ((out=fopen(tagfile,"wt"))==NULL)		quit(71,"Unable to create backup file");
if ((tag=fopen(BACKUP_FILE,"rt"))==NULL)	quit(72,"Unable to open new tagfile");

textattr(WHITE);
cputs("Working..");
textattr(WHITE+BLINK);
cputs(".\r\n");

textattr(LIGHTGREEN);

while(fgets(tagline,TAGLEN,tag))
	{
	for (flib=0; flib<srchfnd; flib++)
		{
		if (!strlen(tofind[flib]))	break;

		if (strstr(tagline,tofind[flib]))
			{
			rmtrail(tagline);
			strrepl(tagline,TAGLEN,tofind[flib],toreplace[flib]);

			cprintf("Replaced: %.68s\r\n",tagline);
			strcat(tagline,"\n");
			totreplaced++;
			break;
			}
		}

	fputs(tagline,out);

	tot_tags++;

	check_key_abort();
	}

fclose(tag);
fclose(out);

textattr(WHITE);
cputs("Finished.\r\n");
cprintf("[%ld] tags processed.\r\n",tot_tags);
cprintf("[%ld] tags altered.\r\n",totreplaced);

wait(20);

sprintf(dummy,"%ld/%ld tags altered.",totreplaced,tot_tags);
quit(0,dummy);
}

void filter_non_punct(void)
{
FILE *in,*out,*bak,*cfg;
char dodupe=0;
char it,done;

textattr(WHITE);
cprintf("Filtering non-punctuated ending tags.\n\r");
textattr(YELLOW);
cprintf("Tagfile: [%s]\r\n",tagfile);
cprintf("CfgFile: [%s]\r\n",CFGFILE);

if ((cfg=fopen(CFGFILE,"rt"))==NULL)	quit(6,"Unable to open configfile");

if (strlen(dupetagfile))
	{
	cprintf("DupeFile: [%s]\r\n",dupetagfile);
	dodupe=1;
	}
	else
	{
	textattr(LIGHTGREEN);
	cprintf("No dupetagfile - deleting.\r\n");
	}

fclose(cfg);

if ((in=fopen(tagfile,"rt"))==NULL)		quit(7,"Unable to open tagfile");
if ((out=fopen(BACKUP_FILE,"wt"))==NULL)	quit(8,"Unable to open temp file");
if (dodupe)	if ((bak=fopen(dupetagfile,"at"))==NULL) quit(9,"Unable to open duped tagfile");

textattr(WHITE);

while (fgets(tagline,TAGLEN,in))
	{
	tot_tags++;

	rmtrail(tagline);
	it = tagline[strlen(tagline)-1];

	done=0;

	if ((it > 32) && (it < 48))	done=1;
	if ((it > 57) && (it < 65))	done=1;
	if ((it > 90) && (it < 97))	done=1;

	if (done)
		{
		tot_found++;
		fprintf(out,"%s\n",tagline);
		}
		else
		{
		chosen++;
		if (dodupe)	fprintf(bak,"%s\n",tagline);
		}

	cprintf("\rTotal Tags: [%lu]  Ok [%lu]  Bad [%lu]  ",
								tot_tags,
								tot_found,
								chosen);
	}

fclose(in);
fclose(out);
fclose(bak);

unlink(tagfile);

if (rename(BACKUP_FILE,tagfile))
	{
	textattr(LIGHTRED);
	cprintf("Problem: Unable to change temp file [%s] to tagfile.\r\n");
	wait(20);
	quit(8,"Unable to rename temp to tagfile");
	}

textattr(LIGHTGREEN);
cprintf("\r\nFinished.\r\n");
wait(10);
quit(0,"Process complete.");
}

void cross_dupecheck(void)
{
FILE *tag1,*tag2,*tmp,*save;
int j,l;

if (sort_bfr_dupe)
	{
	memset(dumtag,0,TAGLEN);
	cprintf("Sorting tagfiles...\r\n");
	sprintf(dumtag,"TSORT %s",tagfile);
	execute(dumtag);
	memset(dumtag,0,TAGLEN);
	sprintf(dumtag,"TSORT %s",msgfile);
	execute(dumtag);
	}
	else
	{
	cprintf("Not sorting. Assuming both files are sorted.\r\n");
	}

textattr(WHITE);
cprintf("Crossfile Dupe-Checking.\r\n");
textattr(YELLOW);
cprintf("File #1: [%s]\r\nFile #2: [%s]\r\n",tagfile,msgfile);

textattr(LIGHTGRAY);
if (fuzzy_dupe) cputs("Fuzzy Checking."); else cputs("Exact Checking");


if ((tag1=fopen(tagfile,"rt"))==NULL)	quit(71,"Tagfile 1 does not exist");
if ((tag2=fopen(msgfile,"rt"))==NULL)	quit(72,"Tagfile 2 does not exist");
if ((tmp=fopen(TEMP_FILE,"wt"))==NULL)	quit(75,"Unable to create temp file");

if (strlen(dupetagfile))
	{
	if ((save=fopen(dupetagfile,"at"))==NULL)	quit(73,"Unable to open DupedTagFile");
	}

tot_tags=0L;
tot_found=0L;

textattr(LIGHTBLUE);
cputs("\n");




while(fgets(tagline,TAGLEN,tag1))
	{
	rewind(tag2);
	rmtrail(tagline);

	l=0;

	while (fgets(dumtag,TAGLEN,tag2))
		{
		rmtrail(dumtag);
		if (fuzzy_dupe)
			{
			if (exact_check(tagline,dumtag))	{ l=1; break; }
			}
			else
			{
			if (!strcmp(tagline,dumtag))		{ l=1; break; }
			}
		if (tagline[0] < dumtag[0]) break;  // overrun
		}

	if (l)
		{
		if (strlen(dupetagfile))
			{
			fprintf(save,"%s\n",tagline);
			}
		tot_found++;
		}
		else
		{
		fprintf(tmp,"%s\n",tagline);
		}

	tot_tags++;

	cprintf("\rTags Processed: [%lu]  Duped: [%lu]",tot_tags,tot_found);

	check_key_abort();

	if (feof(tag1))	break;
	}

fclose(tag1);
fclose(tag2);
fclose(tmp);
fclose(save);

unlink(BACKUP_FILE);

if (rename(tagfile,BACKUP_FILE))	quit(76,"Unable to rename tagfile to backup file.");
if (rename(TEMP_FILE,tagfile))		quit(77,"Unable to rename temp file to tagfile");

textattr(LIGHTCYAN);
cprintf("\r\n\nProcess finished.\r\n");

wait(5);

sprintf(dummy,"Cross-Check complete. %lu tags checked. %lu were duped.",tot_tags,tot_found);
quit(0,dummy);
}

void tagfile_toss(void)
{
FILE *in,*out;

char ctrlwords[50][42];
char ctrlfiles[50][15];
UCHAR foundit;
int numfound=0,junk;

textattr(WHITE);
cprintf("Tagline Tossing!\r\n");
textattr(YELLOW);
cprintf("Tagfile:      [%s]\r\n",tagfile);
cprintf("Control File: [%s]\r\n",msgfile);

textattr(LIGHTGRAY);
cprintf("Reading Control File...  ");

if ((in=fopen(msgfile,"rt"))==NULL)	missing_file(msgfile);


while(fgets(tagline,TAGLEN,in))
	{
	if ((strstr(tagline,"Entry")) && (tagline[0]=='E') && (numfound < 50))
		{
//		rmtrail(tagline);
		memset(ctrlwords[numfound],'\0',42);
		memset(ctrlfiles[numfound],'\0',15);

		for (junk=6; junk!=27; junk++)
			{
			if (tagline[junk]==0)	quit(23,"Short line Error in Ctrl file");
			ctrlwords[numfound][junk-6]=tagline[junk];
			}

		rmtrail(ctrlwords[numfound]);
		strupr(ctrlwords[numfound]);

		for (junk=28; junk!=strlen(tagline); junk++)
			{
			ctrlfiles[numfound][junk-28]=tagline[junk];
			}
		rmtrail(ctrlfiles[numfound]);
		strupr(ctrlfiles[numfound]);

		//
//		cprintf("\r\n[%s] [%s]\n",ctrlwords[numfound],ctrlfiles[numfound]);

		numfound++;
		}
	}
cprintf("[%d] entries found and parsed.\r\n",numfound);

fclose(in);

if (!numfound)
	{
	textattr(WHITE);
	cprintf("Not enough entries to continue\r\n");
	wait(10);
	quit(1,"Not enough entries in control file for toss-tag");
	}

textattr(WHITE);
cprintf("Working..");
textattr(WHITE+BLINK);
cputs(".\r\n");

if ((in=fopen(tagfile,"rt"))==NULL)	missing_file(tagfile);

while(fgets(tagline,TAGLEN,in))
	{
	foundit=0;
	tot_tags++;

	strcpy(dumtag,tagline);
	strupr(dumtag);

	for (junk=0; junk!=numfound; junk++)
		{
		if (strstr(dumtag,ctrlwords[junk]))	//hit
			{
			textattr(WHITE);
			cputs("\r");
			clreol();
			cprintf("Hit! (Tag: %ld) ",tot_tags);
			textattr(LIGHTBLUE);
			cprintf("[%s] found. Writing to [%s]",ctrlwords[junk],ctrlfiles[junk]);

			if ((out=fopen(ctrlfiles[junk],"at"))==NULL)	missing_file(ctrlfiles[junk]);

			fputs(tagline,out);
			fclose(out);
			tot_found++;
			foundit=1;
			}
		if (foundit)	break;
		}
	check_key_abort();
	}

fclose(in);

textattr(WHITE);
cprintf("\r\nFinished. [%lu] tossed from a total of [%lu] taglines.\r\n",tot_found,tot_tags);
wait(10);
quit(0,"Toss-Tag finished successfully");

}
	// replace regstring in Termail.cfg
void termail_replace_regstring(void)
{
FILE *txt,*cfg,*newcfg;

do_extra_banner("Random Termail RegString");

textattr(WHITE);
cprintf("RegString File: [%s]\r\n",tagfile);
cputs("Backup TM.CFG: [TM-OLD.BAK]\r\n");

unlink("TM-OLD.BAK");

if (rename("TM.CFG","TM-OLD.BAK"))
	{
	textattr(LIGHTRED);
	cprintf("Fatal Error!\r\n");
	cprintf("TM.CFG may have been renamed to TM-OLD.BAK!\r\n");
	wait(30);
	quit(23,"Error renaming TM.CFG");
	}

if ((txt=fopen(tagfile,"rt"))==NULL)	{ quit(82,"Unable to open RegString txtfile"); }

tot_tags=0L;
while(fgets(tagline,TAGLEN,txt))	tot_tags++;

rewind(txt);

chosen=random(tot_tags+1);

for (junk=0; junk!=chosen; junk++)	fgets(tagline,TAGLEN,txt);

rmtrail(tagline);
fclose(txt);

textattr(LIGHTCYAN);
cprintf("Chosen entry: [%.39s]\r\nSearching TM.CFG\r\n",tagline);

if ((cfg=fopen("TM-OLD.BAK","rt"))==NULL)	{ quit(83,"Unable to open TM-OLD.BAK"); }

if ((newcfg=fopen("TM.CFG","wt"))==NULL)	{ quit(84,"Unable to open TM.CFG for writing"); }

while(fgets(dumtag,TAGLEN,cfg))
	{
	if ((strstr(dumtag,"AddToTearline")) && (dumtag[0]!='%'))
		{
		rmtrail(dumtag);
		cprintf("Found entry: [%.39s]\r\n",dumtag);
		fprintf(newcfg,"AddToTearline   %.39s\n",tagline);
		}
		else
		{
		fputs(dumtag,newcfg);
		}
	}
fclose(newcfg);
fclose(cfg);

textattr(WHITE);
cputs("Finished.");
wait(10);

quit(0,"RegString replacer finished normally.");
}
