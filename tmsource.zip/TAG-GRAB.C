/*

small util to grab tags from message conforming to [Begin Tag] thing

*/

#include <stdio.h>

char oneline[101];
char startline[101];
char endline[101];

unsigned long tot_tags=0L;

char *rmtrail(char *);


int main(int argc, char *argv[])
{
FILE *in, *out, *cfg;
char found;

printf("Tag-Grab V.1  Freeware by Simon Avery\n");

if (argc!=3)
	{
	printf("Usage: %s [MsgFile] [Tagfile]\n");
	exit(1);
	}

if ((cfg=fopen("TAG-GRAB.CFG","rt")) == NULL)	{ printf("Cannot open cfg file: TAG-GRAB.CFG\n"); exit(2); }

fgets(startline,100,cfg);
fgets(endline,100,cfg);
fclose(cfg);
rmtrail(startline);
rmtrail(endline);

printf("StartLine = [%s]\n",startline);
printf("EndLine   = [%s]\n",endline);

if ((in=fopen(argv[1],"rt"))==NULL)		{ printf("Cannot open infile [%s]\n",argv[1]); exit(3); }
if ((out=fopen(argv[2],"at"))==NULL)		{ printf("Cannot open tagfile [%s]\n",argv[2]); exit(4); }

while (fgets(oneline,100,in))
	{
	found=0;
	if (strstr(oneline,startline))
		{
		printf("Found StartLine. Stealing...\n");
		while (fgets(oneline,100,in))
			{
			if (strstr(oneline,endline))
				{
				printf("\nFound EndLine. Stopping Steal.\n");
				found=1;
				}
				else
				{
				if (strlen(oneline)>4)
					{
					fputs(oneline,out);
					printf("Stolen [%lu] tags...     \r",tot_tags++);
					}
					else
					{
					printf("Line too short: %s\r",oneline);
					}
				}
			if (found) break;
			}
		}
	}

fclose(in);
fclose(out);
printf("\nFinished. [%lu] tags stolen.\n",tot_tags);

return 0;
}


char *rmtrail(char *lin)
{
int jnk;

jnk=strlen(lin);
while(jnk >= 0)
	{
	jnk--;
	if (!isspace(lin[jnk])) break;
	lin[jnk]=0;
	}
return lin;
}








