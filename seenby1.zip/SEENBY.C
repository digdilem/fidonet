// Widget for Neil Croft - strip SEENBY's from Opus base.


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dir.h>	// for findfirst

//#include "msg-head.h"

char * rmtrail(char *);
void chpath(char *);
char *current_directory(char *);


int main(int argc, char * argv[])
{
FILE *out,*msg;
unsigned long totmsg=0L,totbytes=0L,totlines=0L;
char homedir[101],dummy[501];
struct ffblk ff;
int done;

printf("Seen-by stripper. Simon Avery (For Neil Croft)\n");

if (argc!=3)
	{
	printf("Usage: %s (Opus dir) (Textfile)\n",argv[0]);
	return 1;
	}

strupr(argv[1]);
strupr(argv[2]);

current_directory(homedir);
printf("Home path: %s\n",homedir);

if ((out=fopen(argv[2],"at"))==NULL)
	{
	printf("Unable to create outfile: %s\n",argv[2]);
	return 2;
	}

chpath(argv[1]);

done=findfirst("*.MSG",&ff,0);

while(!done)
	{
	printf("Current message: %s\r",ff.ff_name);

	if ((msg=fopen(ff.ff_name,"rt"))==NULL)
		{
		printf("\nUnable to access file: %s\n",ff.ff_name);
		}
		else
		{
		while(fgets(dummy,500,msg))
			{
			if (strstr(dummy,"SEEN-BY"))
				{
				totlines++;
				rmtrail(dummy);
				totbytes+=strlen(dummy);
				fprintf(out,"%s\r\n",dummy);
				}
			}
		fclose(msg);
		totmsg++;
		}
	done=findnext(&ff);
	}
fclose(out);

printf("\nFinished.\n");
printf("\t%lu messages processed.\n",totmsg);
printf("\t%lu SEEN-BY lines grabbed.\n",totlines);
printf("\t%lu bytes appended to %s\n",totbytes,argv[2]);

chpath(homedir);

return 0;
}
void chpath(char *newpath)
{
printf("Changing to: %s\n",newpath);
if (strchr(newpath,':')) setdisk(newpath[0]-65);

if (chdir(newpath))
		{
		printf("Unable to change to directory: %s\n",newpath);
		exit(6);
		}
}

char *current_directory(char *path)
{
   strcpy(path, "X:\\");      /* fill string with form of response: X:\ */
   path[0] = 'A' + getdisk();    /* replace X with current drive letter */
   getcurdir(0, path+3);  /* fill rest of string with current directory */
   return(path);
}



char * rmtrail(char * lin)
{
int jnk;

jnk=strlen(lin);
while(jnk >= 0)
	{
	jnk--;
	if (!isspace(lin[jnk])) break;
	lin[jnk]=0;
	}
return lin;
}
