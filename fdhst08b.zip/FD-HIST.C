/*
Wee util to generate stats report for the preceeding day.

Usage: FD-HIST [Outputfile]

*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <dir.h>
#include <time.h>

#include "d:\tc\fdstructs\lastcall.h"

#define VER "0.8b"

int main(int argc, char *argv[])
{
char fd_path[MAXPATH];
char dummy[200];
char sysopname[38];
char bbsname[51];
char bbslocation[51];

FILE *in,*out;
unsigned int totin=0, totout=0;
unsigned long totoutB=0L, totinB=0l, totimein=0L, totimeout=0L;

struct date d;
time_t t;

LASTCALL l;

printf("Fd-History %s info generator. (Free) By Simon Avery\n",VER);

getdate(&d);

if (argc!=2)
	{
	printf("Usage: %s [OutputInfoFile]\n",argv[0]);
	return 1;
	}

strcpy(fd_path,getenv("FD"));

if (fd_path[0]==0)
	{
	printf("Error! FD environment not set!\n");
	}

sprintf(dummy,"%s\\SETUP.FD",fd_path);
printf("Reading: %s...\n",dummy);

if ((in=fopen(dummy,"rb"))==NULL)
	{
	printf("Unable to open Setup details.\n");
	return 6;
	}

fseek(in,10069,SEEK_SET);
fgets(sysopname,37,in);
fseek(in,11287,SEEK_SET);
fgets(bbsname,50,in);
fseek(in,11337,SEEK_SET);
fgets(bbslocation,50,in);

printf("Sysop: %s\n",sysopname);
printf("BBS: %s\n",bbsname);
printf("Location: %s\n",bbslocation);

fclose(in);

sprintf(dummy,"%s\\LASTCALL.FD",fd_path);
printf("Reading: %s...\n",dummy);

if ((in=fopen(dummy,"rb"))==NULL)
	{
	printf("Unable to open LastCall file.\n");
	return 7;
	}


fread(&l,sizeof(l),1,in);
fread(&l,sizeof(l),1,in);
fread(&s,sizeof(s),1,in);
fread(&s,sizeof(s),1,in);

fclose(in);

printf("Creating %s...\n",argv[1]);

if ((out=fopen(argv[1],"wt"))==NULL)
	{
	printf("Unable to open output file: [%s]\n",argv[1]);
	return 2;
	}

      fputs("--------------------------------------------------------------\n",out);
fprintf(out,"FrontDoor Recent Activity report for %.2d/%.2d/%.4d\n",
								d.da_day-1,
								d.da_mon,
								d.da_year);

time(&t);

fprintf(out,"Created by Fd-Hist %s (c) Simon Avery at %s",VER,ctime(&t));

      fputs("--------------------------------------------------------------\n",out);

fprintf(out,"Sysop    : %s\n",sysopname);
fprintf(out,"BBS      : %s\n",bbsname);
fprintf(out,"Location : %s\n",bbslocation);

      fputs("--------------------------------------------------\n",out);


      fputs("            |  Total     |  Inbound   |  Outbound\n",out);
      fputs("--------------------------------------------------\n",out);

fprintf(out,"Mail calls  | %10d | %10d | %10d\n",
						l.inbound+l.outbound,
						l.inbound,
						l.outbound);

fprintf(out,"Bytes       | %10lu | %10lu | %10lu\n",
						totinB+totoutB,
						totinB,
						totoutB);

fprintf(out,"Time online | %10lu | %10lu | %10lu  (Seconds)\n",
						totimein+totimeout,
						totimein,
						totimeout);

      fputs("--------------------------------------------------\n",out);

fprintf(out,"Humans In                | %10d |\n",s.humans);

fprintf(out,"Good / Bad Sessions      | %10d | %10d\n",
						s.goodsess,
						s.badsess);
fprintf(out,"File Requests            | %10d\n",
				s.requests);


fclose(out);

printf("Finished.\n");

printf("l=%d\ns=%d\nm=%d\n",sizeof(l),sizeof(s),sizeof(m));

return 0;
}

