/*
find total filespace on a drive (or dir /s)

(c) Simon Avery 1996

*/


#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include <dir.h>
#include <string.h>

void thou_bytes(void);
void get_diskfree(void);
void findpath(char[]);

char origdir[MAXPATH];
char dummy[80];

unsigned long tot_bytes=0L;
unsigned long diskfree=0L;
unsigned long tot_files=0L;
unsigned long tot_dirs=0L;

int main(void)
{

textattr(LIGHTGREEN);
cputs("Disk-Use working...\r\n");

get_diskfree();

sprintf(dummy,"%lu",diskfree);
thou_bytes();

cprintf("Free diskspace: %s\r\n",dummy);


getcurdir(0, origdir);

findpath(origdir);

sprintf(dummy,"%lu",tot_bytes);
thou_bytes();

cprintf("\r\nCompleted.\r\nTotal files: [%lu]\r\nTotal Dirs: [%lu]\r\nTotal Bytes: %s\r\n",
					tot_files,
					tot_dirs,
					dummy);

return 0;
}

void get_diskfree(void)
{
struct dfree free;
int drive;

drive = getdisk();
getdfree(drive+1, &free);
if (free.df_sclus == 0xFFFF)
{
   printf("Error in getdfree() call\n");
   exit(1);
}

diskfree =  (long) free.df_avail
	 * (long) free.df_bsec
	 * (long) free.df_sclus;
}


void findpath(char origpath[MAXPATH])
{
int done = 0;
struct ffblk data;

done = findfirst("*.*", &data, FA_DIREC+FA_SYSTEM+FA_HIDDEN);

while (!done)
	{
	if (((data.ff_attrib & FA_DIREC) == FA_DIREC) && (data.ff_name[0] != '.'))
		{
		chdir(data.ff_name);
		findpath(origpath);
		chdir("..");
		tot_dirs++;
		}

	tot_files++;

	tot_bytes+=data.ff_fsize;

	done = findnext(&data);
	}

}

void thou_bytes(void)
{
char dummy2[15];

strcpy(dummy2,dummy);
strcpy(dummy,"");
switch(strlen(dummy2))
	{
	case 4:
		sprintf(dummy,"%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3]);
		break;
	case 5:
		sprintf(dummy,"%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4]);
		break;
	case 6:
		sprintf(dummy,"%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5]);
		break;
	case 7:
		sprintf(dummy,"%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6]);
		break;
	case 8:
		sprintf(dummy,"%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7]);
		break;
	case 9:
		sprintf(dummy,"%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8]);
		break;
	case 10:
		sprintf(dummy,"%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9]);
		break;
	case 11:
		sprintf(dummy,"%c%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9],dummy2[10]);
		break;
	case 12:
		sprintf(dummy,"%c%c%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9],dummy2[10],dummy2[11]);
		break;
	case 13:
		sprintf(dummy,"%c,%c%c%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9],dummy2[10],dummy2[11],dummy2[12]);
		break;
	case 0:
	case 1:
	case 2:
	case 3: // too short to bother with
	default:
		strcpy(dummy,dummy2);
		break;
	}
}


