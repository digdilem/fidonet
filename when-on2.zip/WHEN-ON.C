/*
to read a list of addresses or names and hunt TM.LOG to see when they
were last on, or not.

Turbo C/C++ V.3 DOS
Large memory model (Obscene amount of global data, sorry)

14/01/98 Update. (V.2)
	To allow wildcard logfiles, outputting to same outfile. (New function/rewrite)
		(Graham Print)
	To allow for soft-coded trigger string (match in logfile)
		(Several others asked for this in REGION25)



*/


#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <direct.h>
#include <ctype.h>
#include <dir.h> //ffblk wildcard struct
#include <string.h>

#define MAX_ENTRIES	1000

void change_path(char *path);
void work(char *fil);
char *rmtrail(char *lin);

char name[MAX_ENTRIES][40];  	// now global
char result[MAX_ENTRIES][40];
char modifier[40];	// to match on log line together with entry[x]
int namecnt=0,junk;
int offset=14;
signed char month,domonth=0;
int day,mon;
char firstline[20];
char line[200];
char work_path[MAXPATH]; 	// argv[2] (logfiles) minus filespec. (Dir)

int main(int argc, char *argv[])
{
FILE *out, *cfg;
struct ffblk ff;
struct date d;
int done,logfiles=0;
char home_path[MAXPATH];	// where prog was started

printf("When-On (V.2). (Freeware by Simon Avery 1999)\n");

strcpy(home_path,"X:\\");
home_path[0]='A'+getdisk();
getcurdir(0,home_path+3);

getdate(&d);
month=d.da_mon;

if (argc < 3)
	{
	printf("Usage:\nWHEN-ON cfg_file log_file out_file {month}\n");
	return 1;
	}

if (argc==5)
	{
//	offset=atoi(argv[4]);	// not doing that, using month instead
	month=atoi(argv[4]);
	junk=month;
	domonth=1;

	if (month==0)	month=d.da_mon;
	if (month<0)	month=(d.da_mon + junk); // plus, not minus as it's a negative value

	if (month < 1)	month=12;

	printf("Only checking month #%d\n",month);
	}

if ((cfg=fopen(argv[1],"rt"))==NULL)
	{
	printf("Cannot open cfg_file: %s\n",argv[1]);
	return 2;
	}
if ((out=fopen(argv[3],"wt"))==NULL)
	{
	printf("Cannot open out_file: %s\n",argv[3]);
	return 2;
	}
	// prettify filenames
strupr(argv[1]);
strupr(argv[2]);
strupr(argv[3]);
strupr(argv[4]);
	// read modifier - first line on config.
while(fgets(line,200,cfg))
	{
	if (line[0]!=';')
		{
		strcpy(modifier,rmtrail(line));
		break;
		}
	}
printf("Modifier is [%s]\n",modifier);


while(fgets(line,200,cfg))
	{
	if (namecnt > MAX_ENTRIES-1)
		{
		printf("Too many config entries, ignoring rest. Limit is: %d\n",MAX_ENTRIES);
		break;
		}
	if (line[0]!=';')
		{
		rmtrail(line);
		strcpy(name[namecnt],line);
		namecnt++;
		}
	}
fclose(cfg);
printf("%d config entries read from %s\n",namecnt,argv[1]);

//for (junk=0; junk!=namecnt; junk++)		printf("Entry %d: [%s]\n",junk,name[junk]);

for (junk=0; junk!=namecnt; junk++)		strcpy((char *)result[junk],"Not Found");

strcpy(work_path,argv[2]);

if (strchr(work_path,'\\'))
	{
	for (junk=strlen(work_path); junk > 0; junk--)
		{
		if (work_path[junk]=='\\')
			{
			work_path[junk]='\0';
			break;
			}
		}
	}
printf("Log path: [%s]\n",work_path);

change_path(work_path);

done=findfirst(argv[2],&ff,0);

while(!done)
	{
	logfiles++;
	work(ff.ff_name);
	done=findnext(&ff);
	}
	//!!!!!

printf("Finished reading. Parsing results.\n");
fprintf(out,"When-On created this file, based on the logfile: %s\n",strupr(argv[2]));
fprintf(out,"First date in logfile: %s\n\n",firstline);

for (junk=0; junk!=namecnt; junk++)
	{
	fprintf(out,"%-30s%s\n",name[junk],result[junk]);
	printf("%-30s%s\n",name[junk],result[junk]);
	}

fprintf(out,"\n\n--- When-On\n");
fclose(out);

change_path(home_path);

printf("Done. %d logfiles read.  %d forgotten files closed.\n",logfiles,fcloseall());
return 0;
}

void work(char *fil)
{
FILE *log;
if ((log=fopen(fil,"rt"))==NULL)
	{
	printf("Cannot open log_file: %s\n",fil);
	return;
	}

printf("Reading %s\\%s...\n",work_path,fil);

fgets(line,200,log);
fgets(line,200,log);
fgets(line,200,log);
line[15]=0;
strcpy(firstline,line);

while(fgets(line,200,log))
	{
	for (junk=0; junk!=namecnt; junk++)
		{
		if ((strstr(line,name[junk])) && (strstr(line,modifier)))	// need to check tfor that to stop it triggering on mailscan
			{
			line[39]=0;
			line[offset]=0;
			if (domonth)
				{
				sscanf(line,"%d/%d",&day,&mon);
				if (mon==month)
					{
					strcpy(result[junk],line);
					}
				}
				else
				{
				strcpy(result[junk],line);
				}

			}
		}
	}

fclose(log);
}

char *rmtrail(char *lin)
{
int jnk;

jnk=strlen(lin);
while(jnk >= 0)
	{
	jnk--;
	if (!isspace(lin[jnk])) break;
	lin[jnk]=0;
	}
return lin;
}


void change_path(char *path)
{
int dr;

if (strchr(path,':'))
	{
	dr=toupper(path[0]);
	dr-=64;
	if (_chdrive(dr))
		{
		printf("Error changing drive to %c: (%d)\r\n",path[0],dr);
		sleep(1);
		}
	}
if (chdir(path))
	{
	printf("Error changing path to: [%s]\n",path);
	sleep(1);
	}
}

