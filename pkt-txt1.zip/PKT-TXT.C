// convert pkt -> txt

#include <stdio.h>
#include <string.h>
#include <mem.h>

// Type definitions, for shorthand
typedef unsigned char   byte;
typedef unsigned short	word;
typedef signed short		integer;
typedef signed long 		int32;
typedef unsigned long 	uint32;

char * nullgets(int maxlen, FILE *fil)
{
char line[100];
int junk;
char c;

memset(line,0,100);

for (junk=0; junk!=maxlen; junk++)
	{
	if (junk>99) break;

	c=fgetc(fil);
	switch (c)
		{
		case 0:
		case '\r':
		case '\n':
			line[junk]=0;
	  return strdup(line);
		default:
			line[junk]=c;
			break;
		}
	}
line[junk]=0;
return strdup(line);
}

struct {
	short int 	origNode;
	short int 	destNode;
	short int 	year;
	short int 	month;
	short int 	day;
	short int 	hour;
	short int 	minute;
	short int 	second;
	short int 	baud;
	short int   packetver;
	short int   orignet;
	short int 	destnet;
	unsigned char prodcodeL;
	unsigned char revisionH;
	unsigned char password[8];
	short int   origZone;
	short int 	destZone;
  short int 	AuxNet;

	short int 	CWvalidationCopy;
  unsigned char prodcodeH;
	unsigned char	revisionL;
	short int 	CapWord;

	short int		OrigZone;
	short int 	DestZone;
	short int 	OrigPoint;
	short int 	DestPoint;
	char	ProdData[4];
} PKTHDR;


struct {
	unsigned short int  ver,                        /*Packet version (2)*/
						orignode,                         /*Originating node*/
						destnode,                         /*Destination node*/
						orignet,                           /*Originating net*/
						destnet,                           /*Destination net*/
						Attribute,                                  /*FTS1 status*/
						cost;                              /*Cost of message*/
} msghdr;

struct {
	char            DateTime[20];
	char            toUserName[36];
	char            fromUserName[36];
	char            Subject[72];
	/*
	**    The message header follows this but is of variable length ASCIIZ
	**    strings in the order: AsciiDate, ToUser, FromUser, Subject, and
	**    MsgText.
	*/
} msghdrtxt;

struct {
	char            fromUserName[36];
	char            toUserName[36];
	char            Subject[72];
	char            DateTime[20];
	short unsigned  TimesRead;
	short unsigned  destnode;
	short unsigned  orignode;
	short unsigned  cost;
	short unsigned  orignet;
	short unsigned  destnet;
	short unsigned  DestZone;
	short unsigned  OrigZone;
	short unsigned  DestPoint;
	short unsigned  OrigPoint;
	short unsigned  replyTo;
	short unsigned  Attribute;
	short unsigned  nextreply;
} opus;


int main(void)
{
int msgnum=0,junk;
char c;
printf("Converting pkt -> Txt\n");
printf("Usage: PKT-TXT <pkt >txt\n");

if (!fread(&PKTHDR,sizeof(PKTHDR),1,stdin))
	printf("* Error reading pkthdr.\r\n");


printf("Packet Header from %d:%d/%d.%d to %d:%d/%d.%d\n",
															PKTHDR.origZone,
															PKTHDR.orignet,
															PKTHDR.origNode,
															PKTHDR.OrigPoint,
															PKTHDR.destZone,
															PKTHDR.destnet,
															PKTHDR.destNode,
															PKTHDR.DestPoint);


msghdr.ver=2;

while(msghdr.ver)	// read all msgs stdin packet.
	{
	msghdr.ver=getw(stdin);

	if (msghdr.ver==0)
		{
		printf("\n* End of PKT. Offset: %lu\n",ftell(stdin));
		break;
		}

	msghdr.orignode=getw(stdin);
	msghdr.destnode=getw(stdin);
	msghdr.orignet=getw(stdin);
	msghdr.destnet=getw(stdin);
	msghdr.Attribute=getw(stdin);
	msghdr.cost=getw(stdin);

//printf("Offset after hdr: %lu\n",ftell(stdin));

	strcpy(msghdrtxt.DateTime,nullgets(20,stdin));
	strcpy(msghdrtxt.toUserName,nullgets(35,stdin));
	strcpy(msghdrtxt.fromUserName,nullgets(35,stdin));
	strcpy(msghdrtxt.Subject,nullgets(72,stdin));


	printf("****************************************************************\nMsg Number: %d\n",++msgnum);

	printf("From: %s @ %d:%d/%d.%d on %s\n",msghdrtxt.fromUserName,
									PKTHDR.OrigZone,
									msghdr.orignet,
									msghdr.orignode,
									PKTHDR.OrigPoint,
									msghdrtxt.DateTime);
	printf("To: %s @ %d:%d/%d.%d\n",msghdrtxt.toUserName,PKTHDR.DestZone,msghdr.destnet,msghdr.destnode,PKTHDR.DestPoint);
	printf("Subj: %s\n",msghdrtxt.Subject);
	printf("------------------------------------------------------------------\n");


	// got PKT msgheader info, copy null-term text into temp file
	junk=0;

	while (!feof(stdin))
		{
		c=fgetc(stdin);

		switch(c)
			{
			case 0:
				if (junk)	junk=2;
				break;
			case 1:
				junk=1;
				putchar('@');
				break;
//			case 10:
			case 13:
				putchar(c);
				putchar('\n');
				putchar('#');
				junk=1;
				break;
			default:
				if (c)	putchar(c);
				break;
			}

		if (junk==2)	break;
		}
	}
printf("\n\nEnd of file. %d messages processed.\n",msgnum);

return 0;
}
