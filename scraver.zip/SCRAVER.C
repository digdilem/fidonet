/*
22 February 1995
Screen saver. Displays text in an ascii file. ("SCRAVER.TXT")
This update to Borland Turbo C v.3.0  Simon Avery
*/


#include<stdio.h>
#include <conio.h>
#include <bios.h>
#include <string.h>
#include <stdlib.h>

void center(char *mush,int y);


int main(void)
{
FILE *fp1;      /*SAVER.TXT*/
char len;
char text[81];
char buf1[71];
char buf3[71];
char a;

printf("\nScraver v.1.  (c) Simon Avery   FreeWare!");

randomize();
delay(500);

fp1=fopen("SCRAVER.TXT","r");

if (fp1 == NULL)
	{
	printf("\nError! \"SCRAVER.TXT\" not found!\n");
	exit(1);
	}

fgets(text,70,fp1);

fclose(fp1);

len=(strlen(text)+2);

_setcursortype(_NOCURSOR);

sprintf(buf1,"� %s �",text);
strcpy(text,buf1);

sprintf(buf1,"�");
for (a=0; a!=len; a++)
	{
	strcat(buf1,"�");
	}
strcat(buf1,"�");

sprintf(buf3,"�");
for (a=0; a!=len; a++)
	{
	strcat(buf3,"�");
	}
strcat(buf3,"�");

a=2;

while (!bioskey(1))
	{
	textbackground(BLACK);
	clrscr();
	textattr(random(128));
	center(buf1,(a-1));
	center(text,a);
	center(buf3,(a+1));
//	sound(300);
//	delay(1);
//	nosound();
	sleep(1);
	a++;
	if (a>23)	a=2;
	}

textattr(15);
clrscr();
cprintf("Scraver Done.\r\n");
bioskey(0);
_setcursortype(_NORMALCURSOR);

return 0;
}

void center(char *mush,int y)
{
int len;
len=strlen(mush);
gotoxy(40-(len/2),y);
cputs(mush);
}
