/*
disko.c

Small prog to list contents of a disk and append filename onto a single
text file.

Numbers them.

Usage: DISKO num TEXTFILE

Num replaced by number to count FROM

(c) SImon Avery 1995

*/


#include <stdio.h>
#include <dos.h>
#include <dir.h>
#include <stdlib.h>

int main(int argc, char*argv[])
{
FILE *log;
struct ffblk ffblk;
int cnt,done,ch;

printf("\nDisko (c) Simon Avery 1995\n");

if (argc!=3)	{ printf("Usage: DISKO num TEXTFILE"); exit(1); }

cnt=atoi(argv[1]);
printf("Textfile: %s. Starting count from %d\n",argv[2],cnt);

if ((log=fopen(argv[2],"at")) == NULL)
	{
	printf("Error opening logfile\n");
	exit(2);
	}

while (ch!=27)
	{
	fprintf(log,"\r\n---Disk #%d---\r\n\n",cnt);
	done = findfirst("A:\\*.*",&ffblk,0);

	while (!done)
	{
	fprintf(log,"%-15s%lu\r\n",
				     ffblk.ff_name,
				     ffblk.ff_fsize
				     );
	done = findnext(&ffblk);
	}
	cnt++;
	printf("Insert New Disk (%d), or press ESC to quit.\r\n",cnt);
	sound(900);
	delay(30);
	nosound();
	ch=getch();
	}

fclose(log);
return 0;
}