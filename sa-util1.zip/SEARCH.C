/*

search.c

(c) Simon Avery

Search a wildcard argument of files for a specific text string


*/


#include <stdio.h>
#include <string.h>
#include <dos.h>
#include <dir.h>
#include <conio.h>
#include <editgets.h>

#define LOGFILE	"SEARCH.LOG"

char loggit(char *msg);


FILE *log;
char str[81];
char lng[162];
int tot=0;
int yes=0;
int no=0;
int currtot=0;
int tmp=0;
char dolog=0;
unsigned long line=0;

main(int argc, char *argv[])
{
FILE *fp;
struct ffblk ffblk;
int done;
char dummy[81];

textcolor(WHITE);

cprintf("\r\nSearch  [Freeware]  (c) Simon Avery 1995");

if (argc<2)	{ help(); }

if ((argc==3) && (!strcmpi(argv[2],"LOG")))
	{
	textcolor(LIGHTGREEN);
	cprintf("\r\nLogging Output to %s",LOGFILE);
	dolog=1;
	if ((log=fopen(LOGFILE,"wt")) == NULL)
		{
		textcolor(LIGHTMAGENTA);
		cprintf("\r\nUnable to open logfile: %s",LOGFILE);
		exit(2);
		}
	}

cprintf("\r\nPlease enter the string to search for in filespec: %s\r\n",argv[1]);

editgets(wherex(),wherey(),str,78,0,0);
textbackground(BLACK);

sprintf(dummy,"%s started with filespec: %s",argv[0],argv[1]);
loggit(dummy);
sprintf(dummy,"\r\nSearching for: %s",str);
loggit(dummy);

done=findfirst(argv[1],&ffblk,0);

while (!done)
	{
	tot++;
	currtot++;
	if ((fp=fopen(ffblk.ff_name,"rb")) == NULL)
		{
		textcolor(LIGHTMAGENTA);
		sprintf(dummy,"\r\nUnable to open %s",ffblk.ff_name);
		cprintf(dummy);
		loggit(dummy);
		}
		else
		{
		while (fgets(lng,160,fp))
			{
			line++;
			if (strstr(lng,str) != NULL)
				{
				if (!tmp)
					{
					textcolor(WHITE);
					sprintf(dummy,"\r\nFound string in %s (Line %d)",ffblk.ff_name,line);
					cprintf(dummy);
					loggit(dummy);
					yes++;
					}
				tmp++;
				}
			}
		if (tmp)
			{
			sprintf(dummy," [%d] times.",tmp);
			cprintf(dummy);
			loggit(dummy);
			}
			else
			{
			textcolor(GREEN);
			cprintf("\r\nNot found in %s",ffblk.ff_name);
			sprintf(dummy,"\r\nString Not found in %s",ffblk.ff_name);
			loggit(dummy);
			no++;
			}
		}
	fclose(fp);
	tmp=0;
	line=0;
	if (currtot>20)	{ getch(); currtot=0; }

	done=findnext(&ffblk);
	}

textcolor(YELLOW);
sprintf(dummy,"\r\n%d files.     Match: %d.    No Match: %d\r\n\n",tot,yes,no);
cprintf(dummy);
loggit(dummy);
loggit("\r\nSearch Finished");

fcloseall();
return 0;
}

char loggit(char *msg)
{
if (dolog)
	{
	fprintf(log,msg);
	}
return 0;
}

beepit(int del)
{
sound(del);
delay(1);
nosound();
return(0);
}

help()
{
textcolor(WHITE);
cprintf("\r\nTo search multiple files for a string.");
textcolor(LIGHTCYAN);
cprintf("\r\nUsage: SEARCH [filespec] {LOG}");
textcolor(CYAN);
cprintf("\r\nEg: SEARCH *.H");
textcolor(LIGHTGRAY);
cprintf("\r\nString entered after program started.\r\n\n");
exit(1);
return 0;
}
