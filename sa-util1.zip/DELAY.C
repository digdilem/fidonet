/*

delay.c

(c) Simon Avery 1995

Simple prog to delay for nn milliseconds

*/


#include <dos.h>
#include <stdlib.h>

main (int argc, char *argv[])
{
if (argc<2)
	{
	printf("\nDelay (c) Simon Avery 1995)");
	printf("\nDelays for nn milliseconds");
	printf("\nEg. DELAY 50\n\n");
	exit(1);
	}

delay(atoi(argv[1]));

return 0;
}

