/*

LOCK-KEY.c

(c) Simon Avery 1995

Toggles num lock/ caps and scroll by c-line


*/

#include <stdio.h>
#include <dos.h>

main(int argc, char *argv[])
{
char method=0;

if (argc<2)	{ help(); }

				// help
if (!stricmp(argv[1],"?"))	method=1;
if (!stricmp(argv[1],"H"))	method=1;
				// caps on
if (!stricmp(argv[1],"C+"))	method=2;
				// caps off
if (!stricmp(argv[1],"C-"))	method=3;
				// Scroll on
if (!stricmp(argv[1],"S+"))	method=4;
				// Scroll off
if (!stricmp(argv[1],"S-"))	method=5;
				// Num on
if (!stricmp(argv[1],"N+"))	method=6;
				// Num off
if (!stricmp(argv[1],"N-"))	method=7;


switch(method)
	{
	case 1:
		help();
		break;
	case 2:
		caps_on();
		break;
	case 3:
		caps_off();
		break;
	case 4:
		scroll_on();
		break;
	case 5:
		scroll_off();
		break;
	case 6:
		num_on();
		break;
	case 7:
		num_off();
		break;
	default:
		printf("\nUnknown Switch\n");
		break;
	}


return 0;
}

help()
{
printf("\nLock-Key   (c) Simon Avery 1995\n");
printf("\n(A program to toggle keyboard lights   (FREEWARE))\n");

printf("\nUsage:   LOCK-KEY [cc]      (cc can be:)\n");
printf("\nC+	Caps Lock On			C-	Caps Lock Off");
printf("\nN+	Numlock On			N-	Numlock Off");
printf("\nS+	Scroll Lock On                  S-	Scroll Lock Off\n\n");

exit(1);
return 0;
}




 caps_on()
{
char  status;

status = peekb (0x40, 0x17);
status |= 0x40;

pokeb (0x40,0x17, status);
return;
}

 caps_off()
{
char  status;

status = peekb (0x40, 0x17);
status &= ~0x40;

pokeb (0x40,0x17, status);
return;
}

 num_on()
{
char  status;

status = peekb (0x40, 0x17);
status |= 0x20;

pokeb (0x40, 0x17, status);
return;
}

 num_off()
{
char  status;

status = peekb (0x40, 0x17);
status &= ~0x20;

pokeb (0x40, 0x17, status);
return;

}

 scroll_on()
{
char  status;

status = peekb (0x40, 0x17);
status |= 0x10;

pokeb (0x40, 0x17, status);
return;
}

 scroll_off()
{
char  status;

status = peekb (0x40, 0x17);
status &= ~0x10;

pokeb (0x40, 0x17, status);
return;

}




