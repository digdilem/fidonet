/*
timedate.c

(c) Simon Avery

Simply outputs time and date onscreen

*/

#include <stdio.h>
#include <dos.h>

void main(void)
{
struct time t;
struct date d;

gettime(&t);
getdate(&d);

printf("\nTime: %d:%d:%d.%d    Date: %d/%d/%d",
					       t.ti_hour,
					       t.ti_min,
					       t.ti_sec,
					       t.ti_hund,
					       d.da_day,
					       d.da_mon,
					       d.da_year
					       );

}