/*
DEL-S   (c) Simon Avery 1995

Useful utility to delete files through sub-dirs

ie. DEL *.BAK /S


A function much needed by me, and sadly lacking in MS-DOS 6.2

Freeware

*/


#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <string.h>
#include <dos.h>
char filespec[13];	// What to delete

char hidden=0;

unsigned long tot_files=0;
unsigned long tot_dirs=1;
unsigned long tot_bytes=0;

char origdir[MAXPATH];
char origpath[MAXPATH];

void findpath(char origpath[MAXDIR]);

int main(int argc, char *argv[])
{

if (argc < 2)	{ help(); }

strcpy(filespec,argv[1]);

printf("\nDEL-S  (c) 1995 Simon Avery.  DEL-S /? for help [%s]",filespec);

if (!strcmpi(filespec,"*.*"))
	{
	printf("\nDelete ALL files?  Sure? (y/N)");
	switch(getch())
		{
		case 'y':
		case 'Y':
			break;
		default:
			printf("\nExitting.\n");
			exit(2);
			break;
		}
	}

if (argc==3)
	{
	switch(argv[2][1])
		{
		case 'h':
		case 'H':
			hidden=1;
			printf("\nDoing Hidden Files");
			break;
		case '?':
			help();
			break;
		default:
			printf("\nUnknown Switch.");
			exit(3);
			break;
		}
	}

getcurdir(0, origdir);

findpath(origdir);

printf("\nCompleted.\nDeleted files: %lu   Total Dirs: %lu  Total Bytes: %lu\n",tot_files,tot_dirs,tot_bytes);

return 0;
}

void findpath(char origpath[MAXPATH])
{
int done = 0;
int done2=0;
struct ffblk data;
struct ffblk fildata;

done = findfirst("*.*", &data, FA_DIREC+FA_SYSTEM+FA_HIDDEN);

while (!done)
{
	if (((data.ff_attrib & FA_DIREC) == FA_DIREC) &&
		(data.ff_name[0] != '.'))
		{
		chdir(data.ff_name);
		findpath(origpath);
		chdir("..");
		tot_dirs++;
		}
	// my stuff to search in dir
	if (!hidden)
		{
		done2=findfirst(filespec,&fildata,0);
		}
		else
		{
		done2=findfirst(filespec,&fildata,FA_HIDDEN+0);
		}
	while (!done2)
		{
		tot_files++;
		tot_bytes+=fildata.ff_fsize;

		unlink(fildata.ff_name);

		done2=findnext(&fildata);
		}


		done = findnext(&data);


}

}

help()
{
printf("\nDEL-S    (c) Simon Avery "__DATE__
	"\nDOS utility to delete files including sub-directories."
	"\nEffectively a DEL [filespec] /S"
	"\n\nUsage: DEL-S [Filespec] {/H /?}"
	"\nEg: DEL-S *.BAK /H"
	"\n\n/H searches for Hidden files too."
	"\n\n/? Shows this help.\n");

exit(1);
return 0;
}
