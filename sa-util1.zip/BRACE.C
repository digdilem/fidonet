/*
brace.c

(c) Simon Avery 1995

Checks source files for number of leading and closing brackets.

*/

#include <stdio.h>


int main(int argc, char *argv[])
{
FILE *fp;
unsigned long tot_open=0;
unsigned long tot_closed=0;
char ch;

if (argc<2)	help();

printf("\nBrace   [Freeware]  (c) Simon Avery 1995");

if ((fp=fopen(argv[1],"rb")) == NULL)
	{
	printf("\nUnable to open file: %s\n",argv[1]);
	exit(2);
	}

printf("\nFile: %s",argv[1]);


while (ch!=EOF)
	{
	ch=fgetc(fp);
	if (ch=='{')	tot_open++;
	if (ch=='}')	tot_closed++;
	}

fclose(fp);

printf("\nNumber of Open Braces   : %lu",tot_open);
printf("\nNumber of Closed Braces : %lu",tot_closed);

if (tot_open==tot_closed)
	{
	printf("\nBrace count OK!");
	}
	else
	{
	printf("\nUnequal number of braces!");
	}

return 0;
}


help()
{
printf("\nUsage:  BRACE [filename.ext]");
printf("\nCounts number of braces in a file.\n\n");
exit(1);
return 0;	// Not needed, but keep compiler happy.
}








