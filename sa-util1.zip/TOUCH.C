/*

touch.c

(c) Simon Avery

touches filetime on wildcard files

*/

#include <string.h>
#include <stdio.h>
#include <dos.h>
#include <fcntl.h>
#include <io.h>
#include <process.h>
#include <time.h>

main(int argc, char *argv[])
{
FILE *fp;
int handle;
int done;
int tot=0;
struct ffblk ffblk;
struct time t;
struct date d;
struct ftime filet;

gettime(&t);
getdate(&d);

filet.ft_tsec = t.ti_sec;
filet.ft_min = t.ti_min;
filet.ft_hour = t.ti_hour;
filet.ft_day = d.da_day;
filet.ft_month = d.da_mon;
filet.ft_year = d.da_year;

printf("\nTouch  [Freeware]  (c) Simon Avery 1995");

if (argc<2)	{ help(); }

if (!strcmpi(argv[1],"/?"))
	{
	help();
	}

done=findfirst(argv[1],&ffblk,0);

while (!done)
	{
	tot++;
	if ((fp=fopen(ffblk.ff_name,"rb"))==NULL)
		{
		printf("\nUnable to open file: %s",ffblk.ff_name);
		}

	setftime(fileno(fp), &filet);

	fclose(fp);
	done=findnext(&ffblk);

	}

printf("\n%d files touched.\n",tot);

return 0;
}

help()
{
printf("\nTo touch multiple files with current time and date.");
printf("\nUsage: TOUCH [filespec]");
printf("\nEg: TOUCH *.*\n");
exit(1);
return 0;
}
