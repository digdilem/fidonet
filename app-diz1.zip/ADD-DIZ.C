/*
Search .ZIP files and append /string/ to wotsit

PD by Simon Avery.  2:255/90

Not technical, not portable, not pretty, but it does work.

If you use it, please mention my name in the docs.

If you want to complain that it doesn't work, address your mail to >NUL
If you want to complain that it works too well and you're fed up with
        DIZ adverts everywhere, address your mail to >NUL.

Compiles (cleanly) under Turbo C/C++ V.3 for DOS.

Notes:  findfirst/findnext aren't ANSI.        

Suggestions:
        Include support for other archivers, perhaps using a config
                file to store user-editable strings.
        Random additions.
        Spawno() or similar to give more memory to archivers.
*/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <dir.h>
#include <string.h>
#include <io.h>

int main(int argc, char*argv[])
{
long totdone=0L;
struct ffblk ffblk;
int done,fnd;
char dummy[100];
char zippath[100];
FILE *fil;
char idstr[15];

printf("Append-a-Diz. (c) "__DATE__" Simon Avery\n");

if (argc!=3)
	{
	printf("Usage: %s {ZipFileDIR} {\"String to add\"}\n",argv[0]);
	return 3;
	}


sprintf(zippath,"%s\\*.ZIP",argv[1]);

printf("ZipPath=%s\n",zippath);
done=findfirst(zippath,&ffblk,0);

while(!done)
	{
	sprintf(zippath,"%s\\%s",argv[1],ffblk.ff_name);
	printf("Searching: %s  ",zippath);
	fnd=0;
	sprintf(dummy,"PKUNZIP -o %s FILE_ID.DIZ DESC.SDI >NUL",zippath);
	system(dummy);

	if (!access("FILE_ID.DIZ",0))
		{
		strcpy(idstr,"FILE_ID.DIZ");
		fnd=1;
		}

	if (!access("DESC.SDI",0))
		{
		strcpy(idstr,"DESC.SDI");
		fnd=1;
		}

	if (!fnd)
		{
		printf("Error - no desc file found.\n");
		}
		else
		{
		printf("Found: %s\n",idstr);
		if ((fil=fopen(idstr,"at"))==NULL)
			{
			printf("Unable to open desc file: [%s]\n",idstr);
			}
			else
			{
			fputs(argv[2],fil);
			fclose(fil);
			}
		sprintf(dummy,"PKZIP -ex %s %s >NUL",zippath,idstr);
		system(dummy);
		}
	totdone++;
	unlink("FILE_ID.DIZ");
	unlink("DESC.SDI");
	done=findnext(&ffblk);
	}

printf("Finished. %lu done\n",totdone);
return 0;
}









