/*
MEM-CHEK.C

(C) Simon Avery 14/10/95

Small program that checks memory available on bootup and
compares it against previous. May prevent TSR viruses

compile in SMALL mem model. (NOT Tiny - farcoreleft doesn't work)

*/


#include <stdio.h>
#include <alloc.h>

#define MEMFILE	"MEMFILE.MEM"

main()
{
unsigned long old1;
unsigned long new1;
FILE *fp;

printf("\nMem-Check (c) Simon Avery 1995");

new1=farcoreleft();


if ((fp=fopen(MEMFILE,"rb")) == NULL)
	{
	printf("\a\nMemfile not found. Creating New...\n");
	fclose(fp);
	if ((fp=fopen(MEMFILE,"wb")) == NULL)
		{
		printf("\a\nUnable to create Memfile: %s.\nAborting. (2)\n",MEMFILE);
		exit(2);
		}
		else
		{
		fprintf(fp,"%ld",new1);
		printf("\nNew file created. Exitting (3)\n");
		fclose(fp);
		exit(3);
		}
	}
	else
	{
	fscanf(fp,"%lu",&old1);
	fclose(fp);
	}

if (old1!=new1)
	{
	printf("\a\nMemory Has Changed.");
	printf("\nOld value: %lu",old1);
	printf("\nNew value: %lu",new1);
	printf("\nCreating new Mem-Check file.");
	unlink(MEMFILE);
	if ((fp=fopen(MEMFILE,"wb")) == NULL)
		{
		printf("\a\nUnable to create Memfile: %s.\nAborting (2)\n",MEMFILE);
		exit(2);
		}
		else
		{
		fprintf(fp,"%lu",new1);
		fclose(fp);
		}
	getch();		// Change to sleep(n) if using from auto
	printf("\nExitting: (1)\n");
	exit(1);
	}
	else
	{
	printf("\nMemory same: %lu    Exitting (0)\n",new1);
	}

return 0;
}






























