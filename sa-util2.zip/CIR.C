/*
cir.c

colour dir replacement.
(c) Simon Avery 1995

Use as DIR
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dir.h>
#include <time.h>
#include <string.h>
#include <dos.h>
#include <io.h>
#include <sys\stat.h>

void help(void);
void getfree(void);
void thou_bytes(void);
void paused(void);

char pause=0;
char wide=0;

struct ffblk ffblk;
struct stat statbuf;

unsigned long avail;
unsigned long tot_bytes=0L;
char dummy[25];

int main(int argc,char *argv[])
{
char filespec[MAXPATH];
char drive[MAXDRIVE];
char dir[MAXDIR];
char file[MAXFILE];
char ext[MAXEXT];
int done;
char ypos=0;
int tot_files=0;

	// get dircmd enviroment

if (strstr(getenv("DIRCMD"),"/P")!=NULL)        pause=1;
if (strstr(getenv("DIRCMD"),"/W")!=NULL)        wide=1;

strcpy(filespec,"*.*");         // default filespec

if (argc>1)
	{
	for (done=1; done!=argc; done++)
		{
		if (!strcmpi(argv[done],"/?"))  help();
			else
			if (!strcmpi(argv[done],"/w"))  wide=1;
				else
				if (!strcmpi(argv[done],"/p"))  pause=1;
					else
					strcpy(filespec,argv[done]);
		}
	}

if (strstr(filespec,".")==NULL)         strcat(filespec,".*");

textbackground(BLACK);
textcolor(WHITE);
cprintf("\r\nCIR  (c) Simon Avery %s  Filespec: %s  %s  %s  %s\r\n",
							__DATE__,
							filespec,
							pause ? "PAUSE" : "",
							wide ? "WIDE" : ""
							);

getfree();

done=findfirst(filespec,&ffblk, FA_DIREC+FA_SYSTEM+FA_HIDDEN+FA_RDONLY);

if (done!=0)
	{
	cprintf("\r\nNo files\r\n");
	return 0;
	}

while (!done)
	{
	tot_files++;
	tot_bytes+=ffblk.ff_fsize;

	fnsplit(ffblk.ff_name,drive,dir,file,ext);

	stat(ffblk.ff_name,&statbuf);
	textcolor(WHITE);       // default col
			// define colours for extensions

	if (!strcmp(ext,".EXE"))        textcolor(LIGHTRED);
	if (!strcmp(ext,".COM"))        textcolor(LIGHTRED);
	if (!strcmp(ext,".BAT"))        textcolor(LIGHTRED);

	if (!strcmp(ext,".TXT"))        textcolor(LIGHTBLUE);
	if (!strcmp(ext,".DOC"))        textcolor(LIGHTBLUE);
	if (!strcmp(ext,".ME"))         textcolor(LIGHTBLUE);

	if (!strcmp(ext,".C"))          textcolor(LIGHTGREEN);
	if (!strcmp(ext,".CPP"))        textcolor(LIGHTGREEN);
	if (!strcmp(ext,".H"))          textcolor(LIGHTGREEN);
	if (!strcmp(ext,".HPP"))        textcolor(LIGHTGREEN);
	if (!strcmp(ext,".ASM"))        textcolor(LIGHTGREEN);

	if (!strcmp(ext,".BIN"))        textcolor(GREEN);
	if (!strcmp(ext,".MAK"))        textcolor(GREEN);
	if (!strcmp(ext,".DLL"))        textcolor(GREEN);
	if (!strcmp(ext,".DAT"))        textcolor(GREEN);
	if (!strcmp(ext,".OBJ"))        textcolor(GREEN);
	if (!strcmp(ext,".OVL"))        textcolor(GREEN);
	if (!strcmp(ext,".LIB"))        textcolor(GREEN);
	if (!strcmp(ext,".LOG"))        textcolor(GREEN);

	if (!strcmp(ext,"."))   textcolor(LIGHTGRAY);
	if (!strcmp(ext,".."))  textcolor(LIGHTGRAY);

	if (!strcmp(ext,".$$$"))        textcolor(BROWN);
	if (!strcmp(ext,".SWP"))        textcolor(BROWN);
	if (!strcmp(ext,".TMP"))        textcolor(BROWN);

	if (!strcmp(ext,".ICO"))        textcolor(MAGENTA);
	if (!strcmp(ext,".PIF"))        textcolor(MAGENTA);

	if (!strcmp(ext,".CFG"))        textcolor(LIGHTMAGENTA);
	if (!strcmp(ext,".CF2"))        textcolor(LIGHTMAGENTA);

	if (!strcmp(ext,".BAK"))        textcolor(CYAN);

	if (!strcmp(ext,".MOD"))        textcolor(LIGHTCYAN);
	if (!strcmp(ext,".MID"))        textcolor(LIGHTCYAN);
	if (!strcmp(ext,".WAV"))        textcolor(LIGHTCYAN);
	if (!strcmp(ext,".S3M"))        textcolor(LIGHTCYAN);

	if ((ffblk.ff_attrib & FA_DIREC) == FA_DIREC)   textcolor(YELLOW);      // recurse for sub-dirs


	if ((ffblk.ff_attrib & FA_HIDDEN) == FA_HIDDEN) textcolor(DARKGRAY+BLINK);
	if ((ffblk.ff_attrib & FA_SYSTEM) == FA_SYSTEM) textcolor(WHITE+BLINK);

	sprintf(dummy,"%lu",ffblk.ff_fsize);
	thou_bytes();

	if (wide)
		{
		if ((ffblk.ff_attrib & FA_DIREC) == FA_DIREC)   strcat(ffblk.ff_name,"  <DIR>");
		cprintf("%-20s",ffblk.ff_name);
		}
		else
		{

		cprintf("%-12s %s� %15s � %s\r",
						   ffblk.ff_name,
						   ffblk.ff_attrib & FA_RDONLY ? "(R/O)" : "     ",
						   ffblk.ff_attrib & FA_DIREC ? "<DIR>" : dummy,
						   ctime(&statbuf.st_ctime)
						   );
		}
	if (pause)      ypos++;

	if (wide)
		{
		if (ypos>88)
			{
			ypos=0;
			paused();
			}
		}
		else
		{
		if (ypos>22)
			{
			ypos=0;
			paused();
			}
		}

	done = findnext(&ffblk);
	}

textcolor(WHITE);

sprintf(dummy,"%lu",tot_bytes);
thou_bytes();
	// do seperators for tot bytes

cprintf("\r\n%d Files: %s Bytes:",
				  tot_files,
				  dummy
				  );

sprintf(dummy,"%lu",avail);
thou_bytes();
cprintf(" %s free diskspace.\r\n",dummy);
return 0;
}

void paused(void)
{
char ch;
textcolor(GREEN);
cprintf("\r\nPaused.  ESC or any key");
sound(500);
delay(2);
nosound();

ch=getch();
switch(ch)
	{
	case 27:
		exit(2);
		break;
	default:
		cprintf("\r");
		clreol();
		gotoxy(1,(wherey()-1));
		break;
	}
}

void getfree(void)
{
   struct dfree free;
   int drive;

   drive = getdisk();
   getdfree(drive+1, &free);
   if (free.df_sclus == 0xFFFF)
   {
      printf("Error in getdfree() call\n");
      exit(1);
   }

   avail =  (long) free.df_avail
	    * (long) free.df_bsec
	    * (long) free.df_sclus;
}
	// converts global ulong to global string, including seperators every
	// thousand bytes (three physical bytes) Long winded, but fast.
void thou_bytes()
{
char dummy2[15];

strcpy(dummy2,dummy);
strcpy(dummy,"");
switch(strlen(dummy2))
	{
	case 4:
		sprintf(dummy,"%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3]);
		break;
	case 5:
		sprintf(dummy,"%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4]);
		break;
	case 6:
		sprintf(dummy,"%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5]);
		break;
	case 7:
		sprintf(dummy,"%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6]);
		break;
	case 8:
		sprintf(dummy,"%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7]);
		break;
	case 9:
		sprintf(dummy,"%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8]);
		break;
	case 10:
		sprintf(dummy,"%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9]);
		break;
	case 11:
		sprintf(dummy,"%c%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9],dummy2[10]);
		break;
	case 12:
		sprintf(dummy,"%c%c%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9],dummy2[10],dummy2[11]);
		break;
	case 13:
		sprintf(dummy,"%c,%c%c%c,%c%c%c,%c%c%c,%c%c%c",dummy2[0],dummy2[1],dummy2[2],dummy2[3],dummy2[4],dummy2[5],dummy2[6],dummy2[7],dummy2[8],dummy2[9],dummy2[10],dummy2[11],dummy2[12]);
		break;
	case 0:
	case 1:
	case 2:
	case 3: // too short to bother with
	default:
		strcpy(dummy,dummy2);
		break;
	}
}


void help(void)
{
printf("\nCIR  (Colour-Coded Dir)");
printf("\nCIR {filespec} {/W} {/P}  (Wide / Pause)\n");
printf("NB. Cir also takes parameters from the enviroment, DIRCMD\n\n");
exit(1);
}










