/*
TM.CFG -> AREAS.BBS converter.

*/

char *rmtrail(char *);

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <ctype.h>

void main(void)
{
FILE *tm,*area;
unsigned char line[1000],addr[31],name[40],jampath[40],echotag[50];
unsigned char origpath[100];
unsigned long totline=0L, totcomm=0L, totblank=0L, totecho=0L,totmark=0L;
char c;
int j;

printf("Tm.BBS -> AREAS.BBS converter. Freeware by Simon Avery.\n\n");

printf("Ensure TM.BBS is in current directory, and AREAS.BBS does not exist.\n");
printf("Does not handle multiple AKAs or groups.\n");
printf("Make backups of everything before running.\n");
printf("Press a key to continue (ESC to abort)\n\n");

switch(getch())
	{
	case 27:
		printf("Aborting.\n");
		exit(1);
		break;
	default:
		break;
	}

printf("Enter your FidoNet address (30chars): ");
fgets(addr,30,stdin);
rmtrail(addr);
printf("\nEnter your name (40 chars): ");
fgets(name,39,stdin);
rmtrail(name);
printf("\nEnter the path to your Termail directory (No trailing \\):\n");
fgets(origpath,99,stdin);
rmtrail(origpath);

if ((tm=fopen("TM.BBS","rt"))==NULL)
	{
	printf("Unable to open TM.BBS\n");
	exit(2);
	}

if ((area=fopen("AREAS.BBS","wt"))==NULL)
	{
	printf("Unable to create AREAS.BBS\n");
	exit(3);
	}

// write stuff to areas

fprintf(area,"%s ! %s\n",addr,name);
fprintf(area,"; Created by Tm-Area.exe by Simon Avery\n");


while(fgets(line,1000,tm))
	{
	c=0;
	if (line[0]=='%')		{ c=1; totcomm++;  }
	if (strlen(line)<3)		{ c=1; totblank++; }
	if (strstr(line,"@LINE"))	{ c=1; totmark++;  }

	if (!c)
		{
		rmtrail(line);

		for (j=0; j!=27; j++)	jampath[j]=line[j];
		jampath[j]='\0';

		for (j=29; j!=73; j++)  echotag[j-29]=line[j];
		echotag[j-29]='\0';

		fprintf(area,"!%s\\%-50s    %s\n",
						origpath,
						jampath,
						echotag);

		printf("Echo: [%s] converted.\n",echotag);
		totecho++;
		}

	totline++;
	}

printf("\nFinished.\n");
printf("Echos: %lu\nLines: %lu\nComments: %lu\nMarkers: %lu\nBlank lines: %lu\n",
				totecho,
				totcomm,
				totmark,
				totblank);

fclose(area);
fclose(tm);
}

char *rmtrail(char *lin)
{
int jnk;

jnk=strlen(lin);
while(jnk >= 0)
	{
	jnk--;
	if (!isspace(lin[jnk])) break;
	lin[jnk]=0;
	}
return lin;
}

